chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.action === 'fromPopup') {
        chrome.notifications.create(
            {
                type: "basic",
                title: "Notifications Title",
                message: "Notifications message to display",
                iconUrl: "../icons/icon.png"
            },
            (notificationId) => {
                console.log('fromPopup notificationId-->', notificationId)
            }
        );
    }
    if (message.action === 'fromContent') {
        console.log(message.url);
        chrome.notifications.create(
            {
                type: "basic",
                title: "Notifications Title",
                message: "Notifications message to display",
                iconUrl: "../icons/icon.png"
            },
            (notificationId) => {
                console.log('fromContent notificationId-->', notificationId)
            }
        );
    }
    if (message.action === 'fromContentFetch') {
        console.log(message.url);
        const response = await fetch(message.url)
        if (!response.ok) {
            throw new Error('Network response was not ok')
        }
        const allData = await response.json()
        console.log('service worker allData', allData)
    }
});

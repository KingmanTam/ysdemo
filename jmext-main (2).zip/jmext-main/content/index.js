console.log('this is content js')
console.log('document', document)
console.log('location', location)
console.log('window', window)

async function sendDomainInfo(nl, gxsj, jls, sj_min, sj_max, yy, bt, zt, wz, pf) {
    let url = 'http://hl.com/api.php/provide/vod/?ac=list&nl=' + nl + '&gxsj=' + gxsj + '&jls=' + jls + '&sj_min=' + sj_min + '&sj_max=' + sj_max + '&yy=' + yy + '&bt=' + decodeURI(bt) + '&zt=' + zt + '&wz=' + wz + '&pf=' + pf;
    console.log(url);
    //chrome.runtime.sendMessage({'type': 'jm', 'sendUrl': url});
    // const response = await fetch(url)
    // console.log(response)
    chrome.runtime.sendMessage({action: "fromContentFetch",url:url});
}

async function getDomainInfo(domain, key) {
    // let xhr = new XMLHttpRequest();
    // xhr.onloadend = function () {
    //     let json_data = xhr.response;
    //     let res = JSON.parse(json_data);
    //     if (res['code'] === 1) {
    //         let data = res['data'];
    //         let bt = Unicode2Native(data['bt'])
    //         sendDomainInfo(data['nl'], data['gxsj'], data['jls'], data['sj_min'], data['sj_max'], data['yy'], bt, data['zt'], data['wz'], data['pf'])
    //     }
    // }
    //let url = 'https://www.juming.com/hao/cha_d?do=lishi&ym=' + domain + '&key=' + key;
    const response = await fetch('https://dplayer.diygod.dev/')
    if (!response.ok) {
        throw new Error('Network response was not ok')
    }
    sendDomainInfo('1', "2", "3", "4", "5", "6", "7", "7", "9", "10");

}

async function geReturnTop(reqdomain) {
    // var xhr = new XMLHttpRequest();
    // xhr.onloadend = function () {
    //     let reptext = xhr.response;
    //     // let ends = reptext.indexOf('</script>');
    //     // let scriptText = reptext.substring(0,ends)
    //     let startnum = reptext.indexOf('key');
    //     let endnum = reptext.indexOf('jmkey');
    //     let key = reptext.substring(startnum + 5, endnum - 2);
    //     getDomainInfo(reqdomain, key);
    // }
    //let reqpurl = 'https://www.juming.com/hao?ym=' + reqdomain + '&fs=1&_=' + (new Date().getTime());
    //const response = await fetch('https://www.juming.com/hao?ym=' + reqdomain + '&fs=1&_=' + (new Date().getTime()))
    const response = await fetch('https://dplayer.diygod.dev/')
    console.log("jum", response);
    if (!response.ok) {
        throw new Error('Network response was not ok')
    }
    //const allData = await response.json()

    getDomainInfo("baidu.com",22)
}

function getOkDoamin(){
    const listform = document.getElementById('app');
    console.log(listform);
    geReturnTop("baidu.com")
    // const trlist = listform.getElementsByTagName('tr');
    // let lenl = trlist.length-1
    // for (let i = 1; i < lenl; i++) {
    //     let cells = trlist[i].cells;
    //     let domain = cells[0].innerText;
    //     let len = cells[1].innerText;
    //     let des = cells[2].innerText;
    //     let opt = cells[7].innerText;
    //     //if (opt!='立即注册') continue;
    //     if (len<5) continue;
    //     if (len>18)continue;
    //     if (des.length<4) continue;
    //     if (des.indexOf('建站')<0)continue;
    //     if (des.indexOf('记录0条')!==-1) continue;
    //     if (des.indexOf('建站0年')!==-1) continue;
    //     let reqdomain = domain.replace('.','_');
    //     geReturnTop(reqdomain);
    // }
    // setTimeout(function (){next()},2000)
}

//创建页面函数
function createPage () {
    const page = $('<div id="cj_move_page"></div>')
    const h3 = $('<h3 id="cj_move_h3">My Chrome Ext Content Page</h3>')
    const but1 = $('<button id="cj_but1">消息通知</button>')
    const but2 = $('<button id="cj_but2">content 加载更多</button>')
    const but3 = $('<button id="cj_but3">service worker 加载</button>')
    const but4 = $('<button id="cj_but4">加载domain</button>')
    page.append(h3)
    page.append(but1)
    page.append(but2)
    page.append(but3)
    page.append(but4)
    $('body').append(page)
    // 消息通知按钮事件
    $('#cj_but1').click(async (e) => {
        console.log('e', e, chrome)
        chrome.runtime.sendMessage({action: "fromContent"});
    })
    // content 加载更多按钮事件
    $('#cj_but2').click(async (e) => {
        const response = await fetch("https://dplayer.diygod.dev/")
        console.log("douban", response);
        if (!response.ok) {
            throw new Error('Network response was not ok')
        }
        const allData = await response.json()
        console.log('content index allData', allData)
    })
    // service worker 加载按钮事件
    $('#cj_but3').click(async (e) => {
        console.log('e', e, chrome)
        chrome.runtime.sendMessage({action: "fromContentFetch"});
    })

    $('#cj_but4').click(async (e) => {
        getOkDoamin();
    })

    //拖拽
    drag(cj_move_h3)
}

createPage()

//拖拽
function drag(ele) {
    let oldX, oldY, newX, newY
    ele.onmousedown = function (e) {
        if (!cj_move_page.style.right && !cj_move_page.style.bottom) {
            cj_move_page.style.right = 0
            cj_move_page.style.bottom = 0
        }
        oldX = e.clientX
        oldY = e.clientY
        document.onmousemove = function (e) {
            newX = e.clientX
            newY = e.clientY
            cj_move_page.style.right = parseInt(cj_move_page.style.right) - newX + oldX + 'px'
            cj_move_page.style.bottom = parseInt(cj_move_page.style.bottom) - newY + oldY + 'px'
            oldX = newX
            oldY = newY
        }
        document.onmouseup = function () {
            document.onmousemove = null
            document.onmouseup = null
        }
    }
}
chrome.runtime.onConnect.addListener((res) => {
    console.log('contentjs中的 chrome.runtime.onConnect：',res)
    if (res.name === 'fromPopup2Content') {
        res.onMessage.addListener(mess => {
            console.log('contentjs中的 res.onMessage.addListener：', mess)
            res.postMessage('哈哈哈，我是contentjs')
        })
    }
})


var editor = ace.edit("editor", {
    theme: "ace/theme/monokai",
    mode: "ace/mode/php",
    maxLines: 40,
    minLines:40,
    autoScrollEditorIntoView: true
});
var editor1 = ace.edit("editor1", {
    theme: "ace/theme/monokai",
    mode: "ace/mode/php",
    maxLines: 40,
    minLines:40,
    autoScrollEditorIntoView: true
});

$(function (){
    initValue();
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "2000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
})

$("#save").click(function() {
    let content = editor.getValue();
    $.ajax({
        type:'post',
        url:'domain/save',
        data:{content:content},
        dataType:'json',
        success:function (res) {
            if (res.success===1){
                toastr.success("保存成功!");
            }else {
                toastr.error("保存失败!");
            }
        }
    })
});

layui.use(function(){
    var util = layui.util;
    util.on('lay-on', {
        'test-page-custom': function(){
            layer.open({
                type: 1,
                // area: ['420px', '240px'], // 宽高
                content: '<div style="padding: 16px;">任意 HTML 内容</div>'
            });
        },
    })
});

function initValue(){
    $.ajax({
        type:'get',
        url:'domain/getDomainContent',
        dataType:'json',
        success:function (res) {
            if (res.success===1){
                editor.setValue(res.data);
                editor1.setValue(res.data);
            }
        }
    })
}


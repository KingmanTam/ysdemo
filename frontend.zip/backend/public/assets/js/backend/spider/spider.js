
layui.use(function(){
    let curTime = layui.util.toDateString(new Date(), 'yyyy-MM-dd')
    let laydate = layui.laydate;
    laydate.render({
        elem: '#qdate',
        value: curTime,
        isInitValue: true
    });
});

let table = layui.table;

layui.use('table', function(){

    let s_date = $('#qdate').val();
    let inst = table.render({
        elem: '#tb_spider',
        url:'spider/getData',
        where: {'s_date':s_date,'domain':''},
        method:'post',
        cols: [[ //标题栏
            {field: 's_time', title: '日期', width: 200},
            {field: 'domain', title: '域名', width: 150},
            {field: 'ip', title: 'IP', width: 100},
            {field: 'url', title: '路径', width: 400},
            {field: 'status', title: '状态', width: 100},
        ]],
        skin: 'line', // 表格风格
        height: 600,
        //even: true,
        page: true, // 是否显示分页
        limits: [100, 200, 500],
        limit: 100 // 每页默认显示的数量
    });
});
$("#query").click(function() {
    let s_date = $('#qdate').val();
    let domain = $('#domain').val();
    table.reloadData('tb_spider', {
        where:{'s_date':s_date,'domain':domain}
    });
});
$("#delete").click(function() {
    let s_date = $('#qdate').val();
    let domain = $('#domain').val();
    $.ajax({
        type:'post',
        url:'spider/delete',
        data:{'s_date':s_date,'domain':domain},
        dataType:'json',
        success:function (res) {
            table.reloadData('tb_spider', {
                where:{'s_date':s_date,'domain':''}
            });
        }
    })
});

layui.use(function(){
    let curTime = layui.util.toDateString(new Date(), 'yyyy-MM-dd')
    let laydate = layui.laydate;
    laydate.render({
        elem: '#qdate',
        value: curTime,
        isInitValue: true
    });
    laydate.render({
        elem: '#sdate',
        value: curTime,
        isInitValue: true
    });
});

let table = layui.table;

layui.use('table', function(){

    let q_date = $('#qdate').val();
    let siteName = $("#site option:selected").text();
    let inst = table.render({
        elem: '#tb_total',
        url:'total/getReqList',
        where: {'q_date':q_date,'siteName':siteName},
        method:'post',
        cols: [[ //标题栏
            {field: 'time', title: '日期', width: 150},
            {field: 'req', title: '总请求', width: 80},
            {field: 'ip', title: 'IP', width: 80},
            {field: 'length', title: '流量', width: 80},
            {field: 'qps', title: 'REQ/s', width: 80},
            {field: 'baidu', title: '百度', width: 80},
            {field: 'yisou', title: '神马', width: 80},
            {field: 'google', title: '谷歌', width: 80},
            {field: 'bing', title: '必应', width: 80},
            {field: 'qh360', title: '360', width: 80},
            {field: 'bytes', title: '字节', width: 80},
            {field: 'status_200', title: '200', width: 80},
            {field: 'status_301', title: '301', width: 80},
            {field: 'status_other', title: '其他', width: 80}
        ]],
        skin: 'line', // 表格风格
        height: 500,
        //even: true,
        page: false // 是否显示分页
    });
    let spider = table.render({
        elem: '#tb_spider',
        url:'total/getSpiderList',
        where: {'s_date':q_date,'siteName':siteName},
        method:'post',
        cols: [[ //标题栏
            {field: 'time', title: '日期', width: 150},
            {field: 'domain', title: '域名', width: 200},
            {field: 'baidu', title: '百度', width: 100},
            {field: 'google', title: '谷歌', width: 100},
            {field: 'bing', title: '必应', width: 100},
            {field: 'yisou', title: '神马', width: 100},
            {field: 'sogou', title: '搜狗', width: 100},
            {field: 'qh360', title: '360', width: 100},
            {field: 'bytes', title: '字节', width: 100},
        ]],
        skin: 'line', // 表格风格
        height: 500,
        //even: true,
        page: false // 是否显示分页
    });
});
$("#query").click(function() {
    let q_date = $('#qdate').val();
    let siteName = $("#site option:selected").text();
    table.reloadData('tb_total', {
        where:{'q_date':q_date,'siteName':siteName}
    });
});
$("#q_spider").click(function() {
    let s_date = $('#sdate').val();
    let siteName = $("#s_site option:selected").text();
    table.reloadData('tb_spider', {
        where:{'s_date':s_date,'siteName':siteName}
    });
});
<?php

namespace app\api\controller;

use app\common\controller\Api;
use SQLite3;

class Total extends Api
{
    protected $noNeedLogin = ['getReqList', 'getSpiderList','del'];
    protected $noNeedRight = ['getReqList', 'getSpiderList','del'];

    public function getReqList(){
        $result = array();
        $data = array();
        $db_file = APP_PATH.'admin/config/total.db';
        $q_date = $_GET['q_date'];
        $siteName = $_GET['siteName'];
        $where = ' and time=\''.$q_date.'\'';
        if (empty($q_date)){
            $where = '';
        }
        $q_sql = "select * from request_stat where site='".$siteName."'".$where;
        $db = new SQLite3($db_file);
        $res = $db->query($q_sql);
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            array_push($data,$row);
        }
        $result['count'] = 1;
        $result['code'] = 0;
        $result['msg'] = '';
        $db->close();
        $result['data'] = $data;
        exit(json_encode($result));
    }

    public function getSpiderList(){
        $result = array();
        $data = array();
        $db_file = APP_PATH.'admin/config/total.db';
        $s_date = $_GET['s_date'];
        $siteName = $_GET['siteName'];
        $where = ' and time=\''.$s_date.'\'';
        if (empty($s_date)){
            $where = '';
        }
        $q_sql = "select * from spider_stat where site='".$siteName."'".$where;
        $db = new SQLite3($db_file);
        $res = $db->query($q_sql);
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            array_push($data,$row);
        }
        $result['count'] = 1;
        $result['code'] = 0;
        $result['msg'] = '';
        $db->close();
        $result['data'] = $data;
        exit(json_encode($result));
    }

    public function del(){
        $result = array();
        $db_file = APP_PATH.'admin/config/total.db';
        $date = $_GET['date'];
        $siteName = $_GET['siteName'];
        $table = $_GET['table'];
        $where = ' and time=\''.$date.'\'';
        if (empty($s_date)){
            $where = '';
        }
        $del_sql = "delete from ".$table." where site='".$siteName."'".$where;
        $db = new SQLite3($db_file);
        $exec = $db->exec($del_sql);
        $result['res'] = $exec;
        exit(json_encode($result));
    }
}
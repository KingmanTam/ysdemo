<?php

namespace app\api\controller;

use app\common\controller\Api;
use Cassandra\Uuid;
use mysqli;
use PhpOffice\PhpSpreadsheet\Calculation\DateTimeExcel\Time;
use SQLite3;

/**
 * 首页接口
 */
class Index extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 首页
     *
     */
    public function index()
    {
        /*$db_file = APP_PATH.'admin/config/domain.db';
        $domain = $_GET['domain'];
        $db = new SQLite3($db_file);
        $db->exec("insert into domain(id,name,flag) values ('".uniqid()."','".$domain."',0)");
        $this->success('请求成功');*/
        $db_file = APP_PATH.'admin/config/domain.db';
        $nl = $_GET['nl'];
        $gxsj = $_GET['gxsj'];
        $jls = $_GET['jls'];
        $sjmin = $_GET['sj_min'];
        $minTime = strtotime($sjmin);
        if ($minTime<1546272000){
            return;
        }
        $sjmax = $_GET['sj_max'];
        $yy = $_GET['yy'];
        $bt = $_GET['bt'];
        $zt = $_GET['zt'];
        $wz = $_GET['wz'];
        $pf = $_GET['pf'];
        $db = new SQLite3($db_file);
        $sq = "insert into jm(id,nl,gxsj,jls,sj_min,sj_max,yy,bt,zt,wz,pf,addtime) values ('".uniqid()."','".$nl."','".$gxsj."','".$jls."','".$sjmin."','".$sjmax."','".$yy."','".$bt."','".$zt."','".$wz."','".$pf."',".\time().")";
        $db->exec($sq);
        $this->success('请求成功');
    }

    public function baiduAutoCommit(){
        $db_file = APP_PATH.'admin/config/backend.db';
        $db = new SQLite3($db_file);
        $result = $db->query('select * from domain');

        $mysqli = new mysqli('127.0.0.1', 'root', 'root', 'maccms10', '3306');
        $max_result = $mysqli->query('select max(vod_id) as maxid from mac_vod');
        $max_id_res = $max_result->fetch_array(MYSQLI_ASSOC);
        //$max_vod_id = $result['maxid'];
        $max_vod_id = 121050;
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $domain = $row['domain'];
            $inc = $row['inc'];
            $offset = $row['offset'];
            $num = $row['num'];
            $lock = $row['lock'];
            if ($lock == 1) continue;
            $start_id = $max_vod_id - $offset;
            $data_result = $mysqli->query('select * from mac_vod where vod_id>' . $start_id.' order by vod_id asc limit 100');
            $dataList = $data_result->fetch_all(MYSQLI_ASSOC);
            $urls = array();
            foreach ($dataList as $data){
                $vod_id = $data['vod_id']+$inc;
                $url = 'https://'.$domain.'/details/'.dechex($vod_id).'.html';
                //$url = 'https://'.$domain.'/plots/'.dechex($vod_id).'.html';
                array_push($urls,$url);
            }
            $num = $num +1;
            $sendResp = $this->sendToBaidu($urls,$domain);
            $success = 0;
            $remain = 100;
            $message = '';
            if (isset($sendResp['success'])){
                $remain = $sendResp['remain'];
                $success = $sendResp['success'];
            }
            if (isset($sendResp['message'])){
                $message = $sendResp['message'];
            }
            $db->exec('update domain set num = ' . $num .' where id='.$row['id']);
            $values = "'".uniqid(16,true)."','".$domain."',".$num.",".$remain.",".$success.",".\time().",'".$message."'";
            $db->exec('insert into commit_log(id,domain,num,remain,success,update_time,message) values('.$values.')');
        }
    }

    private function sendToBaidu($urls,$domain){
        $api = 'http://data.zz.baidu.com/urls?site={domain}&token=68Lp6zFUL2ChlAHk';
        $api = str_replace('{domain}', $domain,$api);
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return json_decode($result,true);
    }
}

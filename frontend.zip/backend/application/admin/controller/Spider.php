<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use SQLite3;

class Spider extends Backend
{
    public function _initialize()
    {
        parent::_initialize();

        //设置过滤方法
        $this->request->filter(['trim', 'strip_tags', 'htmlspecialchars']);
    }

    /**
     * 查看
     */
    public function index(): string
    {
        //设置过滤方法
        return file_get_contents(APP_PATH.'admin/view/spider/index.html');
    }

    /**
     * 查看
     */
    public function getData()
    {
        $result = array();
        $data = array();
        $db_file = APP_PATH.'admin/config/spider.db';
        $page = $_POST['page'];
        $s_date = $_POST['s_date'];
        $domain = $_POST['domain'];
        $where = '';
        if (!empty($domain)){
            $where = "and domain= '".$domain."'";
        }
        $limit = $_POST['limit'];
        $q_sql = 'select * from spider where s_date=\''.$s_date.'\''.$where.' order by s_time desc limit '.($page-1)*$limit.','.$limit;
        $db = new SQLite3($db_file);
        $res = $db->query($q_sql);
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            $fmt_time = date('Y-m-d,H:i:s',$row['s_time']);
            $row['s_time'] = $fmt_time;
            array_push($data,$row);
        }
        $cres = $db->query('select count(*) as count from spider  where s_date=\''.$s_date.'\''.$where);
        while ($row=$cres->fetchArray(SQLITE3_ASSOC)){
            $result['count'] = $row['count'];
        }
        $result['code'] = 0;
        $result['msg'] = '';
        $db->close();
        $result['data'] = $data;
        exit(json_encode($result));
    }

    public function delete(){
        $result = array();
        $db_file = APP_PATH.'admin/config/spider.db';
        $s_date = $_POST['s_date'];
        $domain = $_POST['domain'];
        $where = '';
        if (!empty($domain)){
            $where = "and domain= '".$domain."'";
        }
        $q_sql = 'delete  from spider where s_date=\''.$s_date.'\''.$where;
        $db = new SQLite3($db_file);
        $b = $db->exec($q_sql);
        $result['res'] = $b;
        exit(json_encode($result));
    }
}
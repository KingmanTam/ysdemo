<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use SQLite3;

class Total extends Backend
{
    public function _initialize()
    {
        parent::_initialize();

        //设置过滤方法
        $this->request->filter(['trim', 'strip_tags', 'htmlspecialchars']);
    }

    /**
     * 查看
     */
    public function index(): string
    {
        //设置过滤方法
        return file_get_contents(APP_PATH.'admin/view/total/index.html');
    }

    public function getReqList(){
        $result = array();
        $data = array();
        $db_file = APP_PATH.'admin/config/total.db';
        $q_date = $_POST['q_date'];
        $siteName = $_POST['siteName'];
        $where = ' and time=\''.$q_date.'\'';
        if (empty($q_date)){
            $where = '';
        }
        $q_sql = "select * from request_stat where site='".$siteName."'".$where;
        $db = new SQLite3($db_file);
        $res = $db->query($q_sql);
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            array_push($data,$row);
        }
        $result['count'] = 1;
        $result['code'] = 0;
        $result['msg'] = '';
        $db->close();
        $result['data'] = $data;
        exit(json_encode($result));
    }

    public function getSpiderList(){
        $result = array();
        $data = array();
        $db_file = APP_PATH.'admin/config/total.db';
        $s_date = $_POST['s_date'];
        $siteName = $_POST['siteName'];
        $where = ' and time=\''.$s_date.'\'';
        if (empty($s_date)){
            $where = '';
        }
        $q_sql = "select * from spider_stat where site='".$siteName."'".$where;
        $db = new SQLite3($db_file);
        $res = $db->query($q_sql);
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            array_push($data,$row);
        }
        $result['count'] = 1;
        $result['code'] = 0;
        $result['msg'] = '';
        $db->close();
        $result['data'] = $data;
        exit(json_encode($result));
    }

}
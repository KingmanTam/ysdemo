<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use SQLite3;

class Jmdomain extends Backend
{
    public function _initialize()
    {
        parent::_initialize();

        //设置过滤方法
        $this->request->filter(['trim', 'strip_tags', 'htmlspecialchars']);
    }

    /**
     * 查看
     */
    public function index(): string
    {
        //设置过滤方法
        return file_get_contents(APP_PATH.'admin/view/jm/index.html');
    }

    /**
     * 查看
     */
    public function getData()
    {
        $result = array();
        $data = array();
        $db_file = APP_PATH.'admin/config/domain.db';
        $page = $_POST['page'];
        $limit = $_POST['limit'];
        $q_sql = 'select * from jm where yy <>\'英文\' order by sj_max desc limit '.($page-1)*$limit.','.$limit;
        $db = new SQLite3($db_file);
        $res = $db->query($q_sql);
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            array_push($data,$row);
        }
        $cres = $db->query('select count(*) as count from jm  where yy <>\'英文\'');
        while ($row=$cres->fetchArray(SQLITE3_ASSOC)){
            $result['count'] = $row['count'];
        }
        $result['code'] = 0;
        $result['msg'] = '';
        $db->close();
        $result['data'] = $data;
        exit(json_encode($result));
    }

    public function save(){
        $result = array();
        $domain = $_GET['domain'];
        $db_file = APP_PATH.'admin/config/domain.db';
        $db = new SQLite3($db_file);
        $b = $db->exec("insert into jmok(id,domain) values ('" . uniqid() . "','" . $domain . "')");
        if ($b){
            $result['code']=1;
        }else{
            $result['code']=0;
        }
        exit(json_encode($result));
    }
}
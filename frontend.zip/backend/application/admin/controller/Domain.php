<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use Exception;
use SQLite3;
use think\cache\driver\Redis;
use think\response\Json;

class Domain extends Backend
{

    protected string $domain_config = APP_PATH.'admin/config/domain.php';
    protected string $keyword_db_file = APP_PATH.'admin/config/keyword.db';
    protected string $backup_db_file = APP_PATH.'admin/config/backup.db';
    protected string $backup_path = APP_PATH.'admin/config/';

    public function _initialize()
    {
        parent::_initialize();

        //设置过滤方法
        $this->request->filter(['trim', 'strip_tags', 'htmlspecialchars']);
    }

    /**
     * 查看
     */
    public function index(): string
    {
        //设置过滤方法
        return file_get_contents(APP_PATH.'admin/view/domain/index.html');
    }

    /**
     * 获取域名配置文件
     */
    public function getDomainContent(): Json
    {
        $result = array();
        $contents = file_get_contents($this->domain_config);
        $result['success'] = 1;
        $result['data'] = $contents;
        return json($result);
    }

    /**
     * 保存
     */
    public function save(): Json
    {
        $result = array();
        try {
            $content = $_POST['content'];
            fwrite(fopen($this->domain_config, 'wb'), $content);
            $result['success'] = 1;
            $this->updateCache();
        } catch (Exception $e) {
            $result['success'] = 0;
        }

        return json($result);
    }

    public function updateCache(){
        $domain_list = include $this->domain_config;
        $redis = new Redis();
        foreach ($domain_list as $k => $v) {
            $redis->set('domain:'.$v['domain'],json_encode($v),60*60*2);
        }
    }
    /**
     * 获取keyword列表
     */
    public function getKeys(): Json
    {
        $result = array();
        $db = new SQLite3($this->keyword_db_file);
        $res = $db->query('select * from t_keyword order by id desc');
        $count = 0;
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $result[$count] = $row;
            $count++;
        }
        $db->close();
        return json($result);
    }

    /**
     * 域名备份列表
     */
    public function getBackupList(): Json
    {
        $db = new SQLite3($this->backup_db_file);
        $result = array();
        $res = $db->query('select * from backup order by updatetime DESC');
        $count = 0;
        while ($row=$res->fetchArray(SQLITE3_ASSOC)){
            $date = $row['updatetime'];
            $row['updatetime'] = date('yy-m-d H:i:s',$date);
            $result[$count] = $row;
            $count++;
        }
        $db->close();
        return json($result);
    }

    /**
     * 域名备份
     */
    public function backup(): Json
    {
        $result = array();
        $name = 'domain' . time();
        $back_file = $this->backup_path. $name . '.php';
        if (copy($this->domain_config, $back_file)) {
            $db = new SQLite3($this->backup_db_file);
            $db->exec("insert into backup(id,name,updatetime) values('" . uniqid('d') . "','" . $name . "'," . time() . ")");
            $result['success'] = 1;
            $db->close();
        } else {
            $result['success'] = 0;
        }
        return json($result);
    }

    /**
     * 添加关键词
     */
    public function addKeyword(): Json
    {
        $result = array();
        $keys = $_POST['keys'];
        $keyArr = explode(chr(10), $keys);
        $db = new SQLite3($this->keyword_db_file);
        $values = '';
        for ($j = 0; $j < count($keyArr); $j++) {
            $key = $keyArr[$j];
            if (!empty($key)){
                $values = $values . '(\'' . uniqid() . '\',\'' . $key . '\'),';
            }
        }
        $values = substr($values, 0, strlen($values) - 1);
        $insert_sql = 'insert into t_keyword(id,keyword) values' . $values;
        $db->exec($insert_sql);
        $db->close();
        $result['success'] = 1;
        return json($result);
    }

    /**
     * 删除关键词
     */
    public function delKeyword(): Json
    {
        $result = array();
        try {
            $id = $_POST['id'];
            $db = new SQLite3($this->keyword_db_file);
            $b = $db->exec('delete from t_keyword where id=\'' . $id . '\'');
            if ($b) {
                $result['success'] = 1;
            } else {
                $result['success'] = 0;
            }
            $db->close();
        } catch (Exception $e) {
            $result['success'] = 0;
        }
        return json($result);
    }

    /**
     * 域名配置文件回滚
     */
    public function rollback(): Json
    {
        $result = array();
        $file_name = $_POST['name'];
        $file_path = $this->backup_path.$file_name.'.php';
        $res = file_get_contents($file_path);
        fwrite(fopen($this->domain_config, 'wb'), $res);
        $result['success'] = 1;
        $result['data'] = $res;
        $this->updateCache();
        return json($result);
    }

    /**
     * 删除域名配置文件备份
     */
    public function delBackup(): Json
    {
        $result = array();
        $backupId = $_POST['id'];
        $db = new SQLite3($this->backup_db_file);
        $b = $db->exec('delete from backup where id=\'' . $backupId . '\'');
        if ($b) {
            $result['success'] = 1;
        } else {
            $result['success'] = 0;
        }
        $db->close();
        return json($result);
    }

    /**
     * 域名标题修改
     */
    public function restTitle(): Json
    {
        $result = array();
        $domains = $_POST['domains'];
        $keyNum = $_POST['keyNum'];
        $linkChar = $_POST['linkChar'];
        $restDomainList = explode(chr(10), $domains);
        $db = new SQLite3($this->keyword_db_file);
        $keywordArr = array();
        $restDomainArr = array();
        $domainTemp = array();
        $res = $db->query('select * from t_keyword');
        $count = 0;
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $keywordArr[$count] = $row['keyword'];
            $count++;
        }
        for ($i = 0; $i < count($restDomainList); $i++) {
            $domain = $restDomainList[$i];
            $restDomainArr[$domain] = $domain;
        }
        $keysTotal = count($keywordArr);
        $pro_domain_list = include $this->domain_config;
        foreach ($pro_domain_list as $k => $v) {
            if (!empty($restDomainArr[$v['domain']])) {
                $keywordTempArr = array();
                $flag = true;
                while ($flag){
                    $numArr = array();
                    for ($k = 0; $k < $keyNum; $k++) {
                        $r = mt_rand(0, $keysTotal);
                        array_push($numArr,$r);
                    }
                    if (count($numArr) == count(array_unique($numArr))){
                        for ($k = 0; $k < count($numArr); $k++) {
                            $keyword = $keywordArr[$numArr[$k]];
                            array_push($keywordTempArr, $keyword);
                        }
                        $flag = false;
                    }
                }
                $title = join($linkChar, $keywordTempArr);
                $domainTemp[$v['domain']] = array(
                    'domain' => $v['domain'],
                    'title' => $title,
                    'keywords' => '',
                    'description' => $title,
                    'template' => $v['template'],
                    'name' => $v['name'],
                    'rute' => $v['rute'],
                    'rute_detail' => $v['rute_detail'],
                    'rute_play' => $v['rute_play'],
                    'rute_type' => $v['rute_type'],
                    'offset' => $v['offset'],
                );
            } else {
                $domainTemp[$v['domain']] = array(
                    'domain' => $v['domain'],
                    'title' => $v['title'],
                    'keywords' => '',
                    'description' => $v['description'],
                    'template' => $v['template'],
                    'name' => $v['name'],
                    'rute' => $v['rute'],
                    'rute_detail' => $v['rute_detail'],
                    'rute_play' => $v['rute_play'],
                    'rute_type' => $v['rute_type'],
                    'offset' => $v['offset'],
                );
            }
        }
        $result['success'] = 1;
        $domainstr = '<?php' . chr(10) . 'return ' . var_export($domainTemp, true) . ';' . chr(10) . '?>';
        fwrite(fopen($this->domain_config, 'wb'), $domainstr);
        if ($res) {
            $result['success'] = 1;
            $result['data'] = $domainstr;
        }
        $this->updateCache();
        return json($result);
    }

    public function getRute(){
        $chars = 'abcdefghijklmnopqrstuvwxyz';
        $classArr = '';
        for ( $j = 0; $j < 3; $j++ ) {
            $classArr = $classArr.$chars[ mt_rand(0, strlen($chars) - 1)];
        }
        return $classArr;
    }

    public function getPlay(){
        $chars = 'abcdefghijklmnopqrstuvwxyz';
        $classArr = '';
        for ( $j = 0; $j < 4; $j++ ) {
            $classArr = $classArr.$chars[ mt_rand(0, strlen($chars) - 1)];
        }
        return $classArr;
    }

}
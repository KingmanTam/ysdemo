keyTable = $("#keytable");
rollTable = $("#table");
var editor = ace.edit("editor", {
    theme: "ace/theme/monokai",
    mode: "ace/mode/php",
    maxLines: 40,
    minLines:40,
    autoScrollEditorIntoView: true
});
var editor1 = ace.edit("editor1", {
    theme: "ace/theme/monokai",
    mode: "ace/mode/php",
    maxLines: 40,
    minLines:40,
    autoScrollEditorIntoView: true
});

$(function (){
    initValue();
    initBack();
    initKeyword()
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "2000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
})
function initKeyword(){
    keyTable.bootstrapTable({
        url: 'domain/getKeys',                    // URL
        method:'get',
        dataType: "json",                                        // 请求类型
        showRefresh: false,                                    // 是否刷新按钮
        sortStable: true,                                      // 是否支持排序
        cache: false,                                          // 是否使用缓存
        search: false,
        pageNumber : 1, //初始化加载第一页
        sidePagination : 'client',
        pagination : true,//是否分页
        queryParamsType: "",
        pageSize : 5,//单页记录数
        columns: [
            {field: 'id',width:50,title: 'id',align: "left",halign: "center",sortable: true},
            {field: 'keyword',width:150,title: '关键词',align: "left",halign: "center",sortable: true,cellStyle: formatTableUnit,formatter:paramsMatter},
            {field: 'operate',width:50,title: '操作',align: "left",halign: "center",formatter:optFormatter,events:optEvents}
        ]
    })
}

function initBack(){
    rollTable.bootstrapTable({
        url: 'domain/getBackupList',                    // URL
        method: 'get',
        dataType: "json",                                        // 请求类型
        showRefresh: false,                                    // 是否刷新按钮
        sortStable: true,                                      // 是否支持排序
        cache: false,                                          // 是否使用缓存
        search: false,
        queryParamsType: "",
        pageNumber : 1, //初始化加载第一页
        sidePagination : 'client',
        pagination : true,//是否分页
        pageSize : 5,//单页记录数
        columns: [
            {field: 'id',width:20,title: 'id',align: "left",visible:false,sortable: true},
            {field: 'updatetime',width:100,title: '时间',align: "left",halign: "center",sortable: true},
            {field: 'name',width:100,title: '名称',align: "left",halign: "center"},
            {field: 'operate',width:50,title: '操作',align: "left",halign: "center",formatter:operateFormatter,events:operateEvents}
        ]
    })
}
function paramsMatter(value, row, index) {
    var span = document.createElement("span");
    span.setAttribute("title", value);
    span.innerHTML = value;
    return span.outerHTML;
}
function formatTableUnit(value, row, index) {
    return {
        css: {
            "white-space": "nowrap",
            "text-overflow": "ellipsis",
            "overflow": "hidden",
            "max-width": "60px"
        }
    }
}
function initValue(){
    $.ajax({
        type:'get',
        url:'domain/getDomainContent',
        dataType:'json',
        success:function (res) {
            if (res.success===1){
                editor.setValue(res.data);
                editor1.setValue(res.data);
            }
        }
    })
}

$("#backup").click(function() {
    $.ajax({
        type:'get',
        url:"domain/backup",
        dataType:'json',
        success:function (res) {
            if (res.success===1){
                toastr.success("备份成功!");
            }else {
                toastr.error("备份失败!");
            }
        }
    })
});

$("#titleBtn").click(function() {
    $('#restTitleModal').modal('show');
});

$("#restTitle").click(function() {
    let domains = $('#domains').val();
    let linkChar = $('#linkChar').val();
    let keyNum = $('#keyNum').val();
    $.ajax({
        type:'post',
        url:"domain/restTitle",
        data:{domains:domains,linkChar:linkChar,keyNum:keyNum},
        dataType:'json',
        success:function (res) {
            if (res.success===1){
                console.log(res.data);
                editor.setValue(res.data);
                toastr.success("更改成功!");
            }else {
                toastr.error("更改失败!");
            }
        }
    })
});

function optFormatter(value, row, index) {
    return [
        '<a id="keyOpt" href="javascript:void(0)" title="Like">',
        '删除',
        '</a>  '
    ].join('')
}
window.optEvents = {
    'click #keyOpt': function (e, value, row, index) {
        let id = row['id']
        $.ajax({
            type:'post',
            url:'domain/delKeyword',
            data:{id:id},
            dataType:'json',
            success:function (res) {
                if (res.success===1){
                    toastr.success("删除成功!");
                    keyTable.bootstrapTable(('refresh'));
                }else {
                    toastr.error("删除失败!");
                }
            }
        })
    }
}

$("#addKey").click(function() {
    let keys = $('#keys').val();
    $.ajax({
        type:'post',
        url:"domain/addKeyword",
        data:{keys:keys},
        dataType:'json',
        success:function (res) {
            keyTable.bootstrapTable(('refresh'));
            if (res.success===1){
                toastr.success("添加成功!");
            }else {
                toastr.error("添加失败!");
            }
        }
    })
});

$("#rollback").click(function() {
    rollTable.bootstrapTable(('refresh'));
    $('#rollbackModal').modal('show');
});
$("#spider").click(function() {
    window.location.href='?m=extend-monitor';
});

$("#keyword").click(function() {
    $('#keykModal').modal('show');
});

$("#delCache").click(function() {
    $.ajax({
        type:'get',
        url:"?m=extend-delCache",
        dataType:'json',
        success:function (res) {
            document.getElementById('content').innerHTML = '';
            if (res.success===1){
                toastr.success("删除成功!");
            }else {
                toastr.error("删除失败!");
            }
        }
    })
});

$("#save").click(function() {
    let content = editor.getValue();
    $.ajax({
        type:'post',
        url:'domain/save',
        data:{content:content},
        dataType:'json',
        success:function (res) {
            if (res.success===1){
                toastr.success("保存成功!");
            }else {
                toastr.error("保存失败!");
            }
        }
    })
});

function operateFormatter(value, row, index) {
    return [
        '<a id="backOpt" href="javascript:void(0)" title="Like">',
        '回滚',
        '</a>  ',
        '<a id="backRemove" href="javascript:void(0)" title="Remove">',
        '删除',
        '</a>'
    ].join('')
}

window.operateEvents = {
    'click #backOpt': function (e, value, row, index) {
        var name = row['name']
        $.ajax({
            type:'post',
            url:'domain/rollback',
            data:{name:name},
            dataType:'json',
            success:function (res) {
                if (res.success===1){
                    toastr.success("回滚成功!");
                    editor.setValue(res.data);
                    editor1.setValue(res.data);
                }else {
                    toastr.error("回滚失败!");
                }
            }
        })
    },
    'click #backRemove': function (e, value, row, index) {
        var id = row['id']
        $.ajax({
            type:'post',
            url:'domain/delBackup',
            data:{id:id},
            dataType:'json',
            success:function (res) {
                console.log(res)
                if (res.success===1){
                    toastr.success("删除成功!");
                    rollTable.bootstrapTable(('refresh'));
                }else {
                    toastr.error("删除失败!");
                }
            }
        })
    }
}


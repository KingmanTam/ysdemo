<?php
$strtotime = strtotime('2019-01-01');
print($strtotime);
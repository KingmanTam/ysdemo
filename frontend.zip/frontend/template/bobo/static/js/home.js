function pagego($url,$total){
    $page=$('#page').val();
    if($page>0&&($page<=$total)){
        $url=$url.replace('{pg}',$page);
        location.href=$url;
    }
    return false;
}
$(function (){
    $("#search").click(function() {
        let val = $('#wd').val();

        if (val == undefined || val==''){
            val = '*';
        }
        window.location.href='/index.php?m=search-pg-1-wd-'+val+'.html';
    });
})
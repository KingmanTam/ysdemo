﻿var mac_flag=1;         //播放器版本
var mac_second=5;       //播放前预加载广告时间 1000表示1秒
var mac_width=0;      //播放器宽度0自适应
var mac_height=600;     //播放器高度
var mac_widthmob=0;      //手机播放器宽度0自适应
var mac_heightmob=400;     //手机播放器高度
var mac_widthpop=704;   //弹窗窗口宽度
var mac_heightpop=560;  //弹窗窗口高度
var mac_showtop=0;     //美化版播放器是否显示头部
var mac_showlist=0;     //美化版播放器是否显示列表
var mac_autofull=0;     //是否自动全屏,0否,1是
var mac_buffer="/player/loading.html";     //缓冲广告地址
var mac_prestrain="/player/prestrain.html";  //预加载提示地址
var mac_parse="";  //接口地址
var mac_colors="000000,F6F6F6,F6F6F6,333333,666666,FFFFF,FF0000,2c2c2c,ffffff,a3a3a3,2c2c2c,adadad,adadad,48486c,fcfcfc";   //背景色，文字颜色，链接颜色，分组标题背景色，分组标题颜色，当前分组标题颜色，当前集数颜色，集数列表滚动条凸出部分的颜色，滚动条上下按钮上三角箭头的颜色，滚动条的背景颜色，滚动条空白部分的颜色，滚动条立体滚动条阴影的颜色 ，滚动条亮边的颜色，滚动条强阴影的颜色，滚动条的基本颜色
//缓存开始
var mac_play_list={"ytm3u8":{"status":1,"sort":9999,"show":"\u7389\u5154\u8d44\u6e90\u64ad\u653e\u5668","des":"yutuzy.com","ps":"","parse":"","tip":""},"swm3u8":{"status":1,"sort":999,"show":"\u8272\u7a9dm3u8","des":"www.sewozy.com","ps":"","parse":"","tip":""},"lym3u8":{"status":1,"sort":985,"show":"\u8001\u9e2d\u8d44\u6e90","des":"www.laoyazy.com","ps":"0","parse":"","tip":""},"ykm3u8":{"status":1,"sort":968,"show":"\u5f71\u5e93","des":"http:\/\/jx.ykyunbo.com","ps":"0","parse":"","tip":"\u5f71\u5e93"},"ptzy":{"status":1,"sort":909,"show":"pt\u64ad\u53d1\u5668","des":"https:\/\/jiexi.putaozy.net","ps":"0","parse":"","tip":"\u5728\u7ebf\u64ad\u653e,\u65e0\u9700\u5b89\u88c5\u64ad\u653e\u5668"},"videojs":{"status":0,"sort":907,"show":"Videojs\u3010\u7981\u7528\u3011","des":"videojs.com","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"iva":{"status":0,"sort":906,"show":"iva\u3010\u7981\u7528\u3011","des":"videojj.com","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"iframe":{"status":0,"sort":905,"show":"iframe\u5916\u94fe\u6570\u636e\u3010\u7981\u7528\u3011","des":"iframe\u5d4c\u5165","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"link":{"status":0,"sort":904,"show":"\u5916\u94fe\u6570\u636e\u3010\u7981\u7528\u3011","des":"\u5916\u90e8\u7f51\u7ad9\u64ad\u653e\u94fe\u63a5","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"swf":{"status":0,"sort":903,"show":"Flash\u6587\u4ef6\u3010\u7981\u7528\u3011","des":"swf","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"flv":{"status":0,"sort":902,"show":"flv\u6587\u4ef6\u3010\u7981\u7528\u3011","des":"flv","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"ckplayer":{"status":1,"sort":490,"show":"ckplayer","des":"http:\/\/www.ckplayer.com\/","ps":"0","parse":"","tip":""},"ttm3u8":{"status":1,"sort":99,"show":"\u63a2\u63a2\u64ad\u653e\u5668","des":"tantanzy1.com","ps":"","parse":"","tip":""},"dplayer":{"status":0,"sort":2,"show":"DPlayer_H5\u64ad\u653e\u5668\u3010\u7981\u7528\u3011","des":"dplayer.js.org","ps":"0","parse":"","tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"lbm3u8":{"status":0,"sort":1,"show":"\u4e50\u64ad\u8d44\u6e90\u3010\u7981\u7528\u3011","des":"https:\/\/www.lebozy.com\/","ps":"0","parse":"","tip":"\u5728\u7ebf\u64ad\u653e,\u65e0\u9700\u5b89\u88c5\u64ad\u653e\u5668"},"lajiao":{"status":1,"sort":1,"show":"\u8fa3\u6912\u8d44\u6e90","des":"https:\/\/www.lajiaozy.com\/","ps":"0","parse":"","tip":"\u5728\u7ebf\u64ad\u653e,\u65e0\u9700\u5b89\u88c5\u64ad\u653e\u5668"},"aosika":{"status":1,"sort":1,"show":"\u5965\u65af\u5361\u8d44\u6e90","des":"https:\/\/aosikazy.com\/","ps":"","parse":"","tip":"\u5728\u7ebf\u64ad\u653e,\u65e0\u9700\u5b89\u88c5\u64ad\u653e\u5668"}};var mac_down_list={"http":{"status":1,"sort":190,"show":"HTTP\u4e0b\u8f7d","des":"","ps":null,"parse":null,"tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"ftp":{"status":1,"sort":180,"show":"FTP\u4e0b\u8f7d","des":"","ps":null,"parse":null,"tip":"\u65e0\u9700\u5b89\u88c5\u4efb\u4f55\u63d2\u4ef6"},"xunlei":{"status":1,"sort":90,"show":"\u8fc5\u96f7\u4e0b\u8f7d","des":"xunlei.com","ps":null,"parse":null,"tip":"\u9700\u8981\u5b89\u88c5\u8fc5\u96f7\u4e0b\u8f7d\u5de5\u5177"},"kuaiche":{"status":1,"sort":80,"show":"\u5feb\u8f66\u4e0b\u8f7d","des":"kuaiche.com","ps":null,"parse":null,"tip":"\u9700\u8981\u5b89\u88c5\u5feb\u8f66\u4e0b\u8f7d\u529f\u80fd"},"bt":{"status":1,"sort":70,"show":"BT\u4e0b\u8f7d","des":"bt.com","ps":null,"parse":null,"tip":"\u9700\u8981\u5b89\u88c5BT\u4e0b\u8f7d\u5de5\u5177"}};var mac_server_list={"webplay":{"status":1,"sort":1,"show":"\u8fdc\u53e4\u670d\u52a1\u5668","des":"maccmsc.com","ps":null,"parse":null,"tip":"\u8fdc\u53e4\u670d\u52a1\u566822"}};
//缓存结束

var killErrors=function(value){return true};window.onerror=null;window.onerror=killErrors;
window.onresize=function(){if(window.name=="macopen1"){MacPlayer.Width=$(window).width()-$(".MacPlayer").offset().left-15;MacPlayer.HeightAll=$(window).height()-$(".MacPlayer").offset().top-15;MacPlayer.Height=MacPlayer.HeightAll;if(mac_showtop==1){MacPlayer.Height-=20}$(".MacPlayer").width(MacPlayer.Width);$(".MacPlayer").height(MacPlayer.HeightAll);$("#buffer").width(MacPlayer.Width);$("#buffer").height(MacPlayer.HeightAll);$("#Player").width(MacPlayer.Width);$("#Player").height(MacPlayer.Height)}};
var MacPlayer = {
    'GoPreUrl': function() {
        if (this.Num > 0) {
            this.Go(this.Src + 1, this.Num)
        }
    },
    'GetPreUrl': function() {
        return this.Num > 0 ? this.GetUrl(this.Src + 1, this.Num) : ''
    },
    'GoNextUrl': function() {
        if (this.Num + 1 != this.PlayUrlLen) {
            this.Go(this.Src + 1, this.Num + 2)
        }
    },
    'GetNextUrl': function() {
        return this.Num + 1 <= this.PlayUrlLen ? this.GetUrl(this.Src + 1, this.Num + 2) : ''
    },
    'GetUrl': function(s, n) {
        return mac_link.replace('{src}', s).replace('{src}', s).replace('{num}', n).replace('{num}', n)
    },
    'Go': function(s, n) {
        location.href = this.GetUrl(s, n)
    },
    'GetList': function() {
        this.RightList = '';
        for (i = 0; i < this.Data.from.length; i++) {
            from = this.Data.from[i];
            url = this.Data.url[i];
            listr = "";
            sid_on = 'h2';
            sub_on = 'none';
            urlarr = url.split('#');
            for (j = 0; j < urlarr.length; j++) {
                urlinfo = urlarr[j].split('$');
                name = '';
                url = '';
                list_on = '';
                from1 = '';
                if (urlinfo.length > 1) {
                    name = urlinfo[0];
                    url = urlinfo[1];
                    if (urlinfo.length > 2) {
                        from1 = urlinfo[2]
                    }
                } else {
                    name = "第" + (j + 1) + "集";
                    url = urlinfo[0]
                }
                if (this.Src == i && this.Num == j) {
                    sid_on = 'h2_on';
                    sub_on = 'block';
                    list_on = "list_on";
                    this.PlayUrlLen = urlarr.length;
                    this.PlayUrl = url;
                    this.PlayName = name;
                    if (from1 != '') {
                        this.PlayFrom = from1
                    }
                    if (j < urlarr.length - 1) {
                        urlinfo = urlarr[j + 1].split('$');
                        if (urlinfo.length > 1) {
                            name1 = urlinfo[0];
                            url1 = urlinfo[1]
                        } else {
                            name1 = "第" + (j + 1) + "集";
                            url1 = urlinfo[0]
                        }
                        this.PlayUrl1 = url1;
                        this.PalyName1 = name1
                    }
                }
                listr += '<li></li>'
            }
            this.RightList += '<div ></div>'
        }
    },
    'ShowList': function() {
        $('#playright').toggle()
    },
    'Tabs': function(a, n) {
        var b = $('#sub' + a).css('display');
        for (var i = 0; i <= n; i++) {
            $('#main' + i).attr('className', 'h2');
            $('#sub' + i).hide()
        }
        if (b == 'none') {
            $('#sub' + a).show();
            $('#main' + a).attr('className', 'h2_on')
        } else {
            $('#sub' + a).hide()
        }
    },
    'Show': function() {
        if (mac_showtop == 0) {
            $("#playtop").hide()
        }
        if (mac_showlist == 0) {
            $("#playright").hide()
        }
        setTimeout(function() {
            MacPlayer.AdsEnd()
        }, this.Second * 1000);
        $("#topdes").get(0).innerHTML = '' + '正在播放：第一集';
        $("#playright").get(0).innerHTML = '<div class="rightlist" id="rightlist" style="height:' + this.Height + 'px;">' + this.RightList + '</div>';
        $("#playleft").get(0).innerHTML = this.Html + '';
    },
    'ShowBuffer': function() {
        var w = this.Width - 100;
        var h = this.Height - 100;
        var l = (this.Width - w) / 2;
        var t = (this.Height - h) / 2 + 20;
        $(".MacBuffer").css({
            'width': w,
            'height': h,
            'left': l,
            'top': t
        });
        $(".MacBuffer").toggle()
    },
    'AdsEnd': function() {
        $('#buffer').hide()
    },
    'Install': function() {
        this.Status = false;
        $('#install').parent().show();
        $('#install').show()
    },
    'Play': function() {
        var a = mac_colors.split(',');
        document.write('<style>.MacPlayer{background: #' + a[0] + ';font-size:14px;color:#' + a[1] + ';margin:0px;padding:0px;position:relative;overflow:hidden;width:100%px;height:' + this.HeightAll + 'px;}.MacPlayer a{color:#' + a[2] + ';text-decoration:none}a:hover{text-decoration: underline;}.MacPlayer a:active{text-decoration: none;}.MacPlayer table{width:100%;height:100%;}.MacPlayer ul,li,h2{ margin:0px; padding:0px; list-style:none}.MacPlayer #playtop{text-align:center;height:20px; line-height:21px;font-size:12px;}.MacPlayer #topleft{width:150px;}.MacPlayer #topright{width:100px;} .MacPlayer #topleft{text-align:left;padding-left:5px}.MacPlayer #topright{text-align:right;padding-right:5px}.MacPlayer #playleft{width:100%;height:100%;overflow:hidden;}.MacPlayer #playright{height:100%;overflow-y:auto;}.MacPlayer #rightlist{width:120px;overflow:auto;scrollbar-face-color:#' + a[7] + ';scrollbar-arrow-color:#' + a[8] + ';scrollbar-track-color: #' + a[9] + ';scrollbar-highlight-color:#' + a[10] + ';scrollbar-shadow-color: #' + a[11] + ';scrollbar-3dlight-color:#' + a[12] + ';scrollbar-darkshadow-color:#' + a[13] + ';scrollbar-base-color:#' + a[14] + ';}.MacPlayer #rightlist ul{ clear:both; margin:5px 0px}.MacPlayer #rightlist li{ height:21px; line-height:21px;overflow: hidden; text-overflow: ellipsis; white-space: nowrap;}.MacPlayer #rightlist li a{padding-left:15px; display:block; font-size:12px}.MacPlayer #rightlist h2{ cursor:pointer;font-size:13px;font-family: "宋体";font-weight:normal;height:25px;line-height:25px;background:#' + a[3] + ';padding-left:5px; margin-bottom:1px}.MacPlayer #rightlist .h2{color:#' + a[4] + '}.MacPlayer #rightlist .h2_on{color:#' + a[5] + '}.MacPlayer #rightlist .ul_on{display:block}.MacPlayer #rightlist .list_on{color:#' + a[6] + '} </style><div class="MacPlayer"><table border="0" cellpadding="0" cellspacing="0"><tr><td colspan="2"><table border="0" cellpadding="0" cellspacing="0" id="playtop"><tr><td width="100" id="topleft"><a target="_self" href="javascript:void(0)" onclick="MacPlayer.GoPreUrl();return false;">上一集</a> <a target="_self" href="javascript:void(0)" onclick="MacPlayer.GoNextUrl();return false;">下一集</a></td><td id="topcc"><div id="topdes" style="height:26px;line-height:26px;overflow:hidden"></div></td><td width="100" id="topright"><a target="_self" href="javascript:void(0)" onClick="MacPlayer.ShowList();return false;">开/关列表</a></td></tr></table></td></tr><tr style="display:none"><td colspan="2" id="install" style="display:none"></td></tr><tr><td id="playleft" valign="top">&nbsp;</td><td id="playright" valign="top">&nbsp;</td></tr></table></div>');
        document.write('<script src="/template/bobo/static/js/dplayer.js"></script>')
    },
    'Down': function() {},
    'Init': function() {
        this.Status = true;
        this.Url = location.href;
        this.Par = location.search;
        console.log(11111)
        console.log(mac_from)
        console.log(mac_urlx10d26)
        this.Data = {
            'from': mac_from.split('$$$'),
            'server': 0,
            'url': mac_urlx10d26.split('$$$')
        };
        this.Width = window.name == 'macopen1' ? mac_widthpop : mac_width;
        this.HeightAll = window.name == 'macopen1' ? mac_heightpop : mac_height;
        this.Height = this.HeightAll;
        if (mac_showtop == 1) {
            this.Height -= 20
        }
        if (this.Url.indexOf('#') > -1) {
            this.Url = this.Url.substr(0, this.Url.indexOf('#'))
        }
        console.log(this.Data.url)
        console.log(this.Data.url[0].indexOf("$"))
        if (this.Data.url[0].indexOf("$")>-1){
            var playurls = this.Data.url[0].split('$')
            MacPlayer.PlayUrl = playurls[1];
        }else {
            MacPlayer.PlayUrl = this.Data.url[0];
        }
        this.Prestrain = mac_prestrain;
        this.Buffer = mac_buffer;
        this.Second = mac_second;
        this.Flag = mac_flag;
        var a = this.Url.match(/\d+.*/g)[0].match(/\d+/g);
        var b = a.length;
        this.Id = a[(b - 3)] * 1;
        this.Src = a[(b - 2)] * 1 - 1;
        this.Num = a[(b - 1)] * 1 - 1;
        this.PlayFrom = this.Data.from[0];
        this.PlayServer = '';
        this.PlayNote = '';
        //this.GetList();
        //this.NextUrl = this.GetNextUrl();
        //this.PreUrl = this.GetPreUrl();
        this.Path = '/template/bobo/static/';
        MacPlayer.Play()
    }
};

MacPlayer.Init();
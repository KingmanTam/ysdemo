<?php

class InitDomainInfo
{

    public static function init(): void
    {
        $domain_file = 'app/config/domain.php';
        $domain_list = array();
        if(file_exists($domain_file)){
            $domain_list = include $domain_file;
        }
        foreach ($domain_list as $k=>$v){
            Cache::set('domain:'.$k,json_encode($v));
        }
    }
}
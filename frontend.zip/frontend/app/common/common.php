<?php
require 'app/core/Db.php';
class common
{
    public static function execTime(): float
    {
        $time = explode(" ", microtime());
        $usec = (double)$time[0];
        $sec = (double)$time[1];
        return $sec + $usec;
    }

    public static function validUrl(): bool
    {
        try {
            $m = '';
            if (isset($_GET['m'])){
                $m =  $_GET['m'];
            }
            if (empty($m)){
                app::$method = 'index';
                return app::$valid_url;
            }
            $match_search = preg_match('/search-pg-[0-9]*-wd.*html/',$m);
            if ($match_search){
                $params = explode('-', $m);
                app::$page = $params[2];
                app::$method = 'search';
                app::$searchKey = str_replace('.html','',$params[4]);
                return true;
            }
            $params = explode('/', $m);

            if ($params[1] != app::$domain['rute']) {
                return false;
            }
            switch ($params[2]) {
                case app::$domain['rute_detail']:
                    $p2 = $params[3];
                    $id = strstr($p2, '.', true);
                    if (!is_numeric($id)) {
                        app::$valid_url = false;
                        break;
                    }
                    app::$id = $id;
                    app::$method = 'detail';
                    break;
                case app::$domain['rute_play']:
                    $p2 = $params[3];
                    $id = strstr($p2, '.', true);
                    $is_numeric = is_numeric($id);
                    if (!$is_numeric) {
                        app::$valid_url = false;
                        break;
                    }
                    app::$id = $id;
                    app::$method = 'play';

                    break;
                case app::$domain['rute_type']:
                    $p2 = $params[3];
                    $p3 = $params[4];
                    $pg = strstr($p3, '.', true);
                    if (!(is_numeric($p2) && is_numeric($pg))) {
                        app::$valid_url = false;
                        break;
                    }
                    app::$page = $pg;
                    app::$typeId = $p2;
                    app::$method = 'type';
                    break;
                default:
                    app::$valid_url = false;
            }
        } catch (Exception $e) {
            app::$valid_url = false;
        }

        return app::$valid_url;
    }

    public static function getItemType(): array
    {
        return array(
            1 => '自拍偷拍',
            2 => '国产主播',
            3 => '原创传媒',
            4 => '精品三级',
            5 => '无码专区',
            6 => '有码视频',
            7 => '韩国精品',
            8 => '国产精品',
            9 => '同性系列',
            10 => '欧美精品',
            11 => '卡通动漫',
            12 => '童颜巨乳',
            13 => '重咸口味',
            14 => '中文字幕',
            15 => '制服丝袜',
            16 => '亚洲精品'
        );
    }

    public static function getReqDomain($HTTP_HOST){
        if(str_contains($HTTP_HOST, 'www.')){
            return str_replace('www.', '' ,$_SERVER['HTTP_HOST']);
        }
        return $HTTP_HOST;
    }

    public static function isSpider(): int
    {
        $ip = self::getIP();
        $key = 'as:'.$ip;
        $ip = Cache::get($key);
        if (!empty($ip)){
            return 1;
        }
        $spiders = array(
            '360Spider',
            'Googlebot',
            'SogouSpider',
            'bingbot',
            'bytespider',
            'Baiduspider',
            'YisouSpider'
        );
        if(!empty($ua)){
            foreach ($spiders as $spider) {
                if (stripos($ua, $spider) !== false) {
                    return 1;
                }
            }
        }
        return 0;
    }

    public static function getIP(): string
    {
        $ip = '';
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $pos = array_search('unknown', $arr);
            if (false !== $pos) {
                unset($arr[$pos]);
            }
            $ip = trim(current($arr));
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        // IP地址合法验证
        $long = sprintf("%u", ip2long($ip));
        return $long ? $ip : '0.0.0.0';
    }

    public static function getMillisecond(): string
    {
        list($mse, $sec) = explode(' ', microtime());
        $mse_time =  (float)sprintf('%.0f', (floatval($mse) + floatval($sec)) * 1000);
        return substr($mse_time,0,13);
    }
}
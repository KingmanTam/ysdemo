<?php
set_exception_handler(['AppExceptionHandler','AppExceptionHandle']);

//自定义异常处理函数
class AppExceptionHandler
{
    public static function AppExceptionHandle(Throwable $throwable): void
    {
        if($throwable instanceof AppException){
            echo 'AppException '.$throwable->getMessage();
        }
    }
}

//自定义异常
class AppException extends Exception
{

}

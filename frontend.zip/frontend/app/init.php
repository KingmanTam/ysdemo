<?php
require 'common/AppException.php';
require 'config/App.php';
require 'common/common.php';

@header('Content-Type:text/html;Charset=utf-8');
@date_default_timezone_set('Etc/GMT-8');
define('CHO_ROOT', substr(__FILE__, 0, -13));
@ini_set('display_errors','On');
@error_reporting(1);
@ob_start();
define('MAC_TSP',date('Ymd'));
define('START_TIME',common::getMillisecond());
app::$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
app::$domain['domain'] = common::getReqDomain($_SERVER['HTTP_HOST']);
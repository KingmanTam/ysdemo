<?php

class AppService
{
    public static function loadHtml($type): void
    {
        $key = '';
        switch ($type){
            case 'index':
                $key = 'bb_index';
                break;
            case 'detail':
                $key = 'bb_detail';
                break;
            case 'play':
                $key = 'bb_play';
                break;
            case 'type':
                $key = 'bb_type';
                break;
            case 'search':
                $key = 'bb_search';
                break;
            case 'error':
                $key = 'bb_error';
                break;
        }
        $content = Cache::get($key);
        if (empty($content)){
            switch ($type){
                case 'index':
                    $content = file_get_contents('template/bobo/html/index.html');
                    Cache::set($key,$content,app::$redis['timeout']);
                    break;
                case 'detail':
                    $content = file_get_contents('template/bobo/html/detail.html');
                    Cache::set($key,$content,app::$redis['timeout']);
                    break;
                case 'play':
                    $content = file_get_contents('template/bobo/html/play.html');
                    Cache::set($key,$content,app::$redis['timeout']);
                    break;
                case 'type':
                    $content = file_get_contents('template/bobo/html/type.html');
                    Cache::set($key,$content,app::$redis['timeout']);
                    break;
                case 'search':
                    $content = file_get_contents('template/bobo/html/search.html');
                    Cache::set($key,$content,app::$redis['timeout']);
                    break;
                case 'error':
                    $content = file_get_contents('template/bobo/html/error.html');
                    Cache::set($key,$content,app::$redis['timeout']);
                    break;

            }
        }
        app::$content = $content;
    }

    public static function setCommon(): void
    {
        self::setInclude();
        app::$content = str_replace('{bb:title}', app::$domain['title'],app::$content);
        app::$content = str_replace('{bb:name}', app::$domain['name'],app::$content);
        app::$content = str_replace('{bb:domain}', app::$domain['domain'],app::$content);
    }

    public static function setError(): void
    {
        app::$content = str_replace('{bb:title}', app::$domain['title'],app::$content);
        app::$content = str_replace('{bb:error}', app::$error,app::$content);
        app::$content = str_replace('{bb:name}', app::$domain['name'],app::$content);
    }

    /**
     * @throws AppException
     */
    public static function setDetail(): void
    {
        $item = Cache::get('item:' . app::$id);
        if (empty($item)){
            $row = Db::selectOne('select * from cho_vod where d_id =' . app::$id);
            if (empty($row)){
                throw new AppException('资源不存在');
            }
            Cache::set('item:'.app::$id,json_encode($row),app::$redis['timeout']);
        }else{
            $row = json_decode($item,true);
        }
        $d_time = date('yy-m-d',$row['d_addtime']);
        $itemTypes = common::getItemType();
        app::$content = str_replace('[item:playlink]', self::getLink('vodPlay',$row['d_id']),app::$content);
        app::$content = str_replace('[item:pic]', $row['d_pic'],app::$content);
        app::$content = str_replace('[item:name]', $row['d_name'],app::$content);
        $link = "<a href='/'>首页</a>&nbsp;&nbsp;&raquo;&nbsp;&nbsp;<a href='". self::getLink('typeLink',$row['d_type']) ."' >". $itemTypes[$row['d_type']] ."</a>"."&nbsp;&nbsp;&raquo;&nbsp;&nbsp;<a href='". self::getLink('vodDetail',$row['d_id']) ."'>".$row['d_name']."</a>";
        app::$content = str_replace('[item:textlink]', $link,app::$content);
        app::$content = str_replace('[item:time]', $d_time,app::$content);
        app::$content = str_replace('[item:typename]', $itemTypes[$row['d_type']],app::$content);
    }
    public static function setPlayInfo(): void
    {
        $row = Db::selectOne('select * from cho_vod where d_id =' . app::$id);
        $itemTypes = common::getItemType();
        $url = str_replace("'","\'",$row['d_playurl']);
        $info = "<script>var mac_flag='play',mac_link='".self::getLink('vodPlay',$row['d_id'])."', mac_name='".$row['d_type']."',mac_from='swm3u8',mac_server='0',mac_note='',mac_urlx10d26=unescape('".self::escape($url)."'); </script>";
        app::$content = str_replace('[item:playerinfo]', $info,app::$content);
        app::$content = str_replace('[item:player]', '<script src="/template/bobo/static/js/playerconfig.js?t='.MAC_TSP.'"></script>',app::$content);
        $link = "<a href='/'>首页</a>&nbsp;&nbsp;&raquo;&nbsp;&nbsp;<a href='". self::getLink('typeLink',$row['d_type']) ."' >". $itemTypes[$row['d_type']] ."</a>"."&nbsp;&nbsp;&raquo;&nbsp;&nbsp;<a href='". self::getLink('vodDetail',$row['d_id']) ."'>".$row['d_name']."</a>";
        app::$content = str_replace('[item:textlink]', $link,app::$content);
    }
    public static function setTypeInfo(): void
    {
        $row = Db::selectOne('select count(d_id) as total from cho_vod where d_type =' . app::$typeId);
        $itemTypes = common::getItemType();
        app::$content = str_replace('{page:now}', app::$page,app::$content);
        app::$content = str_replace('{type:name}', $itemTypes[app::$typeId],app::$content);
        $link = "<a href='/'>首页</a>&nbsp;&nbsp;&raquo;&nbsp;&nbsp;<a href='". self::getLink('typeLink',app::$typeId) ."' >". $itemTypes[app::$typeId] ."</a>";
        app::$content = str_replace('[type:textlink]', $link,app::$content);
        $pageurl = '/'.app::$domain['rute'].'/'.app::$domain['rute_type'].'/'.app::$typeId.'/{page}.html';
        $page = new PageUtils($row['total'], app::$paeConfig['t_size'], app::$page, $pageurl, 4);
        $page_str = $page->myde_write();
        app::$content = str_replace('{bb:pages}', $page_str,app::$content);
    }

    public static function setInclude(): void
    {
        $foot = Cache::get('bb_foot');
        if (empty($foot)){
            $foot = file_get_contents('template/bobo/html/foot.html');
            Cache::set('bb_foot',$foot,60*60*12);
        }
        $include = Cache::get('bb_include');
        if (empty($include)){
            $include = file_get_contents('template/bobo/html/include.html');
            Cache::set('bb_include',$include,60*60*12);
        }
        $head = Cache::get('bb_head');
        if (empty($head)){
            $head = file_get_contents('template/bobo/html/head.html');
            $head = self::setMenuCode($head);
            Cache::set('bb_head',$head,60*60*12);
        }
        app::$content = str_replace('{bb:foot}', $foot,app::$content);
        app::$content = str_replace('{bb:include}', $include,app::$content);
        app::$content = str_replace('{bb:head}', $head,app::$content);
        app::$content = str_replace('{bb:title}', app::$domain['title'],app::$content);
        app::$content = str_replace('{bb:name}', app::$domain['name'],app::$content);
        app::$content = str_replace('{bb:domain}', app::$domain['domain'],app::$content);
    }

    /**
     * @throws Exception
     */
    public static function setMenuCode($head): string
    {
        $menu_area1 = '';
        $menu_area2 = '';
        $rows = Db::selectAll('select * from cho_vod_type where t_id in (1,2,3,4,5,6,7,8)');
        foreach ($rows as $row){
            $t_id = $row['t_id'];
            $menu_html = '<dd><a href="'.self::getLink('menu',$t_id).'">'.$row['t_name'].'<img src="/template/bobo/static/images/1.gif"></a></dd>';
            $menu_area1 = $menu_area1.$menu_html;
        }
        $rows = Db::selectAll('select * from cho_vod_type where t_id in (9,10,11,12,13,14,15,16)');
        foreach ($rows as $row){
            $t_id = $row['t_id'];
            $menu_html = '<dd><a href="'.self::getLink('menu',$t_id).'">'.$row['t_name'].'<img src="/template/bobo/static/images/1.gif"></a></dd>';
            $menu_area2 = $menu_area2.$menu_html;
        }
        $head = str_replace('{bb:menu1}', $menu_area1,$head);
        return str_replace('{bb:menu2}', $menu_area2,$head);
    }

    public static function setSearch(): void
    {
        $desc = '';
        $size = app::$paeConfig['s_size'];
        if (app::$searchKey == '*'){
            $key = '*';
            $desc = '&sort=d_addtm%20desc';
        }else{
            $key = urlencode(app::$searchKey);
        }
        $start = app::$page;
        $url = 'http://localhost:8983/solr/zb_core/select?hl.fl=d_name&hl.highlightMultiTerm=false&hl.requireFieldMatch=false&hl.simple.post=%3C%2Ffont%3E&hl.simple.pre=%3Cfont%20color%3D%22red%22%3E&hl.usePhraseHighLighter=false&hl=true&indent=true&q.op=OR&q=d_name%3A'.$key.$desc.'&rows='.$size.'&start='.(($start-1)*$size).'&wt=json';
        $result = file_get_contents($url);
        $row = json_decode($result,true);
        $res = $row['response']['docs'];
        $resHigh = $row['highlighting'];
        $itemHtml = "";
        for($i = 0; $i < count($res); $i++) {
            $d = $res[$i];
            $id = $d['id'];
            $d_id = $d['d_id'];
            $name = $d['d_name'];
            $pic = $d['d_pic'];
            $addtime=date('yy-m-d',$d['d_addtm']);
            $type = $d['d_type'];
            $hname = $resHigh[$id]['d_name'][0];
            if (empty($hname)){
                $hname = $name;
            }
            $html = '';
            if ($key=='*'){
                $html = '<li><a class="thumbnail" href="'.self::getLink('vodDetail',$d_id).'"><img src="'.$pic.'" alt="'.$name.'"></a>
                        <div class="video-info">
                            <h5><a href="'.self::getLink('vodDetail',$d_id).'" title="'.$name.'">'.$name.'</a></h5>
                            <p>'.$type.' - '.$addtime.'</p>
                        </div>
                    </li>';
            }else{
                $html = '<li><a class="thumbnail" href="'.self::getLink('vodDetail',$d_id).'"><img src="'.$pic.'" alt="'.$name.'"></a>
                        <div class="video-info">
                            <h5><a href="'.self::getLink('vodDetail',$d_id).'" title="'.$name.'">'.$hname.'</a></h5>
                            <p>'.$type.' - '.$addtime.'</p>
                        </div>
                    </li>';
            }
            $itemHtml = $itemHtml.$html;
        }
        $totalPage = ceil($row['response']['numFound']/$size);
        app::$content = str_replace("{searchResult}", $itemHtml,app::$content);
        app::$content = str_replace("{search:key}", app::$searchKey,app::$content);
        app::$content = str_replace("{page:now}", app::$page,app::$content);
        if (app::$page<2){
            $pageHtml = '当前:'.app::$page.'/'.$totalPage.'页&nbsp;<em>首页</em>&nbsp;<em>上一页</em>&nbsp;<a target="_self" href="/index.php?m=search-pg-'.(app::$page+1).'-wd-'.$key.'.html" class="pagelink_a">下一页</a>&nbsp;
                    <a target="_self" href="/index.php?m=search-pg-'.$totalPage.'-wd-'.$key.'.html" class="pagelink_a">尾页</a>&nbsp;<input type="input" name="page" id="page" size="4" class="pagego">
                    <input type="button" value="跳 转" onclick="pagego(\'/index.php?m=search-pg-{pg}-wd-'.$key.'.html\','.$totalPage.')" class="pagebtn"></center>';

        }else if(app::$page==$totalPage){
            $pageHtml = '当前:'.app::$page.'/'.$totalPage.'&nbsp;<a target="_self" href="/index.php?m=vod-search-wd-'.$key.'.html" class="pagelink_a">首页</a>&nbsp;
        <a target="_self" href="/index.php?m=search-pg-'.(app::$page-1).'-wd-'.$key.'.html" class="pagelink_a">上一页</a>&nbsp;&nbsp;<em>下一页</em>&nbsp;
                    <em>尾页</em>&nbsp;<input type="input" name="page" id="page" size="4" class="pagego">
                    <input type="button" value="跳 转" onclick="pagego(\'/index.php?m=search-pg-{pg}-wd-'.$key.'.html\','.$totalPage.')" class="pagebtn"></center>';
        }else{
            $pageHtml = '当前:'.app::$page.'/'.$totalPage.'&nbsp;<a target="_self" href="/index.php?m=search-wd-'.$key.'.html" class="pagelink_a">首页</a>&nbsp;
        <a target="_self" href="/index.php?m=search-pg-'.(app::$page-1).'-wd-'.$key.'.html" class="pagelink_a">上一页</a>&nbsp;
        <a target="_self" href="/index.php?m=search-pg-'.(app::$page+1).'-wd-'.$key.'.html" class="pagelink_a">下一页</a>&nbsp;<a target="_self" href="/index.php?m=search-pg-'.$totalPage.'-wd-'.$key.'.html" class="pagelink_a">尾页</a>&nbsp;
        <input type="input" name="page" id="page" size="4" class="pagego"><input type="button" value="跳 转" onclick="pagego(pagego(\'/index.php?m=search-pg-{pg}-wd-'.$key.'.html\','.$totalPage.'))" class="pagebtn"></center>';
        }
        app::$content = str_replace("{searchPages}", $pageHtml,app::$content);
    }


    /**
     * @throws Exception
     */
    public static function setItemList(): void
    {
        $sql = '';
        switch (app::$method) {
            case 'detail':
                $size = app::$paeConfig['d_size'];
                $sql = 'select * from cho_vod where d_id<' . app::$id . ' order by d_id desc limit ' . ((app::$page) * $size) . ',' . $size;
                break;
            case 'play':
                $size = app::$paeConfig['p_size'];
                $sql = 'select * from cho_vod where d_id<' . app::$id . ' order by d_id desc limit ' . ((app::$page) * $size) . ',' . $size;
                break;
            case 'index':
                $size = app::$paeConfig['i_size'];
                $sql = 'select * from cho_vod order by d_id desc limit ' . ((app::$page) * $size) . ',' . $size;
                break;
            case 'type':
                $size = app::$paeConfig['t_size'];
                $sql = 'select * from cho_vod where d_type=' . app::$typeId . ' order by d_id desc limit ' . ((app::$page) * $size) . ',' . $size;
                break;
        }
        $item_html = '';
        $rows = Db::selectAll($sql);
        $itemTypes = common::getItemType();
        foreach ($rows as $row) {
            $d_id = $row['d_id'];
            $vodLink = self::getLink('vodDetail', $d_id);
            $pic = $row['d_pic'];
            $d_name = $row['d_name'];
            $d_type_id = $row['d_type'];
            $d_typename = $itemTypes[$d_type_id];
            $d_time = date('yy-m-d', $row['d_addtime']);
            $item = '<li><a class="thumbnail" href="' . $vodLink . '"><img src="' . $pic . '" alt="' . $d_name . '"></a>
                            <div class="video-info">
                                <h5><a href="' . $vodLink . '" title="' . $d_name . '">' . $d_name . '</a></h5>
                                <p>' . $d_typename . ' - ' . $d_time . '</p>
                            </div>
                        </li>';
            $item_html = $item_html . $item;
        }
        app::$content = str_replace('{bb:item}', $item_html, app::$content);
    }

    public static function getLink($type,$args): string
    {
        $link = '';
        switch ($type){
            case 'menu':
                $link = '/'.app::$domain['rute'].'/'.app::$domain['rute_type'].'/'.$args.'/'.app::$page.'.html';
                break;
            case 'vodDetail':
                $link = '/'.app::$domain['rute'].'/'.app::$domain['rute_detail'].'/'.$args.'.html';
                break;
            case 'vodPlay':
                $link = '/'.app::$domain['rute'].'/'.app::$domain['rute_play'].'/'.$args.'.html';
                break;
            case 'typeLink':
                $link = '/'.app::$domain['rute'].'/'.app::$domain['rute_type'].'/'.$args.'/1.html';
                break;
        }
        return $link;
    }

    public static function getPage(): void
    {
        $page_key = 'page:';
        switch (app::$method){
            case 'index':
                $page_key = $page_key.app::$domain['domain'];
        }
        app::$content = Cache::get($page_key);
    }

    public static function escape($str): string
    {
        preg_match_all("/[\xC0-\xE0].|[\xE0-\xF0]..|[\x01-\x7f]+/",$str,$r);
        $ar = $r[0];
        foreach($ar as $k=>$v) {
            $ord = ord($v[0]);
            if( $ord<=0x7F)
                $ar[$k] = rawurlencode($v);
            elseif ($ord<0xE0) {
                $ar[$k] = "%u". self::utf2ucs($v);
            }
            elseif ($ord<0xF0) {
                $ar[$k] = "%u". self::utf2ucs($v);
            }
        }
        return join("",$ar);
    }

    public static function utf2ucs($str): string
    {
        $n=strlen($str);
        if ($n==3) {
            $highCode = ord($str[0]);
            $midCode = ord($str[1]);
            $lowCode = ord($str[2]);
            $a   = 0x1F & $highCode;
            $b   = 0x7F & $midCode;
            $c   = 0x7F & $lowCode;
            $ucsCode = (64*$a + $b)*64 + $c;
        }
        elseif ($n==2) {
            $highCode = ord($str[0]);
            $lowCode = ord($str[1]);
            $a   = 0x3F & $highCode;
            $b   = 0x7F & $lowCode;
            $ucsCode = 64*$a + $b;
        }elseif($n==1) {
            $ucscode = ord($str);
        }
        return dechex($ucsCode);
    }

    public static function showError(){
        $content = file_get_contents('template/bobo/html/error.html');
        $content = str_replace('{bb:error}', app::$error,$content);
        $content = str_replace('{bb:title}', app::$domain['title'],$content);
        $content = str_replace('{bb:name}', app::$domain['name'],$content);
        echo $content;
    }
}
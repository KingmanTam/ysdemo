<?php
require 'core/Cache.php';

$domain_key = $_SERVER['HTTP_HOST'];
if(str_contains($domain_key, 'www.')){
    $domain_key = str_replace('www.', '' ,$domain_key);
}
$domain_info = Cache::get('domain:'.$domain_key);
if (!empty($domain_info)){
    $domainConf = json_decode($domain_info,true);
    app::$domain['title'] = $domainConf['title'];
    app::$domain['name'] = $domainConf['name'];
    app::$domain['keywords'] = $domainConf['keywords'];
    app::$domain['description'] = $domainConf['description'];
    app::$domain['template'] = $domainConf['template'];
    app::$domain['offset'] = $domainConf['offset'];
    app::$domain['rute'] = $domainConf['rute'];
    app::$domain['rute_detail'] = $domainConf['rute_detail'];
    app::$domain['rute_play'] = $domainConf['rute_play'];
    app::$domain['rute_type'] = $domainConf['rute_type'];
}
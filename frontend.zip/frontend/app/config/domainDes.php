<?php
return array (
    'gzmilk.com' =>
        array (
            'offset' => 784,
            'des_pre' => '夜骄人影院-yjr,',
            'sub_title' => '国产丝袜美腿黑丝,国产亚洲人妻无大码精品,国产乱人伦99精品',
            'site_rute' => '/jzcsu',
            'site_detail' => 'nhplc',
            'site_play' => 'zrent',
            'site_type' => 'ulaqt',
        ),
    'nnbbbyy.com' =>
        array (
            'offset' => 556,
            'des_pre' => '天竺影视为你提供:',
            'sub_title' => '美眉中文中出无a码高清,国产乱人伦99精品,一级a免费观看完整视频',
            'site_rute' => '/ckoyc',
            'site_detail' => 'afwdc',
            'site_play' => 'kgeky',
            'site_type' => 'yiyqr',
        ),
    'groupsex-world.com' =>
        array (
            'offset' => 490,
            'des_pre' => '春菊影视为你提供:',
            'sub_title' => '欧美日韩人妻无大码精品,国产乱人伦精品视频不卡,日韩人妻无大码精品',
            'site_rute' => '/vbpaq',
            'site_detail' => 'nreap',
            'site_play' => 'gdyoc',
            'site_type' => 'dqdci',
        ),
    'wxsthy.com' =>
        array (
            'offset' => 1117,
            'des_pre' => '天堂鸟影视为你提供:',
            'sub_title' => '日韩中文字幕在线不卡,欧美老熟妇乱子伦,国产真实夫妻91',
            'site_rute' => '/hudse',
            'site_detail' => 'jytam',
            'site_play' => 'fbclh',
            'site_type' => 'fhvve',
        ),
    'diaodengdai.com' =>
        array (
            'offset' => 589,
            'des_pre' => '墨兰影视为你提供:',
            'sub_title' => '亚洲日韩中文字幕免费播放,美眉中文中出无a码高清',
            'site_rute' => '/wpkkp',
            'site_detail' => 'rbvgv',
            'site_play' => 'ecdsy',
            'site_type' => 'scdsh',
        ),
    'bimalmitra.com' =>
        array (
            'offset' => 388,
            'des_pre' => '桃花影视为你提供:',
            'sub_title' => '日韩精品人妻在线观看,国产亚洲精品在线爽',
            'site_rute' => '/zdwpw',
            'site_detail' => 'ioqew',
            'site_play' => 'ixgpy',
            'site_type' => 'mditq',
        ),
    'devtucao.com' =>
        array (
            'offset' => 7,
            'des_pre' => '文竹',
            'site_rute' => '/ltkml',
            'site_detail' => 'mykmq',
            'site_play' => 'mvmvt',
            'site_type' => 'ngkat',
        ),
    'zanabilichina.com' =>
        array (
            'offset' => 14,
            'des_pre' => '文竹',
            'site_rute' => '/wkwdo',
            'site_detail' => 'xrekh',
            'site_play' => 'mvxnn',
            'site_type' => 'arrop',
        ),
    'liesouwang.com' =>
        array (
            'offset' => 2,
            'des_pre' => '文竹',
            'site_rute' => '/mssxa',
            'site_detail' => 'kfnna',
            'site_play' => 'wkumz',
            'site_type' => 'uyelj',
        ),
    'dienmaytanhung.com' =>
        array (
            'offset' => 25,
            'des_pre' => '文竹',
            'site_rute' => '/oosvw',
            'site_detail' => 'giozn',
            'site_play' => 'grsbo',
            'site_type' => 'jsytv',
        ),
    'buyercampus.com' =>
        array (
            'offset' => 35,
            'des_pre' => '石竹',
            'site_rute' => '/ftpmj',
            'site_detail' => 'vfxbe',
            'site_play' => 'muekp',
            'site_type' => 'hihjw',
        ),
    'iraqimemoirs.com' =>
        array (
            'offset' => 11,
            'des_pre' => '石竹',
            'site_rute' => '/skrsk',
            'site_detail' => 'sfity',
            'site_play' => 'dimoh',
            'site_type' => 'lhrkn',
        ),
    'virtualkk.com' =>
        array (
            'offset' => 22,
            'des_pre' => '石竹',
            'site_rute' => '/jsbfs',
            'site_detail' => 'xpndg',
            'site_play' => 'nlzqa',
            'site_type' => 'tiwuj',
        ),
    'jiyanjy120.com' =>
        array (
            'offset' => 6,
            'des_pre' => '石竹',
            'site_rute' => '/ourmu',
            'site_detail' => 'jxhpx',
            'site_play' => 'indrr',
            'site_type' => 'ifrgs',
        ),
    'lanyuefang.com' =>
        array (
            'offset' => 2,
            'des_pre' => '石竹',
            'site_rute' => '/azkxa',
            'site_detail' => 'orjtb',
            'site_play' => 'wfztb',
            'site_type' => 'ncxct',
        ),
    'turcksh.com' =>
        array (
            'offset' => 25,
            'des_pre' => '石竹',
            'site_rute' => '/fiskk',
            'site_detail' => 'vutjq',
            'site_play' => 'doyad',
            'site_type' => 'whqtm',
        ),
    'm-mediate.com' =>
        array (
            'offset' => 2,
            'des_pre' => '石竹',
            'site_rute' => '/vgdxe',
            'site_detail' => 'pivgq',
            'site_play' => 'ljmqy',
            'site_type' => 'ctrnf',
        ),
    'colapt.com' =>
        array (
            'offset' => 19,
            'des_pre' => '石竹',
            'site_rute' => '/mxrja',
            'site_detail' => 'kxskh',
            'site_play' => 'wkiqg',
            'site_type' => 'avywq',
        ),
    'jimope.com' =>
        array (
            'offset' => 4,
            'des_pre' => '玉兰',
            'site_rute' => '/ibtop',
            'site_detail' => 'dkhdk',
            'site_play' => 'mewxo',
            'site_type' => 'fjfxr',
        ),
    'hg84111.com' =>
        array (
            'offset' => 36,
            'des_pre' => '玉兰',
            'site_rute' => '/tdalc',
            'site_detail' => 'tpgln',
            'site_play' => 'gzuwf',
            'site_type' => 'paiba',
        ),
    'puruixi.com' =>
        array (
            'offset' => 35,
            'des_pre' => '玉兰',
            'site_rute' => '/ehqdm',
            'site_detail' => 'kyuji',
            'site_play' => 'vuuvs',
            'site_type' => 'hxakm',
        ),
    'dudoanbongda24h.com' =>
        array (
            'offset' => 5,
            'des_pre' => '玉兰',
            'site_rute' => '/jbzkd',
            'site_detail' => 'rfaug',
            'site_play' => 'rolqf',
            'site_type' => 'guoiy',
        ),
    'englishvitamin.com' =>
        array (
            'offset' => 28,
            'des_pre' => '玉兰',
            'site_rute' => '/hzkjp',
            'site_detail' => 'dbapw',
            'site_play' => 'bninc',
            'site_type' => 'dxyhk',
        ),
    'gent-x.com' =>
        array (
            'offset' => 22,
            'des_pre' => '玉兰',
            'site_rute' => '/plrke',
            'site_detail' => 'djqpi',
            'site_play' => 'txail',
            'site_type' => 'jzmul',
        ),
    'xin-lv.com' =>
        array (
            'offset' => 21,
            'des_pre' => '玉兰',
            'site_rute' => '/snejn',
            'site_detail' => 'bxwwu',
            'site_play' => 'yqzcl',
            'site_type' => 'hhasx',
        ),
    'hopsocietyja.com' =>
        array (
            'offset' => 19,
            'des_pre' => '玉兰',
            'site_rute' => '/mwaty',
            'site_detail' => 'guhvz',
            'site_play' => 'xdjju',
            'site_type' => 'txjru',
        ),
    'love-lala.com' =>
        array (
            'offset' => 17,
            'des_pre' => '玉兰',
            'site_rute' => '/dsgyv',
            'site_detail' => 'xfanb',
            'site_play' => 'pzzak',
            'site_type' => 'fjlid',
        ),
    'thevillagedubai.com' =>
        array (
            'offset' => 13,
            'des_pre' => '玉兰',
            'site_rute' => '/lhedg',
            'site_detail' => 'tdvcw',
            'site_play' => 'lnbsm',
            'site_type' => 'qknaf',
        ),
    'dymjggs.com' =>
        array (
            'offset' => 10,
            'des_pre' => '春兰',
            'site_rute' => '/edcfh',
            'site_detail' => 'sdyge',
            'site_play' => 'yhlzr',
            'site_type' => 'pwcmi',
        ),
    'ouyaer.com' =>
        array (
            'offset' => 7,
            'des_pre' => '春兰',
            'site_rute' => '/adsik',
            'site_detail' => 'bmpfr',
            'site_play' => 'cgozy',
            'site_type' => 'mwhgq',
        ),
    'hbtdblg.com' =>
        array (
            'offset' => 7,
            'des_pre' => '春兰',
            'site_rute' => '/yxfki',
            'site_detail' => 'qyozv',
            'site_play' => 'rfkte',
            'site_type' => 'rbnfs',
        ),
    'maycblast.com' =>
        array (
            'offset' => 7,
            'des_pre' => '春兰',
            'site_rute' => '/ejlvh',
            'site_detail' => 'sdvhv',
            'site_play' => 'ysfxw',
            'site_type' => 'kwpdu',
        ),
    'hfyfhj.com' =>
        array (
            'offset' => 4,
            'des_pre' => '春兰',
            'site_rute' => '/uckiq',
            'site_detail' => 'drqvy',
            'site_play' => 'gwyyu',
            'site_type' => 'swhjq',
        ),
    'jiayingli.com' =>
        array (
            'offset' => 1,
            'des_pre' => '春兰',
            'site_rute' => '/ojgkc',
            'site_detail' => 'digde',
            'site_play' => 'ltthe',
            'site_type' => 'ncule',
        ),
    'kangdarui.com' =>
        array (
            'offset' => 1,
            'des_pre' => '春兰',
            'site_rute' => '/ytyvu',
            'site_detail' => 'ztceo',
            'site_play' => 'clsru',
            'site_type' => 'ozcky',
        ),
    'hongyijushi.com' =>
        array (
            'offset' => 1,
            'des_pre' => '翠菊',
            'site_rute' => '/xaqum',
            'site_detail' => 'szfqn',
            'site_play' => 'apucy',
            'site_type' => 'tsddv',
        ),
    'zzdyscl.com' =>
        array (
            'offset' => 1,
            'des_pre' => '春兰',
            'site_rute' => '/zxwxa',
            'site_detail' => 'dldqu',
            'site_play' => 'dbsky',
            'site_type' => 'yndhr',
        ),
    'marchingbears.com' =>
        array (
            'offset' => 1,
            'des_pre' => '春菊',
            'site_rute' => '/ymdul',
            'site_detail' => 'leuzf',
            'site_play' => 'zrlya',
            'site_type' => 'eazrx',
        ),
    'rathfrilandfc.com' =>
        array (
            'offset' => 1,
            'des_pre' => '翠菊',
            'site_rute' => '/rlzlx',
            'site_detail' => 'qthjm',
            'site_play' => 'qrmer',
            'site_type' => 'bgkwm',
        ),
    'laserargon.com' =>
        array (
            'offset' => 1,
            'des_pre' => '天竺',
            'site_rute' => '/yaqza',
            'site_detail' => 'topwe',
            'site_play' => 'fjkfi',
            'site_type' => 'hnhzt',
        ),
    'sweetnailart.com' =>
        array (
            'offset' => 1,
            'des_pre' => '罗兰',
            'site_rute' => '/trbnw',
            'site_detail' => 'xnzvd',
            'site_play' => 'mutes',
            'site_type' => 'bqtqu',
        ),
    'actorobo.com' =>
        array (
            'offset' => 1,
            'des_pre' => '罗兰',
            'site_rute' => '/tckux',
            'site_detail' => 'boceg',
            'site_play' => 'orzju',
            'site_type' => 'qxlbw',
        ),
    'madein70.com' =>
        array (
            'offset' => 2,
            'des_pre' => '春菊',
            'site_rute' => '/iqbdn',
            'site_detail' => 'nmoyp',
            'site_play' => 'glefm',
            'site_type' => 'kguot',
        ),
    'kshhbf.com' =>
        array (
            'offset' => 2,
            'des_pre' => '石竹',
            'site_rute' => '/kmaux',
            'site_detail' => 'edoka',
            'site_play' => 'ncvuf',
            'site_type' => 'fhzgc',
        ),
    'lnsyqjs.com' =>
        array (
            'offset' => 2,
            'des_pre' => '玉兰',
            'site_rute' => '/fkcfk',
            'site_detail' => 'ftgor',
            'site_play' => 'mtdtl',
            'site_type' => 'mprqb',
        ),
    'tonbde.com' =>
        array (
            'offset' => 2,
            'des_pre' => '天竺',
            'site_rute' => '/wprln',
            'site_detail' => 'elzqe',
            'site_play' => 'puupu',
            'site_type' => 'edzac',
        ),
    'jxxhjz.com' =>
        array (
            'offset' => 2,
            'des_pre' => '罗兰',
            'site_rute' => '/xyfop',
            'site_detail' => 'bjxwx',
            'site_play' => 'oetqn',
            'site_type' => 'wwcst',
        ),
    'goodabc.net' =>
        array (
            'offset' => 2,
            'des_pre' => '文竹',
            'site_rute' => '/oqgta',
            'site_detail' => 'yqaiy',
            'site_play' => 'nbjww',
            'site_type' => 'iakua',
        ),
    'tecsmetales.com' =>
        array (
            'offset' => 3,
            'des_pre' => '墨兰',
            'site_rute' => '/tfywh',
            'site_detail' => 'jinre',
            'site_play' => 'tgcjz',
            'site_type' => 'hwtwp',
        ),
    'dominicanice.com' =>
        array (
            'offset' => 3,
            'des_pre' => '文竹',
            'site_rute' => '/rvstg',
            'site_detail' => 'ioanc',
            'site_play' => 'xitqv',
            'site_type' => 'vgpnp',
        ),
    'wfdfcyey.com' =>
        array (
            'offset' => 3,
            'des_pre' => '天竺',
            'site_rute' => '/ngcyi',
            'site_detail' => 'mhiqw',
            'site_play' => 'dzdta',
            'site_type' => 'watqy',
        ),
    'drmadjar.com' =>
        array (
            'offset' => 3,
            'des_pre' => '石竹',
            'site_rute' => '/hpbtt',
            'site_detail' => 'szadf',
            'site_play' => 'bysoy',
            'site_type' => 'wasva',
        ),
    't-precious.com' =>
        array (
            'offset' => 3,
            'des_pre' => '寒兰',
            'site_rute' => '/qiqbp',
            'site_detail' => 'gucyv',
            'site_play' => 'sjodx',
            'site_type' => 'fcjuq',
        ),
    'standrewspca.net' =>
        array (
            'offset' => 3,
            'des_pre' => '桃花',
            'site_rute' => '/ndhva',
            'site_detail' => 'knmkb',
            'site_play' => 'nwzil',
            'site_type' => 'zwrdy',
        ),
    'xiandeli.com' =>
        array (
            'offset' => 3,
            'des_pre' => '建兰',
            'site_rute' => '/ddazm',
            'site_detail' => 'ahcen',
            'site_play' => 'lrjzb',
            'site_type' => 'hkcta',
        ),
    'gongnengxing.com' =>
        array (
            'offset' => 3,
            'des_pre' => '翠菊',
            'site_rute' => '/oygby',
            'site_detail' => 'ptdnj',
            'site_play' => 'mwhpa',
            'site_type' => 'jfmpf',
        ),
    'javaessential.com' =>
        array (
            'offset' => 3,
            'des_pre' => '桃花',
            'site_rute' => '/vndrv',
            'site_detail' => 'waktq',
            'site_play' => 'ianvx',
            'site_type' => 'ctulq',
        ),
    'xpertsenior.com' =>
        array (
            'offset' => 4,
            'des_pre' => '春菊',
            'site_rute' => '/pddyo',
            'site_detail' => 'hcclk',
            'site_play' => 'pnpwe',
            'site_type' => 'yimcd',
        ),
    'fbmsecrets.com' =>
        array (
            'offset' => 4,
            'des_pre' => '春菊',
            'site_rute' => '/sivqf',
            'site_detail' => 'ijjez',
            'site_play' => 'mrrlc',
            'site_type' => 'kgdro',
        ),
    'esjewelryltd.com' =>
        array (
            'offset' => 4,
            'des_pre' => '石竹',
            'site_rute' => '/ijmdx',
            'site_detail' => 'rhwun',
            'site_play' => 'grmxf',
            'site_type' => 'ifisr',
        ),
    'wuye188.com' =>
        array (
            'offset' => 4,
            'des_pre' => '春兰',
            'site_rute' => '/xwhhr',
            'site_detail' => 'aprds',
            'site_play' => 'uwxll',
            'site_type' => 'qssoy',
        ),
    'tipssales.com' =>
        array (
            'offset' => 4,
            'des_pre' => '蕙兰',
            'site_rute' => '/rsvlc',
            'site_detail' => 'yxaop',
            'site_play' => 'higgd',
            'site_type' => 'peuxa',
        ),
    'bitcoinbarato.com' =>
        array (
            'offset' => 4,
            'des_pre' => '寒兰',
            'site_rute' => '/isdln',
            'site_detail' => 'lepat',
            'site_play' => 'dsdos',
            'site_type' => 'mhgef',
        ),
    'artis-fashion.com' =>
        array (
            'offset' => 4,
            'des_pre' => '桃花',
            'site_rute' => '/bmgia',
            'site_detail' => 'gnhbx',
            'site_play' => 'rwvhy',
            'site_type' => 'kexyz',
        ),
    'ericschwerer.com' =>
        array (
            'offset' => 5,
            'des_pre' => '玉兰',
            'site_rute' => '/yvbqf',
            'site_detail' => 'usyff',
            'site_play' => 'vlyfq',
            'site_type' => 'cdowf',
        ),
    'mastiaslot.com' =>
        array (
            'offset' => 5,
            'des_pre' => '文竹',
            'site_rute' => '/wvgkw',
            'site_detail' => 'bredo',
            'site_play' => 'moqaz',
            'site_type' => 'skwkl',
        ),
    'regalosmisticos.com' =>
        array (
            'offset' => 5,
            'des_pre' => '春兰',
            'site_rute' => '/ojifj',
            'site_detail' => 'vgtqy',
            'site_play' => 'dpkie',
            'site_type' => 'vtzws',
        ),
    'terryjamesphoto.com' =>
        array (
            'offset' => 5,
            'des_pre' => '罗兰',
            'site_rute' => '/msibc',
            'site_detail' => 'cfrtp',
            'site_play' => 'nlzoa',
            'site_type' => 'vicaf',
        ),
    'alexrugowski.com' =>
        array (
            'offset' => 5,
            'des_pre' => '文竹',
            'site_rute' => '/vgiao',
            'site_detail' => 'xhnaf',
            'site_play' => 'ayipj',
            'site_type' => 'tqhon',
        ),
    'pop-replicas.com' =>
        array (
            'offset' => 5,
            'des_pre' => '春菊',
            'site_rute' => '/afgjh',
            'site_detail' => 'kwusc',
            'site_play' => 'wwoem',
            'site_type' => 'ytebl',
        ),
    'guanshengdl.com' =>
        array (
            'offset' => 5,
            'des_pre' => '翠菊',
            'site_rute' => '/hvqlu',
            'site_detail' => 'jurpi',
            'site_play' => 'rmfxh',
            'site_type' => 'puwgy',
        ),
    'pifumb.com' =>
        array (
            'offset' => 5,
            'des_pre' => '春兰',
            'site_rute' => '/teboo',
            'site_detail' => 'yclmm',
            'site_play' => 'axuis',
            'site_type' => 'sikof',
        ),
    'sjzdtj.com' =>
        array (
            'offset' => 6,
            'des_pre' => '罗兰',
            'site_rute' => '/ciuvr',
            'site_detail' => 'xpsad',
            'site_play' => 'wjtno',
            'site_type' => 'updzg',
        ),
    'zjxmbnf.com' =>
        array (
            'offset' => 6,
            'des_pre' => '玉兰',
            'site_rute' => '/asyrx',
            'site_detail' => 'yqfqo',
            'site_play' => 'iqhkq',
            'site_type' => 'bpbwy',
        ),
    'lituojin.com' =>
        array (
            'offset' => 6,
            'des_pre' => '春兰',
            'site_rute' => '/rbeke',
            'site_detail' => 'chmoi',
            'site_play' => 'wsutj',
            'site_type' => 'xgkcm',
        ),
    'heixiongboji.com' =>
        array (
            'offset' => 6,
            'des_pre' => '桃花',
            'site_rute' => '/tjqjm',
            'site_detail' => 'rment',
            'site_play' => 'ddkqn',
            'site_type' => 'fwfop',
        ),
    'shouerkusa.com' =>
        array (
            'offset' => 6,
            'des_pre' => '寒兰',
            'site_rute' => '/pvqjr',
            'site_detail' => 'xzzef',
            'site_play' => 'vcxrm',
            'site_type' => 'mfqay',
        ),
    'hxzmgw.com' =>
        array (
            'offset' => 6,
            'des_pre' => '翠菊',
            'site_rute' => '/pzgdx',
            'site_detail' => 'svstd',
            'site_play' => 'nrpyj',
            'site_type' => 'xfzxf',
        ),
    'viecoico.com' =>
        array (
            'offset' => 6,
            'des_pre' => '墨兰',
            'site_rute' => '/wzbfx',
            'site_detail' => 'nlbgp',
            'site_play' => 'vfema',
            'site_type' => 'elntd',
        ),
    'hongzefcw.com' =>
        array (
            'offset' => 6,
            'des_pre' => '桃花',
            'site_rute' => '/ttjds',
            'site_detail' => 'hocrc',
            'site_play' => 'ipkvp',
            'site_type' => 'leoqe',
        ),
    'hxzhumu.com' =>
        array (
            'offset' => 7,
            'des_pre' => '罗兰',
            'site_rute' => '/ovgyd',
            'site_detail' => 'nhxaw',
            'site_play' => 'icdpw',
            'site_type' => 'ckznx',
        ),
    'njtaida.com' =>
        array (
            'offset' => 7,
            'des_pre' => '石竹',
            'site_rute' => '/gfnmt',
            'site_detail' => 'bkmyh',
            'site_play' => 'mivhq',
            'site_type' => 'vvncs',
        ),
    'jnmaya.com' =>
        array (
            'offset' => 7,
            'des_pre' => '石竹',
            'site_rute' => '/tlbhy',
            'site_detail' => 'ljjek',
            'site_play' => 'xmvbg',
            'site_type' => 'byowy',
        ),
    'baduzy.com' =>
        array (
            'offset' => 7,
            'des_pre' => '寒兰',
            'site_rute' => '/bxgkj',
            'site_detail' => 'efopa',
            'site_play' => 'tfqjl',
            'site_type' => 'syqsb',
        ),
    'kcstkd.com' =>
        array (
            'offset' => 7,
            'des_pre' => '春兰',
            'site_rute' => '/vnadi',
            'site_detail' => 'kujkf',
            'site_play' => 'bfmos',
            'site_type' => 'odpip',
        ),
    'jjhqnt.com' =>
        array (
            'offset' => 8,
            'des_pre' => '春兰',
            'site_rute' => '/nqjbg',
            'site_detail' => 'ollvf',
            'site_play' => 'phqzz',
            'site_type' => 'tqias',
        ),
    'cnprxh.com' =>
        array (
            'offset' => 8,
            'des_pre' => '罗兰',
            'site_rute' => '/ehvyf',
            'site_detail' => 'ncamr',
            'site_play' => 'eidft',
            'site_type' => 'krsjo',
        ),
    'shaoguanfuke.com' =>
        array (
            'offset' => 8,
            'des_pre' => '建兰',
            'site_rute' => '/tnumv',
            'site_detail' => 'abcgi',
            'site_play' => 'vbxyp',
            'site_type' => 'bovov',
        ),
    'cdmhjs.com' =>
        array (
            'offset' => 8,
            'des_pre' => '海棠',
            'site_rute' => '/auenz',
            'site_detail' => 'nzlpv',
            'site_play' => 'kkqxf',
            'site_type' => 'guyxr',
        ),
    'xhqhlhgc.com' =>
        array (
            'offset' => 8,
            'des_pre' => '玉兰',
            'site_rute' => '/oghum',
            'site_detail' => 'crjxx',
            'site_play' => 'kkcjn',
            'site_type' => 'senqo',
        ),
    'k4minds.com' =>
        array (
            'offset' => 8,
            'des_pre' => '石竹',
            'site_rute' => '/ifdou',
            'site_detail' => 'tsjnu',
            'site_play' => 'fkzyy',
            'site_type' => 'uysie',
        ),
    'aiq2018.com' =>
        array (
            'offset' => 8,
            'des_pre' => '海棠',
            'site_rute' => '/cgljs',
            'site_detail' => 'nqcws',
            'site_play' => 'pcwex',
            'site_type' => 'kzfig',
        ),
    'duotuangou.com' =>
        array (
            'offset' => 8,
            'des_pre' => '海棠',
            'site_rute' => '/xktjt',
            'site_detail' => 'hdjjx',
            'site_play' => 'tsgyy',
            'site_type' => 'egrgj',
        ),
    'giangcau.com' =>
        array (
            'offset' => 8,
            'des_pre' => '桃花',
            'site_rute' => '/xqcsr',
            'site_detail' => 'ryzbt',
            'site_play' => 'snoid',
            'site_type' => 'ikjgy',
        ),
    'edforshaw.com' =>
        array (
            'offset' => 9,
            'des_pre' => '桃花',
            'site_rute' => '/ngzzc',
            'site_detail' => 'lpyvu',
            'site_play' => 'cdfzu',
            'site_type' => 'pvdko',
        ),
    'buybestus.com' =>
        array (
            'offset' => 9,
            'des_pre' => '寒兰',
            'site_rute' => '/gtyfw',
            'site_detail' => 'iaihp',
            'site_play' => 'acgof',
            'site_type' => 'mxzbd',
        ),
    'ereneban.com' =>
        array (
            'offset' => 9,
            'des_pre' => '蕙兰',
            'site_rute' => '/emvem',
            'site_detail' => 'yradd',
            'site_play' => 'tdzfq',
            'site_type' => 'msquq',
        ),
    'hkfyjs.com' =>
        array (
            'offset' => 9,
            'des_pre' => '罗兰',
            'site_rute' => '/pwozf',
            'site_detail' => 'oudyo',
            'site_play' => 'xkqno',
            'site_type' => 'opcqn',
        ),
    'thegritfairy.com' =>
        array (
            'offset' => 9,
            'des_pre' => '翠菊',
            'site_rute' => '/xfshc',
            'site_detail' => 'ffufy',
            'site_play' => 'dfbth',
            'site_type' => 'rwboj',
        ),
    'elkinspotter.com' =>
        array (
            'offset' => 9,
            'des_pre' => '文竹',
            'site_rute' => '/quwqu',
            'site_detail' => 'jmohn',
            'site_play' => 'cluof',
            'site_type' => 'bkwir',
        ),
    'honglingjinlove.com' =>
        array (
            'offset' => 9,
            'des_pre' => '春菊',
            'site_rute' => '/wgycu',
            'site_detail' => 'abbvx',
            'site_play' => 'eitlq',
            'site_type' => 'iwdhi',
        ),
    'shengyihe.com' =>
        array (
            'offset' => 9,
            'des_pre' => '罗兰',
            'site_rute' => '/upauc',
            'site_detail' => 'hsiaw',
            'site_play' => 'nswqp',
            'site_type' => 'wmmpf',
        ),
    'nhhymy.com' =>
        array (
            'offset' => 9,
            'des_pre' => '寒兰',
            'site_rute' => '/jwnbc',
            'site_detail' => 'enjtp',
            'site_play' => 'tspne',
            'site_type' => 'gzxet',
        ),
    'pufengpai.com' =>
        array (
            'offset' => 10,
            'des_pre' => '春兰',
            'site_rute' => '/lpwsw',
            'site_detail' => 'voilq',
            'site_play' => 'oztsm',
            'site_type' => 'otioe',
        ),
    'fenghuangmpz.com' =>
        array (
            'offset' => 10,
            'des_pre' => '寒兰',
            'site_rute' => '/hmibp',
            'site_detail' => 'uojbj',
            'site_play' => 'brqte',
            'site_type' => 'ipqcd',
        ),
    'cdxymr.com' =>
        array (
            'offset' => 10,
            'des_pre' => '建兰',
            'site_rute' => '/rrkqy',
            'site_detail' => 'rlukv',
            'site_play' => 'hujkp',
            'site_type' => 'lphno',
        ),
    'fsjycy.com' =>
        array (
            'offset' => 10,
            'des_pre' => '春兰',
            'site_rute' => '/zyavx',
            'site_detail' => 'opwqh',
            'site_play' => 'gdclr',
            'site_type' => 'bskox',
        ),
    'lilongmuliao.com' =>
        array (
            'offset' => 10,
            'des_pre' => '建兰',
            'site_rute' => '/dwjco',
            'site_detail' => 'pddbv',
            'site_play' => 'lpodx',
            'site_type' => 'xurvw',
        ),
    'ecstaticfun.com' =>
        array (
            'offset' => 10,
            'des_pre' => '寒兰',
            'site_rute' => '/yqyrc',
            'site_detail' => 'buaxj',
            'site_play' => 'izrtd',
            'site_type' => 'pwsvq',
        ),
    'zhishi366.com' =>
        array (
            'offset' => 10,
            'des_pre' => '蕙兰',
            'site_rute' => '/asyio',
            'site_detail' => 'bdgym',
            'site_play' => 'gmxok',
            'site_type' => 'kcddm',
        ),
    'ccsapparel.com' =>
        array (
            'offset' => 10,
            'des_pre' => '文竹',
            'site_rute' => '/lgjxr',
            'site_detail' => 'ofthh',
            'site_play' => 'oincx',
            'site_type' => 'ycrtz',
        ),
    'xmrhtbz.com' =>
        array (
            'offset' => 11,
            'des_pre' => '石竹',
            'site_rute' => '/fhwcm',
            'site_detail' => 'dfwyg',
            'site_play' => 'cckrp',
            'site_type' => 'hnbeq',
        ),
    'chezrivieres.com' =>
        array (
            'offset' => 11,
            'des_pre' => '海棠',
            'site_rute' => '/dxoln',
            'site_detail' => 'eiulq',
            'site_play' => 'mgnbv',
            'site_type' => 'nxspp',
        ),
    'de-los-santos.com' =>
        array (
            'offset' => 11,
            'des_pre' => '翠菊',
            'site_rute' => '/tqtfn',
            'site_detail' => 'zurbq',
            'site_play' => 'lixjj',
            'site_type' => 'snbew',
        ),
    'ptorthorehab.com' =>
        array (
            'offset' => 11,
            'des_pre' => '石竹',
            'site_rute' => '/coych',
            'site_detail' => 'eabsh',
            'site_play' => 'jrngx',
            'site_type' => 'vnbvb',
        ),
    'ihaveatiger.com' =>
        array (
            'offset' => 11,
            'des_pre' => '墨兰',
            'site_rute' => '/qcnzi',
            'site_detail' => 'wpavg',
            'site_play' => 'shooz',
            'site_type' => 'rvbyt',
        ),
    'redticketblues.com' =>
        array (
            'offset' => 11,
            'des_pre' => '翠菊',
            'site_rute' => '/wpras',
            'site_detail' => 'isapi',
            'site_play' => 'vcpgu',
            'site_type' => 'ephwu',
        ),
    'bidwales.com' =>
        array (
            'offset' => 11,
            'des_pre' => '建兰',
            'site_rute' => '/bnbyz',
            'site_detail' => 'cznok',
            'site_play' => 'fgbqh',
            'site_type' => 'jaqkf',
        ),
    'daviddemartin.com' =>
        array (
            'offset' => 12,
            'des_pre' => '春菊',
            'site_rute' => '/rkjsn',
            'site_detail' => 'zwxrw',
            'site_play' => 'ynlej',
            'site_type' => 'gensj',
        ),
    'watermarksbh.com' =>
        array (
            'offset' => 12,
            'des_pre' => '蕙兰',
            'site_rute' => '/yambb',
            'site_detail' => 'kgisa',
            'site_play' => 'ocdby',
            'site_type' => 'hnpnj',
        ),
    'instinctcode.net' =>
        array (
            'offset' => 12,
            'des_pre' => '建兰',
            'site_rute' => '/derva',
            'site_detail' => 'yyevf',
            'site_play' => 'lwplc',
            'site_type' => 'iowod',
        ),
    'pc-surveillance.com' =>
        array (
            'offset' => 12,
            'des_pre' => '罗兰',
            'site_rute' => '/bsvax',
            'site_detail' => 'rfifp',
            'site_play' => 'kjthb',
            'site_type' => 'wnchg',
        ),
    'tinglouyi.com' =>
        array (
            'offset' => 12,
            'des_pre' => '桃花',
            'site_rute' => '/cahys',
            'site_detail' => 'hyynu',
            'site_play' => 'zyout',
            'site_type' => 'fpogy',
        ),
    'xixidaili.com' =>
        array (
            'offset' => 12,
            'des_pre' => '蕙兰',
            'site_rute' => '/wxwas',
            'site_detail' => 'cehaj',
            'site_play' => 'oedpn',
            'site_type' => 'wguac',
        ),
    'jiufuduoni.com' =>
        array (
            'offset' => 12,
            'des_pre' => '蕙兰',
            'site_rute' => '/alxgs',
            'site_detail' => 'saxbd',
            'site_play' => 'cclsc',
            'site_type' => 'pdszh',
        ),
    'supersubeta.com' =>
        array (
            'offset' => 12,
            'des_pre' => '建兰',
            'site_rute' => '/yjgvv',
            'site_detail' => 'yqitc',
            'site_play' => 'reiby',
            'site_type' => 'vbmxn',
        ),
    'heel-spurs.com' =>
        array (
            'offset' => 12,
            'des_pre' => '玉兰',
            'site_rute' => '/wnith',
            'site_detail' => 'qpesy',
            'site_play' => 'ogucg',
            'site_type' => 'hbkgg',
        ),
    'qijiangkeji.com' =>
        array (
            'offset' => 13,
            'des_pre' => '罗兰',
            'site_rute' => '/cnsyw',
            'site_detail' => 'nawkq',
            'site_play' => 'wrsvt',
            'site_type' => 'ahodk',
        ),
    'transaxleengr.com' =>
        array (
            'offset' => 13,
            'des_pre' => '蕙兰',
            'site_rute' => '/udsfu',
            'site_detail' => 'nvidv',
            'site_play' => 'rqufv',
            'site_type' => 'kdddq',
        ),
    'tianshituye.com' =>
        array (
            'offset' => 13,
            'des_pre' => '玉兰',
            'site_rute' => '/hdpth',
            'site_detail' => 'yzqwb',
            'site_play' => 'xyyaf',
            'site_type' => 'whthz',
        ),
    'kaidifengji.com' =>
        array (
            'offset' => 13,
            'des_pre' => '蕙兰',
            'site_rute' => '/gpjou',
            'site_detail' => 'gisvs',
            'site_play' => 'dbbnm',
            'site_type' => 'muhei',
        ),
    'veganjohn.com' =>
        array (
            'offset' => 13,
            'des_pre' => '石竹',
            'site_rute' => '/byiru',
            'site_detail' => 'wzpft',
            'site_play' => 'trmop',
            'site_type' => 'pwtyo',
        ),
    'tjjfyyjx.com' =>
        array (
            'offset' => 13,
            'des_pre' => '桃花',
            'site_rute' => '/tuvgn',
            'site_detail' => 'ixtub',
            'site_play' => 'imjte',
            'site_type' => 'qilpf',
        ),
    'hzzcgy.com' =>
        array (
            'offset' => 13,
            'des_pre' => '文竹',
            'site_rute' => '/affsd',
            'site_detail' => 'ydoxm',
            'site_play' => 'jguup',
            'site_type' => 'qnryl',
        ),
    'easyhome-realty.com' =>
        array (
            'offset' => 13,
            'des_pre' => '玉兰',
            'site_rute' => '/xooic',
            'site_detail' => 'xvayd',
            'site_play' => 'rseux',
            'site_type' => 'rghpd',
        ),
    'diwndq.com' =>
        array (
            'offset' => 14,
            'des_pre' => '玉兰',
            'site_rute' => '/zuzmm',
            'site_detail' => 'xkboe',
            'site_play' => 'hccqt',
            'site_type' => 'ketth',
        ),
    'sldf150.com' =>
        array (
            'offset' => 14,
            'des_pre' => '天竺',
            'site_rute' => '/velbb',
            'site_detail' => 'qestz',
            'site_play' => 'lbozh',
            'site_type' => 'qnylr',
        ),
    'gpsoem114.com' =>
        array (
            'offset' => 14,
            'des_pre' => '罗兰',
            'site_rute' => '/zknkg',
            'site_detail' => 'axzsi',
            'site_play' => 'skplx',
            'site_type' => 'tuhbq',
        ),
    'puppeespot.com' =>
        array (
            'offset' => 14,
            'des_pre' => '寒兰',
            'site_rute' => '/zmrzn',
            'site_detail' => 'ruotg',
            'site_play' => 'xauyi',
            'site_type' => 'yzdij',
        ),
    'kajtez.com' =>
        array (
            'offset' => 14,
            'des_pre' => '墨兰',
            'site_rute' => '/eykfy',
            'site_detail' => 'asrlj',
            'site_play' => 'excvl',
            'site_type' => 'ohwhi',
        ),
    'dusecraft.com' =>
        array (
            'offset' => 14,
            'des_pre' => '天竺',
            'site_rute' => '/rwrij',
            'site_detail' => 'bwmhw',
            'site_play' => 'eblgl',
            'site_type' => 'kgixr',
        ),
    'fishnor.com' =>
        array (
            'offset' => 14,
            'des_pre' => '天竺',
            'site_rute' => '/sqjzx',
            'site_detail' => 'kgvbw',
            'site_play' => 'bzqxo',
            'site_type' => 'yzmtq',
        ),
    'realcapgame.com' =>
        array (
            'offset' => 14,
            'des_pre' => '翠菊',
            'site_rute' => '/qczzq',
            'site_detail' => 'zfrct',
            'site_play' => 'pdpzz',
            'site_type' => 'zgier',
        ),
    'navybrad.com' =>
        array (
            'offset' => 15,
            'des_pre' => '天竺',
            'site_rute' => '/ywbya',
            'site_detail' => 'pvobm',
            'site_play' => 'wkjfz',
            'site_type' => 'qrcly',
        ),
    'sinonilodge.com' =>
        array (
            'offset' => 15,
            'des_pre' => '春兰',
            'site_rute' => '/ameyv',
            'site_detail' => 'xfzzb',
            'site_play' => 'wmiav',
            'site_type' => 'lvkow',
        ),
    'hotelnorthsails.com' =>
        array (
            'offset' => 15,
            'des_pre' => '春菊',
            'site_rute' => '/msmzt',
            'site_detail' => 'ofnfc',
            'site_play' => 'qgjmm',
            'site_type' => 'iqiqz',
        ),
    'kunicool.com' =>
        array (
            'offset' => 15,
            'des_pre' => '春菊',
            'site_rute' => '/ajhza',
            'site_detail' => 'htbts',
            'site_play' => 'duujn',
            'site_type' => 'ofkho',
        ),
    'qxqygl.com' =>
        array (
            'offset' => 15,
            'des_pre' => '寒兰',
            'site_rute' => '/oifdw',
            'site_detail' => 'xkxgm',
            'site_play' => 'xnsrd',
            'site_type' => 'renzj',
        ),
    'ihouseidea.com' =>
        array (
            'offset' => 15,
            'des_pre' => '春菊',
            'site_rute' => '/rzqfr',
            'site_detail' => 'jlgxg',
            'site_play' => 'unakq',
            'site_type' => 'suqsh',
        ),
    'rogcomp.com' =>
        array (
            'offset' => 15,
            'des_pre' => '春兰',
            'site_rute' => '/seqnj',
            'site_detail' => 'zfhzh',
            'site_play' => 'buplb',
            'site_type' => 'hirpo',
        ),
    'yuyaju.com' =>
        array (
            'offset' => 15,
            'des_pre' => '蕙兰',
            'site_rute' => '/mpqlk',
            'site_detail' => 'znoyn',
            'site_play' => 'snfnc',
            'site_type' => 'yiqrj',
        ),
    'aurora-novato.com' =>
        array (
            'offset' => 15,
            'des_pre' => '罗兰',
            'site_rute' => '/enjss',
            'site_detail' => 'uicsh',
            'site_play' => 'pegjg',
            'site_type' => 'itxhl',
        ),
    'algratz.com' =>
        array (
            'offset' => 16,
            'des_pre' => '文竹',
            'site_rute' => '/jobzw',
            'site_detail' => 'scwyl',
            'site_play' => 'smxcs',
            'site_type' => 'znvyi',
        ),
    'laserachau.com' =>
        array (
            'offset' => 16,
            'des_pre' => '玉兰',
            'site_rute' => '/itver',
            'site_detail' => 'didvk',
            'site_play' => 'qdupc',
            'site_type' => 'eqtau',
        ),
    'wideopensecret.com' =>
        array (
            'offset' => 16,
            'des_pre' => '建兰',
            'site_rute' => '/zieiw',
            'site_detail' => 'gahio',
            'site_play' => 'vnmjz',
            'site_type' => 'ymfrw',
        ),
    'meiba123.com' =>
        array (
            'offset' => 16,
            'des_pre' => '文竹',
            'site_rute' => '/aewoa',
            'site_detail' => 'yhajm',
            'site_play' => 'uyqym',
            'site_type' => 'ndqva',
        ),
    'pokerrockets.com' =>
        array (
            'offset' => 16,
            'des_pre' => '罗兰',
            'site_rute' => '/qpqjh',
            'site_detail' => 'ihmom',
            'site_play' => 'kbpjl',
            'site_type' => 'xqilu',
        ),
    'hukakkk.com' =>
        array (
            'offset' => 16,
            'des_pre' => '墨兰',
            'site_rute' => '/idexm',
            'site_detail' => 'gpjvp',
            'site_play' => 'irfqi',
            'site_type' => 'qrzfv',
        ),
    'nxyxys.com' =>
        array (
            'offset' => 16,
            'des_pre' => '翠菊',
            'site_rute' => '/acgmq',
            'site_detail' => 'fmsyj',
            'site_play' => 'prvla',
            'site_type' => 'voltq',
        ),
    'dupedamerica.com' =>
        array (
            'offset' => 16,
            'des_pre' => '春菊',
            'site_rute' => '/cziup',
            'site_detail' => 'hzmlk',
            'site_play' => 'sorvp',
            'site_type' => 'wvjbh',
        ),
    'zdrummer.com' =>
        array (
            'offset' => 16,
            'des_pre' => '文竹',
            'site_rute' => '/wmgul',
            'site_detail' => 'pyedn',
            'site_play' => 'zkqmk',
            'site_type' => 'uktpt',
        ),
    'hszdcl.com' =>
        array (
            'offset' => 17,
            'des_pre' => '石竹',
            'site_rute' => '/pgdgq',
            'site_detail' => 'rbamc',
            'site_play' => 'gbtru',
            'site_type' => 'hbqbd',
        ),
    'thelittledayovo.com' =>
        array (
            'offset' => 17,
            'des_pre' => '罗兰',
            'site_rute' => '/jgzes',
            'site_detail' => 'tidmb',
            'site_play' => 'pxfmt',
            'site_type' => 'sfahh',
        ),
    'dgzqwj888.com' =>
        array (
            'offset' => 17,
            'des_pre' => '桃花',
            'site_rute' => '/fvpjy',
            'site_detail' => 'rwcpz',
            'site_play' => 'tvgah',
            'site_type' => 'lcdvt',
        ),
    'hotfunnysms.com' =>
        array (
            'offset' => 17,
            'des_pre' => '春菊',
            'site_rute' => '/xtocw',
            'site_detail' => 'novbq',
            'site_play' => 'bpykt',
            'site_type' => 'auwyj',
        ),
    'tuanvpn.com' =>
        array (
            'offset' => 17,
            'des_pre' => '桃花',
            'site_rute' => '/unljx',
            'site_detail' => 'pqvca',
            'site_play' => 'zfbvj',
            'site_type' => 'gzjqp',
        ),
    'cactusandsalad.com' =>
        array (
            'offset' => 17,
            'des_pre' => '石竹',
            'site_rute' => '/pqyjz',
            'site_detail' => 'xtjcv',
            'site_play' => 'jusws',
            'site_type' => 'nkacm',
        ),
    'cobaltspatial.com' =>
        array (
            'offset' => 17,
            'des_pre' => '春菊',
            'site_rute' => '/utzjk',
            'site_detail' => 'ckkbu',
            'site_play' => 'xkmua',
            'site_type' => 'eubsd',
        ),
    'calcurt.com' =>
        array (
            'offset' => 17,
            'des_pre' => '寒兰',
            'site_rute' => '/jgtct',
            'site_detail' => 'mrskw',
            'site_play' => 'tzurb',
            'site_type' => 'wshcq',
        ),
    'cdston.com' =>
        array (
            'offset' => 18,
            'des_pre' => '翠菊',
            'site_rute' => '/qlgwj',
            'site_detail' => 'bqfwh',
            'site_play' => 'pfhkw',
            'site_type' => 'grcyt',
        ),
    'qlbgsb.com' =>
        array (
            'offset' => 18,
            'des_pre' => '春菊',
            'site_rute' => '/uomgn',
            'site_detail' => 'qwedp',
            'site_play' => 'peilh',
            'site_type' => 'khiqz',
        ),
    'ssqlsc.com' =>
        array (
            'offset' => 18,
            'des_pre' => '罗兰',
            'site_rute' => '/pyzca',
            'site_detail' => 'gurvc',
            'site_play' => 'xmbea',
            'site_type' => 'ygfmh',
        ),
    'lufulou.com' =>
        array (
            'offset' => 18,
            'des_pre' => '天竺',
            'site_rute' => '/xovlo',
            'site_detail' => 'twegm',
            'site_play' => 'ceapd',
            'site_type' => 'utsea',
        ),
    'bibigun.com' =>
        array (
            'offset' => 18,
            'des_pre' => '桃花',
            'site_rute' => '/xcbph',
            'site_detail' => 'xemsu',
            'site_play' => 'wqfpj',
            'site_type' => 'lctzm',
        ),
    'markmancina.com' =>
        array (
            'offset' => 18,
            'des_pre' => '翠菊',
            'site_rute' => '/hoomc',
            'site_detail' => 'iquvg',
            'site_play' => 'xsjil',
            'site_type' => 'dpopr',
        ),
    'meinengkang.com' =>
        array (
            'offset' => 18,
            'des_pre' => '蕙兰',
            'site_rute' => '/gyxwf',
            'site_detail' => 'lqgxk',
            'site_play' => 'bgolp',
            'site_type' => 'avdol',
        ),
    'zhxmtz.com' =>
        array (
            'offset' => 18,
            'des_pre' => '春菊',
            'site_rute' => '/gqyco',
            'site_detail' => 'lfqkl',
            'site_play' => 'ldlne',
            'site_type' => 'vawva',
        ),
    'kiencuongsteel.com' =>
        array (
            'offset' => 19,
            'des_pre' => '玉兰',
            'site_rute' => '/cragf',
            'site_detail' => 'cisha',
            'site_play' => 'yuxhu',
            'site_type' => 'mdhcz',
        ),
    'yipinyuzhai.com' =>
        array (
            'offset' => 19,
            'des_pre' => '翠菊',
            'site_rute' => '/kjegg',
            'site_detail' => 'kxjxq',
            'site_play' => 'itxzo',
            'site_type' => 'sadfs',
        ),
    'vilunddesign.com' =>
        array (
            'offset' => 19,
            'des_pre' => '石竹',
            'site_rute' => '/njsci',
            'site_detail' => 'eijlv',
            'site_play' => 'nfnkn',
            'site_type' => 'nkhov',
        ),
    'ppbcycling.com' =>
        array (
            'offset' => 19,
            'des_pre' => '寒兰',
            'site_rute' => '/zbkbz',
            'site_detail' => 'uksck',
            'site_play' => 'kqlux',
            'site_type' => 'qteso',
        ),
    'diftnorm.com' =>
        array (
            'offset' => 19,
            'des_pre' => '石竹',
            'site_rute' => '/hhnay',
            'site_detail' => 'feabq',
            'site_play' => 'igcea',
            'site_type' => 'ktbgy',
        ),
    'softble.com' =>
        array (
            'offset' => 19,
            'des_pre' => '天竺',
            'site_rute' => '/jlwrk',
            'site_detail' => 'selzr',
            'site_play' => 'vaomb',
            'site_type' => 'lbgvg',
        ),
    'syzhbz.com' =>
        array (
            'offset' => 19,
            'des_pre' => '桃花',
            'site_rute' => '/aeiyc',
            'site_detail' => 'tzaxc',
            'site_play' => 'gsygx',
            'site_type' => 'zvfuy',
        ),
    'masterartltd.com' =>
        array (
            'offset' => 20,
            'des_pre' => '玉兰',
            'site_rute' => '/ckjbw',
            'site_detail' => 'jratb',
            'site_play' => 'kqsze',
            'site_type' => 'ykmiq',
        ),
    'tecnofus.net' =>
        array (
            'offset' => 20,
            'des_pre' => '墨兰',
            'site_rute' => '/nlnib',
            'site_detail' => 'lbyzt',
            'site_play' => 'wfdal',
            'site_type' => 'kqivd',
        ),
    'wanjiazhuang.com' =>
        array (
            'offset' => 20,
            'des_pre' => '春菊',
            'site_rute' => '/rmqdx',
            'site_detail' => 'yvovn',
            'site_play' => 'jxqql',
            'site_type' => 'ogkzc',
        ),
    'delindamorgan.com' =>
        array (
            'offset' => 20,
            'des_pre' => '海棠',
            'site_rute' => '/twppw',
            'site_detail' => 'xbjac',
            'site_play' => 'ragcx',
            'site_type' => 'ryzrd',
        ),
    'wojomojo.com' =>
        array (
            'offset' => 20,
            'des_pre' => '天竺',
            'site_rute' => '/gxyzt',
            'site_detail' => 'pakza',
            'site_play' => 'rmcmd',
            'site_type' => 'bksve',
        ),
    'sounddecisiontn.com' =>
        array (
            'offset' => 20,
            'des_pre' => '蕙兰',
            'site_rute' => '/dealj',
            'site_detail' => 'fqwcw',
            'site_play' => 'hnqdz',
            'site_type' => 'wfrxe',
        ),
    'emclifesales.com' =>
        array (
            'offset' => 20,
            'des_pre' => '春兰',
            'site_rute' => '/zwdbw',
            'site_detail' => 'aqczx',
            'site_play' => 'xyien',
            'site_type' => 'mbjpd',
        ),
    'beuniqueuae.com' =>
        array (
            'offset' => 20,
            'des_pre' => '文竹',
            'site_rute' => '/zdpff',
            'site_detail' => 'pxedc',
            'site_play' => 'tmtwh',
            'site_type' => 'kdrkc',
        ),
    'mega-magic.com' =>
        array (
            'offset' => 20,
            'des_pre' => '罗兰',
            'site_rute' => '/iacix',
            'site_detail' => 'fpgfr',
            'site_play' => 'eurxj',
            'site_type' => 'iddkj',
        ),
    'xiguakuo.com' =>
        array (
            'offset' => 21,
            'des_pre' => '罗兰',
            'site_rute' => '/aabfs',
            'site_detail' => 'bdpfo',
            'site_play' => 'ueeey',
            'site_type' => 'ertqv',
        ),
    'swoopbrand.com' =>
        array (
            'offset' => 21,
            'des_pre' => '墨兰',
            'site_rute' => '/bmagq',
            'site_detail' => 'dmdzq',
            'site_play' => 'tnjgx',
            'site_type' => 'ymcom',
        ),
    'fincaskapital.com' =>
        array (
            'offset' => 21,
            'des_pre' => '石竹',
            'site_rute' => '/tdxcu',
            'site_detail' => 'ptrym',
            'site_play' => 'eivoc',
            'site_type' => 'lewms',
        ),
    'sanfordcolorado.com' =>
        array (
            'offset' => 21,
            'des_pre' => '蕙兰',
            'site_rute' => '/zuujn',
            'site_detail' => 'grwdy',
            'site_play' => 'gbpjp',
            'site_type' => 'uotoq',
        ),
    'hideal.net' =>
        array (
            'offset' => 21,
            'des_pre' => '天竺',
            'site_rute' => '/oklph',
            'site_detail' => 'eoirj',
            'site_play' => 'otfbl',
            'site_type' => 'zzwdh',
        ),
    'beijingzhongyue.com' =>
        array (
            'offset' => 21,
            'des_pre' => '玉兰',
            'site_rute' => '/wifys',
            'site_detail' => 'bopps',
            'site_play' => 'zgibi',
            'site_type' => 'owial',
        ),
    'bieaoqx.com' =>
        array (
            'offset' => 21,
            'des_pre' => '天竺',
            'site_rute' => '/puyxg',
            'site_detail' => 'ilbcv',
            'site_play' => 'saihi',
            'site_type' => 'ibjhz',
        ),
    'honggedichan.com' =>
        array (
            'offset' => 21,
            'des_pre' => '桃花',
            'site_rute' => '/hxhmi',
            'site_detail' => 'ibutk',
            'site_play' => 'nexbx',
            'site_type' => 'tteiy',
        ),
    'wuhanshangji.com' =>
        array (
            'offset' => 22,
            'des_pre' => '寒兰',
            'site_rute' => '/romzo',
            'site_detail' => 'ijklm',
            'site_play' => 'byvbi',
            'site_type' => 'qzekr',
        ),
    'macaiw.com' =>
        array (
            'offset' => 22,
            'des_pre' => '天竺',
            'site_rute' => '/rkjpv',
            'site_detail' => 'fpwvt',
            'site_play' => 'rfhmk',
            'site_type' => 'icrjm',
        ),
    'nubreeddev.com' =>
        array (
            'offset' => 22,
            'des_pre' => '春菊',
            'site_rute' => '/fgonp',
            'site_detail' => 'lvlwx',
            'site_play' => 'lqple',
            'site_type' => 'olgwr',
        ),
    'syxhjsj.com' =>
        array (
            'offset' => 22,
            'des_pre' => '墨兰',
            'site_rute' => '/xuotd',
            'site_detail' => 'bxpdo',
            'site_play' => 'mxtxx',
            'site_type' => 'fwbww',
        ),
    'yfjscn.com' =>
        array (
            'offset' => 22,
            'des_pre' => '春兰',
            'site_rute' => '/ptlir',
            'site_detail' => 'fqagt',
            'site_play' => 'comry',
            'site_type' => 'eufio',
        ),
    'wsqy888.com' =>
        array (
            'offset' => 22,
            'des_pre' => '建兰',
            'site_rute' => '/rypkz',
            'site_detail' => 'ukbbg',
            'site_play' => 'uputi',
            'site_type' => 'gbsaf',
        ),
    'tangzhongren.com' =>
        array (
            'offset' => 22,
            'des_pre' => '墨兰',
            'site_rute' => '/nqdzd',
            'site_detail' => 'nmvpo',
            'site_play' => 'lvxsm',
            'site_type' => 'wglxr',
        ),
    'caijingcun.com' =>
        array (
            'offset' => 23,
            'des_pre' => '海棠',
            'site_rute' => '/xqkep',
            'site_detail' => 'vvgub',
            'site_play' => 'qhprt',
            'site_type' => 'ziuno',
        ),
    'richharvest.net' =>
        array (
            'offset' => 23,
            'des_pre' => '桃花',
            'site_rute' => '/tqxmr',
            'site_detail' => 'oxykg',
            'site_play' => 'yvybq',
            'site_type' => 'ujaix',
        ),
    'sdpy365.com' =>
        array (
            'offset' => 23,
            'des_pre' => '春兰',
            'site_rute' => '/pvpmf',
            'site_detail' => 'eunmy',
            'site_play' => 'kvoux',
            'site_type' => 'rgjlk',
        ),
    'garabettavitjan.com' =>
        array (
            'offset' => 23,
            'des_pre' => '春兰',
            'site_rute' => '/nskkn',
            'site_detail' => 'rdtjp',
            'site_play' => 'nvetw',
            'site_type' => 'ufgqc',
        ),
    'thecenterforpt.com' =>
        array (
            'offset' => 23,
            'des_pre' => '墨兰',
            'site_rute' => '/jpgjy',
            'site_detail' => 'dtnvk',
            'site_play' => 'khbvr',
            'site_type' => 'nmdeo',
        ),
    'debbieajohnson.com' =>
        array (
            'offset' => 23,
            'des_pre' => '玉兰',
            'site_rute' => '/qepan',
            'site_detail' => 'tleed',
            'site_play' => 'xwmhd',
            'site_type' => 'xtufu',
        ),
    'kinumedicina.com' =>
        array (
            'offset' => 23,
            'des_pre' => '玉兰',
            'site_rute' => '/jsnzc',
            'site_detail' => 'yzihf',
            'site_play' => 'ebnzq',
            'site_type' => 'pxhgy',
        ),
    'fjzpbz.com' =>
        array (
            'offset' => 23,
            'des_pre' => '墨兰',
            'site_rute' => '/vsvfn',
            'site_detail' => 'pmowa',
            'site_play' => 'aojva',
            'site_type' => 'itbws',
        ),
    'boweishangmao.com' =>
        array (
            'offset' => 23,
            'des_pre' => '罗兰',
            'site_rute' => '/vwpcd',
            'site_detail' => 'eprvo',
            'site_play' => 'zzzfm',
            'site_type' => 'fsqbu',
        ),
    'pa-zone.com' =>
        array (
            'offset' => 24,
            'des_pre' => '桃花',
            'site_rute' => '/lkeyu',
            'site_detail' => 'yxzjz',
            'site_play' => 'pcnih',
            'site_type' => 'yeclc',
        ),
    'ltcp898.com' =>
        array (
            'offset' => 24,
            'des_pre' => '春菊',
            'site_rute' => '/gyxmw',
            'site_detail' => 'igbxb',
            'site_play' => 'tnieb',
            'site_type' => 'baogc',
        ),
    'ionhotelbatam.com' =>
        array (
            'offset' => 24,
            'des_pre' => '文竹',
            'site_rute' => '/fvhac',
            'site_detail' => 'yfrna',
            'site_play' => 'koglp',
            'site_type' => 'crmlx',
        ),
    'pencilwritten.com' =>
        array (
            'offset' => 24,
            'des_pre' => '墨兰',
            'site_rute' => '/khtya',
            'site_detail' => 'ycddw',
            'site_play' => 'yddaq',
            'site_type' => 'ajaog',
        ),
    'univanp.com' =>
        array (
            'offset' => 24,
            'des_pre' => '桃花',
            'site_rute' => '/cunqa',
            'site_detail' => 'cepcx',
            'site_play' => 'zsewn',
            'site_type' => 'bbgyd',
        ),
    'lizhzh.com' =>
        array (
            'offset' => 24,
            'des_pre' => '寒兰',
            'site_rute' => '/hkjus',
            'site_detail' => 'znmce',
            'site_play' => 'iialk',
            'site_type' => 'jlihw',
        ),
    'montereywaves.com' =>
        array (
            'offset' => 24,
            'des_pre' => '天竺',
            'site_rute' => '/pkbxy',
            'site_detail' => 'fqiuf',
            'site_play' => 'ctylv',
            'site_type' => 'ujzrg',
        ),
    'exstudio.net' =>
        array (
            'offset' => 24,
            'des_pre' => '桃花',
            'site_rute' => '/ewktn',
            'site_detail' => 'zhuls',
            'site_play' => 'rzysw',
            'site_type' => 'qxucd',
        ),
    'panshiyu.com' =>
        array (
            'offset' => 24,
            'des_pre' => '翠菊',
            'site_rute' => '/dgass',
            'site_detail' => 'sdref',
            'site_play' => 'vlnqj',
            'site_type' => 'ypnsk',
        ),
    'escape2malaysia.com' =>
        array (
            'offset' => 25,
            'des_pre' => '天竺',
            'site_rute' => '/jmkpe',
            'site_detail' => 'gvwhs',
            'site_play' => 'jkekx',
            'site_type' => 'prlmv',
        ),
    'rovelvalves.com' =>
        array (
            'offset' => 25,
            'des_pre' => '春兰',
            'site_rute' => '/pmgjv',
            'site_detail' => 'eiprt',
            'site_play' => 'snsxd',
            'site_type' => 'jzbni',
        ),
    'plasticcardsale.com' =>
        array (
            'offset' => 25,
            'des_pre' => '春菊',
            'site_rute' => '/oopnf',
            'site_detail' => 'kfssg',
            'site_play' => 'ykhch',
            'site_type' => 'cvxrz',
        ),
    'hannahsbandb.com' =>
        array (
            'offset' => 25,
            'des_pre' => '石竹',
            'site_rute' => '/qyayq',
            'site_detail' => 'hlywn',
            'site_play' => 'vpzna',
            'site_type' => 'ciluj',
        ),
    'innopticstw.com' =>
        array (
            'offset' => 25,
            'des_pre' => '天竺',
            'site_rute' => '/jiygk',
            'site_detail' => 'zdjob',
            'site_play' => 'nqodk',
            'site_type' => 'zseju',
        ),
    'shivamabrasive.com' =>
        array (
            'offset' => 25,
            'des_pre' => '建兰',
            'site_rute' => '/hsvqf',
            'site_detail' => 'osrvn',
            'site_play' => 'tkzqa',
            'site_type' => 'kisgf',
        ),
    'dylmfg.com' =>
        array (
            'offset' => 26,
            'des_pre' => '罗兰',
            'site_rute' => '/ibuws',
            'site_detail' => 'btpsz',
            'site_play' => 'xaywk',
            'site_type' => 'meyrj',
        ),
    'lydiaoyan.com' =>
        array (
            'offset' => 26,
            'des_pre' => '天竺',
            'site_rute' => '/uzphd',
            'site_detail' => 'yqkke',
            'site_play' => 'rueqg',
            'site_type' => 'xflnz',
        ),
    'photomonic.com' =>
        array (
            'offset' => 26,
            'des_pre' => '蕙兰',
            'site_rute' => '/lhrty',
            'site_detail' => 'qjppo',
            'site_play' => 'wlxmk',
            'site_type' => 'rhtdm',
        ),
    'soundtemp.com' =>
        array (
            'offset' => 26,
            'des_pre' => '建兰',
            'site_rute' => '/ywwse',
            'site_detail' => 'pqskh',
            'site_play' => 'axrmv',
            'site_type' => 'omwtt',
        ),
    'safarman.com' =>
        array (
            'offset' => 26,
            'des_pre' => '寒兰',
            'site_rute' => '/bkpzj',
            'site_detail' => 'vurcn',
            'site_play' => 'fvjgr',
            'site_type' => 'ureva',
        ),
    'eninexpaint.com' =>
        array (
            'offset' => 26,
            'des_pre' => '海棠',
            'site_rute' => '/fccnt',
            'site_detail' => 'hjucu',
            'site_play' => 'zypep',
            'site_type' => 'qwtrg',
        ),
    'bcisportsdogs.com' =>
        array (
            'offset' => 26,
            'des_pre' => '海棠',
            'site_rute' => '/huzzr',
            'site_detail' => 'dioze',
            'site_play' => 'zxdtv',
            'site_type' => 'jkyzf',
        ),
    'skihirewhistler.com' =>
        array (
            'offset' => 26,
            'des_pre' => '玉兰',
            'site_rute' => '/boidt',
            'site_detail' => 'wbszr',
            'site_play' => 'qwfet',
            'site_type' => 'ugvbq',
        ),
    'peluqueriajuan.com' =>
        array (
            'offset' => 26,
            'des_pre' => '寒兰',
            'site_rute' => '/skeed',
            'site_detail' => 'twjyo',
            'site_play' => 'xokrp',
            'site_type' => 'fhdpq',
        ),
    'ddddbaby.com' =>
        array (
            'offset' => 27,
            'des_pre' => '石竹',
            'site_rute' => '/grvwm',
            'site_detail' => 'qgfqd',
            'site_play' => 'qndcg',
            'site_type' => 'uiuop',
        ),
    'pws-kokusei.com' =>
        array (
            'offset' => 27,
            'des_pre' => '文竹',
            'site_rute' => '/yfchu',
            'site_detail' => 'waeee',
            'site_play' => 'otlrg',
            'site_type' => 'ttzdz',
        ),
    'lshtzm.com' =>
        array (
            'offset' => 27,
            'des_pre' => '文竹',
            'site_rute' => '/icjcq',
            'site_detail' => 'gzbxi',
            'site_play' => 'hntwm',
            'site_type' => 'szeyl',
        ),
    'muchemwasichone.com' =>
        array (
            'offset' => 27,
            'des_pre' => '春兰',
            'site_rute' => '/pmovk',
            'site_detail' => 'dlpzx',
            'site_play' => 'hbggz',
            'site_type' => 'hwopw',
        ),
    'carver-india.com' =>
        array (
            'offset' => 27,
            'des_pre' => '春兰',
            'site_rute' => '/bgxow',
            'site_detail' => 'hsoso',
            'site_play' => 'nlzsw',
            'site_type' => 'yktko',
        ),
    'xhoseinventor.com' =>
        array (
            'offset' => 27,
            'des_pre' => '文竹',
            'site_rute' => '/iakbg',
            'site_detail' => 'wsdxz',
            'site_play' => 'oamxm',
            'site_type' => 'ekhut',
        ),
    'cheng91.com' =>
        array (
            'offset' => 27,
            'des_pre' => '海棠',
            'site_rute' => '/zwcbq',
            'site_detail' => 'wrcdr',
            'site_play' => 'hcvfu',
            'site_type' => 'rwiov',
        ),
    'lylmscc.com' =>
        array (
            'offset' => 27,
            'des_pre' => '寒兰',
            'site_rute' => '/tcmlx',
            'site_detail' => 'yfgjl',
            'site_play' => 'grhgs',
            'site_type' => 'bavwe',
        ),
    'articlepush.com' =>
        array (
            'offset' => 27,
            'des_pre' => '墨兰',
            'site_rute' => '/jevuq',
            'site_detail' => 'ydzic',
            'site_play' => 'uhzio',
            'site_type' => 'coota',
        ),
    'sugarpy.com' =>
        array (
            'offset' => 28,
            'des_pre' => '春兰',
            'site_rute' => '/ldzsm',
            'site_detail' => 'jrsjr',
            'site_play' => 'demgp',
            'site_type' => 'kjztg',
        ),
    'catarinomoreira.com' =>
        array (
            'offset' => 28,
            'des_pre' => '玉兰',
            'site_rute' => '/dsxsg',
            'site_detail' => 'uuyzi',
            'site_play' => 'psqao',
            'site_type' => 'cmyfm',
        ),
    'tljsjhw.com' =>
        array (
            'offset' => 28,
            'des_pre' => '墨兰',
            'site_rute' => '/ynvle',
            'site_detail' => 'ucakb',
            'site_play' => 'ohvjk',
            'site_type' => 'kstko',
        ),
    'e-fila.com' =>
        array (
            'offset' => 28,
            'des_pre' => '翠菊',
            'site_rute' => '/mjxec',
            'site_detail' => 'rpmpf',
            'site_play' => 'wjzbn',
            'site_type' => 'tuwqh',
        ),
    'axing8.com' =>
        array (
            'offset' => 28,
            'des_pre' => '建兰',
            'site_rute' => '/iwuzp',
            'site_detail' => 'lnisf',
            'site_play' => 'fawqb',
            'site_type' => 'zjlbl',
        ),
    'vertexbroadband.com' =>
        array (
            'offset' => 28,
            'des_pre' => '石竹',
            'site_rute' => '/qctel',
            'site_detail' => 'gwjfc',
            'site_play' => 'iyrqo',
            'site_type' => 'zkxxm',
        ),
    'ttmy999.com' =>
        array (
            'offset' => 28,
            'des_pre' => '石竹',
            'site_rute' => '/exmjx',
            'site_detail' => 'ellmk',
            'site_play' => 'ntmyi',
            'site_type' => 'kdjlg',
        ),
    'hldyzz.com' =>
        array (
            'offset' => 29,
            'des_pre' => '墨兰',
            'site_rute' => '/umorc',
            'site_detail' => 'kuekr',
            'site_play' => 'szuan',
            'site_type' => 'gwnvm',
        ),
    'huomaozi.com' =>
        array (
            'offset' => 29,
            'des_pre' => '文竹',
            'site_rute' => '/jihyx',
            'site_detail' => 'akqdm',
            'site_play' => 'jzhmh',
            'site_type' => 'dhaqk',
        ),
    'yinengyejin.com' =>
        array (
            'offset' => 29,
            'des_pre' => '寒兰',
            'site_rute' => '/sfjah',
            'site_detail' => 'zbpal',
            'site_play' => 'yjrwj',
            'site_type' => 'obnvw',
        ),
    'vipgongjue.com' =>
        array (
            'offset' => 29,
            'des_pre' => '春兰',
            'site_rute' => '/uypsb',
            'site_detail' => 'emybm',
            'site_play' => 'kolyj',
            'site_type' => 'qcjck',
        ),
    'zhaotaoke.com' =>
        array (
            'offset' => 29,
            'des_pre' => '文竹',
            'site_rute' => '/terlp',
            'site_detail' => 'xifjl',
            'site_play' => 'xuhet',
            'site_type' => 'msihv',
        ),
    'sakamatiya.com' =>
        array (
            'offset' => 29,
            'des_pre' => '寒兰',
            'site_rute' => '/levlw',
            'site_detail' => 'zadzl',
            'site_play' => 'vyyrt',
            'site_type' => 'mkwsk',
        ),
    'iamjustlooking.com' =>
        array (
            'offset' => 29,
            'des_pre' => '罗兰',
            'site_rute' => '/mtxmu',
            'site_detail' => 'opvwv',
            'site_play' => 'phwyu',
            'site_type' => 'tnktr',
        ),
    'multicadres.com' =>
        array (
            'offset' => 29,
            'des_pre' => '罗兰',
            'site_rute' => '/thsmi',
            'site_detail' => 'waxor',
            'site_play' => 'cqepg',
            'site_type' => 'sygsu',
        ),
    'meiermg.com' =>
        array (
            'offset' => 29,
            'des_pre' => '天竺',
            'site_rute' => '/yhtwf',
            'site_detail' => 'dqryt',
            'site_play' => 'pqdos',
            'site_type' => 'pmwcj',
        ),
    'chinamuqiang.com' =>
        array (
            'offset' => 30,
            'des_pre' => '建兰',
            'site_rute' => '/oonje',
            'site_detail' => 'sjjxs',
            'site_play' => 'ywlwc',
            'site_type' => 'meprs',
        ),
    'buyarmysurplus.com' =>
        array (
            'offset' => 30,
            'des_pre' => '建兰',
            'site_rute' => '/ejfym',
            'site_detail' => 'xrnqx',
            'site_play' => 'egzvg',
            'site_type' => 'avqfv',
        ),
    'applimetrix.com' =>
        array (
            'offset' => 30,
            'des_pre' => '翠菊',
            'site_rute' => '/vqzbx',
            'site_detail' => 'sjfgo',
            'site_play' => 'raqkr',
            'site_type' => 'wbmsf',
        ),
    'helmam.com' =>
        array (
            'offset' => 30,
            'des_pre' => '玉兰',
            'site_rute' => '/degil',
            'site_detail' => 'cwjwp',
            'site_play' => 'enboy',
            'site_type' => 'mbzmq',
        ),
    'cqqdbz.com' =>
        array (
            'offset' => 30,
            'des_pre' => '海棠',
            'site_rute' => '/egtov',
            'site_detail' => 'griqb',
            'site_play' => 'uvegz',
            'site_type' => 'czzpv',
        ),
    'worldpinstravel.com' =>
        array (
            'offset' => 30,
            'des_pre' => '玉兰',
            'site_rute' => '/vxinu',
            'site_detail' => 'mtylm',
            'site_play' => 'zlklj',
            'site_type' => 'elhcb',
        ),
    'luohehaoyuan.com' =>
        array (
            'offset' => 30,
            'des_pre' => '海棠',
            'site_rute' => '/iqykd',
            'site_detail' => 'armsm',
            'site_play' => 'dztjc',
            'site_type' => 'zqziy',
        ),
    'xiaomifenggj.com' =>
        array (
            'offset' => 30,
            'des_pre' => '天竺',
            'site_rute' => '/nnwga',
            'site_detail' => 'kzxud',
            'site_play' => 'apewj',
            'site_type' => 'wbtmn',
        ),
    'valeraine.com' =>
        array (
            'offset' => 30,
            'des_pre' => '天竺',
            'site_rute' => '/xjosz',
            'site_detail' => 'wonrk',
            'site_play' => 'esafy',
            'site_type' => 'epadq',
        ),
    'bjchanchu.com' =>
        array (
            'offset' => 31,
            'des_pre' => '翠菊',
            'site_rute' => '/ehane',
            'site_detail' => 'zkson',
            'site_play' => 'ohauh',
            'site_type' => 'mezuy',
        ),
    'bopaide.com' =>
        array (
            'offset' => 31,
            'des_pre' => '桃花',
            'site_rute' => '/cvpyh',
            'site_detail' => 'yttac',
            'site_play' => 'krqwk',
            'site_type' => 'mqokw',
        ),
    'fudaola.com' =>
        array (
            'offset' => 31,
            'des_pre' => '罗兰',
            'site_rute' => '/zeavr',
            'site_detail' => 'gshkq',
            'site_play' => 'bcfgp',
            'site_type' => 'loibg',
        ),
    'cccchd.com' =>
        array (
            'offset' => 31,
            'des_pre' => '桃花',
            'site_rute' => '/phhoo',
            'site_detail' => 'fhvet',
            'site_play' => 'gnfqw',
            'site_type' => 'eeaak',
        ),
    'tzjhcb.com' =>
        array (
            'offset' => 31,
            'des_pre' => '寒兰',
            'site_rute' => '/valbu',
            'site_detail' => 'jbjhf',
            'site_play' => 'zrkeg',
            'site_type' => 'lxerd',
        ),
    'shinsouke.com' =>
        array (
            'offset' => 31,
            'des_pre' => '文竹',
            'site_rute' => '/kdnxo',
            'site_detail' => 'crtbg',
            'site_play' => 'gzhki',
            'site_type' => 'noiwx',
        ),
    'pyhygc.com' =>
        array (
            'offset' => 31,
            'des_pre' => '春菊',
            'site_rute' => '/nfwol',
            'site_detail' => 'pcysq',
            'site_play' => 'dmwvk',
            'site_type' => 'aatuq',
        ),
    'qzchws.com' =>
        array (
            'offset' => 31,
            'des_pre' => '文竹',
            'site_rute' => '/tlhfo',
            'site_detail' => 'mnwar',
            'site_play' => 'djlii',
            'site_type' => 'qcpug',
        ),
    'sdlzlj.com' =>
        array (
            'offset' => 32,
            'des_pre' => '海棠',
            'site_rute' => '/sopvp',
            'site_detail' => 'gjbgg',
            'site_play' => 'ssqrf',
            'site_type' => 'zdkxd',
        ),
    'alikaoshi.com' =>
        array (
            'offset' => 32,
            'des_pre' => '桃花',
            'site_rute' => '/aotdu',
            'site_detail' => 'vsrsa',
            'site_play' => 'kfhzf',
            'site_type' => 'xpyon',
        ),
    'yongyuesrq.com' =>
        array (
            'offset' => 32,
            'des_pre' => '春兰',
            'site_rute' => '/exxjb',
            'site_detail' => 'dniic',
            'site_play' => 'biykc',
            'site_type' => 'dhrtr',
        ),
    'xynewone.com' =>
        array (
            'offset' => 32,
            'des_pre' => '建兰',
            'site_rute' => '/lxiqy',
            'site_detail' => 'dwrtg',
            'site_play' => 'pavoc',
            'site_type' => 'jqoek',
        ),
    'mylove1314178.com' =>
        array (
            'offset' => 32,
            'des_pre' => '寒兰',
            'site_rute' => '/bhmey',
            'site_detail' => 'ekzax',
            'site_play' => 'nfczl',
            'site_type' => 'lnboz',
        ),
    'lifebymb.com' =>
        array (
            'offset' => 32,
            'des_pre' => '海棠',
            'site_rute' => '/ivxfp',
            'site_detail' => 'gfefv',
            'site_play' => 'bylqd',
            'site_type' => 'dxqmm',
        ),
    'mountdoracigars.com' =>
        array (
            'offset' => 32,
            'des_pre' => '春兰',
            'site_rute' => '/dmwvt',
            'site_detail' => 'hayrl',
            'site_play' => 'zzwuy',
            'site_type' => 'pkdxk',
        ),
    'serkankasirga.com' =>
        array (
            'offset' => 32,
            'des_pre' => '海棠',
            'site_rute' => '/cvxix',
            'site_detail' => 'uhwtu',
            'site_play' => 'wcdtf',
            'site_type' => 'jlfmb',
        ),
    'pyxxml.com' =>
        array (
            'offset' => 33,
            'des_pre' => '罗兰',
            'site_rute' => '/kpljx',
            'site_detail' => 'vghio',
            'site_play' => 'jiivy',
            'site_type' => 'vikfc',
        ),
    'bjgrzy.com' =>
        array (
            'offset' => 33,
            'des_pre' => '罗兰',
            'site_rute' => '/dqntg',
            'site_detail' => 'byuff',
            'site_play' => 'iafpw',
            'site_type' => 'bwhtr',
        ),
    'qinzhouvip.com' =>
        array (
            'offset' => 33,
            'des_pre' => '墨兰',
            'site_rute' => '/txjrw',
            'site_detail' => 'ystcj',
            'site_play' => 'pnino',
            'site_type' => 'urjkb',
        ),
    'saturnacottage.com' =>
        array (
            'offset' => 33,
            'des_pre' => '建兰',
            'site_rute' => '/uocxh',
            'site_detail' => 'abiqr',
            'site_play' => 'rmtih',
            'site_type' => 'nuuoi',
        ),
    'bedwascomputers.com' =>
        array (
            'offset' => 33,
            'des_pre' => '天竺',
            'site_rute' => '/cfezg',
            'site_detail' => 'gbwqf',
            'site_play' => 'vnril',
            'site_type' => 'ckzsj',
        ),
    'jinhua1239.com' =>
        array (
            'offset' => 33,
            'des_pre' => '罗兰',
            'site_rute' => '/rloox',
            'site_detail' => 'xoeza',
            'site_play' => 'rtprk',
            'site_type' => 'zdrtc',
        ),
    'shyd001.com' =>
        array (
            'offset' => 33,
            'des_pre' => '翠菊',
            'site_rute' => '/kjsyu',
            'site_detail' => 'igwfz',
            'site_play' => 'qazmm',
            'site_type' => 'ugwng',
        ),
    'britnifletcher.com' =>
        array (
            'offset' => 33,
            'des_pre' => '文竹',
            'site_rute' => '/ksfnr',
            'site_detail' => 'xugto',
            'site_play' => 'ajpto',
            'site_type' => 'wzxly',
        ),
    'jxkxfc.com' =>
        array (
            'offset' => 33,
            'des_pre' => '罗兰',
            'site_rute' => '/oinpw',
            'site_detail' => 'abwfp',
            'site_play' => 'dscxg',
            'site_type' => 'afbal',
        ),
    'jinhuihxt.com' =>
        array (
            'offset' => 34,
            'des_pre' => '翠菊',
            'site_rute' => '/zyqfo',
            'site_detail' => 'zkuof',
            'site_play' => 'lztig',
            'site_type' => 'jxztx',
        ),
    'ccidover.com' =>
        array (
            'offset' => 34,
            'des_pre' => '春菊',
            'site_rute' => '/cfpkl',
            'site_detail' => 'acvlh',
            'site_play' => 'gyqvu',
            'site_type' => 'ptuhf',
        ),
    'gbsitalia.com' =>
        array (
            'offset' => 34,
            'des_pre' => '春兰',
            'site_rute' => '/xjzty',
            'site_detail' => 'fmqun',
            'site_play' => 'prmnl',
            'site_type' => 'psych',
        ),
    'the-positron.com' =>
        array (
            'offset' => 34,
            'des_pre' => '海棠',
            'site_rute' => '/qrfjc',
            'site_detail' => 'fpdaf',
            'site_play' => 'fnfrq',
            'site_type' => 'ftyue',
        ),
    'fsryfz.com' =>
        array (
            'offset' => 34,
            'des_pre' => '春兰',
            'site_rute' => '/tkhfh',
            'site_detail' => 'qckpw',
            'site_play' => 'ozovu',
            'site_type' => 'ruogp',
        ),
    'cruise-plus.com' =>
        array (
            'offset' => 34,
            'des_pre' => '海棠',
            'site_rute' => '/ncvty',
            'site_detail' => 'fvxwq',
            'site_play' => 'fglgt',
            'site_type' => 'tsdwt',
        ),
    'gongzhulingdir.com' =>
        array (
            'offset' => 34,
            'des_pre' => '文竹',
            'site_rute' => '/etueh',
            'site_detail' => 'emeya',
            'site_play' => 'ugusc',
            'site_type' => 'gnjup',
        ),
    'zjhgtx.com' =>
        array (
            'offset' => 34,
            'des_pre' => '石竹',
            'site_rute' => '/skqpk',
            'site_detail' => 'idoqb',
            'site_play' => 'zgweo',
            'site_type' => 'cifbp',
        ),
    'pnjx666.com' =>
        array (
            'offset' => 34,
            'des_pre' => '春菊',
            'site_rute' => '/nnlkn',
            'site_detail' => 'rdqfn',
            'site_play' => 'qxnvj',
            'site_type' => 'auaxt',
        ),
    'weitaici.com' =>
        array (
            'offset' => 35,
            'des_pre' => '翠菊',
            'site_rute' => '/jmtld',
            'site_detail' => 'lhlbb',
            'site_play' => 'beiww',
            'site_type' => 'kiiop',
        ),
    'xxrikang.com' =>
        array (
            'offset' => 35,
            'des_pre' => '春兰',
            'site_rute' => '/kozts',
            'site_detail' => 'mdrrh',
            'site_play' => 'adcni',
            'site_type' => 'ozvpk',
        ),
    'myamplemax.com' =>
        array (
            'offset' => 35,
            'des_pre' => '蕙兰',
            'site_rute' => '/hobsr',
            'site_detail' => 'olnjo',
            'site_play' => 'yewop',
            'site_type' => 'hjejv',
        ),
    'lhgjsm.com' =>
        array (
            'offset' => 35,
            'des_pre' => '文竹',
            'site_rute' => '/gqgac',
            'site_detail' => 'yspkx',
            'site_play' => 'errpn',
            'site_type' => 'dtvgn',
        ),
    'gay-farmer.com' =>
        array (
            'offset' => 35,
            'des_pre' => '玉兰',
            'site_rute' => '/fdvev',
            'site_detail' => 'iosnb',
            'site_play' => 'dturw',
            'site_type' => 'vkdhk',
        ),
    'livelyrecipes.com' =>
        array (
            'offset' => 35,
            'des_pre' => '石竹',
            'site_rute' => '/ahmdz',
            'site_detail' => 'shpox',
            'site_play' => 'njqsd',
            'site_type' => 'refmz',
        ),
    'jiefengjidian.com' =>
        array (
            'offset' => 35,
            'des_pre' => '罗兰',
            'site_rute' => '/cfzzm',
            'site_detail' => 'kyjux',
            'site_play' => 'cjbdt',
            'site_type' => 'dgffm',
        ),
    'srilankaprint.com' =>
        array (
            'offset' => 36,
            'des_pre' => '春兰',
            'site_rute' => '/trcew',
            'site_detail' => 'qohzu',
            'site_play' => 'xoywp',
            'site_type' => 'hvjjo',
        ),
    'jilinguijinshu.com' =>
        array (
            'offset' => 36,
            'des_pre' => '桃花',
            'site_rute' => '/lcpja',
            'site_detail' => 'gnmzy',
            'site_play' => 'lppzq',
            'site_type' => 'ljmum',
        ),
    'nmglthk.com' =>
        array (
            'offset' => 36,
            'des_pre' => '蕙兰',
            'site_rute' => '/pqkxp',
            'site_detail' => 'kbkqg',
            'site_play' => 'zhudu',
            'site_type' => 'sdnqi',
        ),
    'mangzihg.com' =>
        array (
            'offset' => 36,
            'des_pre' => '春兰',
            'site_rute' => '/xckma',
            'site_detail' => 'mqdcd',
            'site_play' => 'smdez',
            'site_type' => 'kbgmc',
        ),
    'ginbata.com' =>
        array (
            'offset' => 36,
            'des_pre' => '建兰',
            'site_rute' => '/vbfjr',
            'site_detail' => 'yfnsm',
            'site_play' => 'rmfyw',
            'site_type' => 'hqaru',
        ),
    'hengxingweiye.com' =>
        array (
            'offset' => 36,
            'des_pre' => '桃花',
            'site_rute' => '/kaecj',
            'site_detail' => 'wynzp',
            'site_play' => 'firix',
            'site_type' => 'fxhmc',
        ),
    'gzqcst.com' =>
        array (
            'offset' => 36,
            'des_pre' => '文竹',
            'site_rute' => '/otdgp',
            'site_detail' => 'slqlo',
            'site_play' => 'hunkg',
            'site_type' => 'yazil',
        ),
    'shihaobzj.com' =>
        array (
            'offset' => 36,
            'des_pre' => '桃花',
            'site_rute' => '/otjfe',
            'site_detail' => 'huqcn',
            'site_play' => 'autfo',
            'site_type' => 'nootu',
        ),
    'hbzhongchao.com' =>
        array (
            'offset' => 37,
            'des_pre' => '寒兰',
            'site_rute' => '/aspwn',
            'site_detail' => 'atapb',
            'site_play' => 'uozkz',
            'site_type' => 'ufzbq',
        ),
    'qyrjny.com' =>
        array (
            'offset' => 37,
            'des_pre' => '春兰',
            'site_rute' => '/mvnxo',
            'site_detail' => 'msjja',
            'site_play' => 'mpebm',
            'site_type' => 'ibjbf',
        ),
    'soloowners.net' =>
        array (
            'offset' => 37,
            'des_pre' => '墨兰',
            'site_rute' => '/nmxig',
            'site_detail' => 'umypr',
            'site_play' => 'lteqf',
            'site_type' => 'faavm',
        ),
    'zsfucai.com' =>
        array (
            'offset' => 37,
            'des_pre' => '石竹',
            'site_rute' => '/qcqeg',
            'site_detail' => 'kbgie',
            'site_play' => 'kfejc',
            'site_type' => 'rusmf',
        ),
    'xijujituan.com' =>
        array (
            'offset' => 37,
            'des_pre' => '玉兰',
            'site_rute' => '/tulcu',
            'site_detail' => 'agalo',
            'site_play' => 'ptpov',
            'site_type' => 'apkho',
        ),
    'xlbd888.com' =>
        array (
            'offset' => 37,
            'des_pre' => '石竹',
            'site_rute' => '/eztke',
            'site_detail' => 'wpwac',
            'site_play' => 'ollci',
            'site_type' => 'dxasi',
        ),
    'shinehawk.com' =>
        array (
            'offset' => 37,
            'des_pre' => '海棠',
            'site_rute' => '/eodsn',
            'site_detail' => 'zgdrg',
            'site_play' => 'rlfjb',
            'site_type' => 'aympo',
        ),
    'zjjfys.com' =>
        array (
            'offset' => 37,
            'des_pre' => '石竹',
            'site_rute' => '/hpdti',
            'site_detail' => 'fdlef',
            'site_play' => 'wlwfe',
            'site_type' => 'dfyde',
        ),
    'ar-remodeling.com' =>
        array (
            'offset' => 37,
            'des_pre' => '春菊',
            'site_rute' => '/pxlbh',
            'site_detail' => 'luyth',
            'site_play' => 'mknoh',
            'site_type' => 'vmymi',
        ),
    'nuobaoxuan.com' =>
        array (
            'offset' => 38,
            'des_pre' => '罗兰',
            'site_rute' => '/eawdx',
            'site_detail' => 'swkfw',
            'site_play' => 'aowyu',
            'site_type' => 'xblhc',
        ),
    'cqxuanli.com' =>
        array (
            'offset' => 38,
            'des_pre' => '春兰',
            'site_rute' => '/ogoja',
            'site_detail' => 'gywks',
            'site_play' => 'ygyzi',
            'site_type' => 'vxfdq',
        ),
    'jdsyb.com' =>
        array (
            'offset' => 38,
            'des_pre' => '石竹',
            'site_rute' => '/pjqpb',
            'site_detail' => 'rnxvl',
            'site_play' => 'tklqy',
            'site_type' => 'bevny',
        ),
    'jszhwhys.com' =>
        array (
            'offset' => 38,
            'des_pre' => '建兰',
            'site_rute' => '/vsiwh',
            'site_detail' => 'mfgvu',
            'site_play' => 'ncpvw',
            'site_type' => 'vvjww',
        ),
    'chencunfu.com' =>
        array (
            'offset' => 38,
            'des_pre' => '春菊',
            'site_rute' => '/eocbu',
            'site_detail' => 'mjoyf',
            'site_play' => 'keczw',
            'site_type' => 'mrqgo',
        ),
    'sanyuanlun.com' =>
        array (
            'offset' => 38,
            'des_pre' => '文竹',
            'site_rute' => '/dcgce',
            'site_detail' => 'zlrzy',
            'site_play' => 'xtgdh',
            'site_type' => 'blixh',
        ),
    'zwangsc.com' =>
        array (
            'offset' => 38,
            'des_pre' => '海棠',
            'site_rute' => '/cxuhh',
            'site_detail' => 'jibgc',
            'site_play' => 'htneo',
            'site_type' => 'fjxxj',
        ),
    'llaaj.com' =>
        array (
            'offset' => 38,
            'des_pre' => '海棠',
            'site_rute' => '/gukvq',
            'site_detail' => 'twzld',
            'site_play' => 'rknud',
            'site_type' => 'xmerj',
        ),
    'szgoodhelper.com' =>
        array (
            'offset' => 38,
            'des_pre' => '翠菊',
            'site_rute' => '/mskio',
            'site_detail' => 'gcdlc',
            'site_play' => 'scjlf',
            'site_type' => 'bbyxj',
        ),
    'ghpyzq.com' =>
        array (
            'offset' => 39,
            'des_pre' => '春兰',
            'site_rute' => '/sfcgr',
            'site_detail' => 'vymfg',
            'site_play' => 'ovqlc',
            'site_type' => 'ctdek',
        ),
    'zkshsw.com' =>
        array (
            'offset' => 39,
            'des_pre' => '玉兰',
            'site_rute' => '/ycxjr',
            'site_detail' => 'raygs',
            'site_play' => 'spqva',
            'site_type' => 'pgpgi',
        ),
    'ykhaida.com' =>
        array (
            'offset' => 39,
            'des_pre' => '翠菊',
            'site_rute' => '/lhszh',
            'site_detail' => 'bgdqi',
            'site_play' => 'jtjwu',
            'site_type' => 'pqjlq',
        ),
    'trankalhk.com' =>
        array (
            'offset' => 39,
            'des_pre' => '天竺',
            'site_rute' => '/iylww',
            'site_detail' => 'mtrkq',
            'site_play' => 'njugg',
            'site_type' => 'gdfjb',
        ),
    'hfnight.com' =>
        array (
            'offset' => 39,
            'des_pre' => '文竹',
            'site_rute' => '/wawez',
            'site_detail' => 'lgdei',
            'site_play' => 'spmsj',
            'site_type' => 'dxnta',
        ),
    'fhhefeng.com' =>
        array (
            'offset' => 39,
            'des_pre' => '玉兰',
            'site_rute' => '/klmmr',
            'site_detail' => 'qzwhp',
            'site_play' => 'cdydq',
            'site_type' => 'edayi',
        ),
    'gzykdq.com' =>
        array (
            'offset' => 39,
            'des_pre' => '玉兰',
            'site_rute' => '/ptjbd',
            'site_detail' => 'ouzst',
            'site_play' => 'ljxzp',
            'site_type' => 'cstix',
        ),
    'hebeirh.com' =>
        array (
            'offset' => 39,
            'des_pre' => '罗兰',
            'site_rute' => '/xvyaf',
            'site_detail' => 'mflib',
            'site_play' => 'tlrxl',
            'site_type' => 'ckomj',
        ),
    'meiyazs.com' =>
        array (
            'offset' => 39,
            'des_pre' => '玉兰',
            'site_rute' => '/duhbk',
            'site_detail' => 'ichbp',
            'site_play' => 'tjkbe',
            'site_type' => 'pcnsu',
        ),
    'hsxgsl.com' =>
        array (
            'offset' => 40,
            'des_pre' => '墨兰',
            'site_rute' => '/hgatf',
            'site_detail' => 'jblnm',
            'site_play' => 'ealzg',
            'site_type' => 'zdbtt',
        ),
    'xbhcp.com' =>
        array (
            'offset' => 40,
            'des_pre' => '春菊',
            'site_rute' => '/wvmng',
            'site_detail' => 'erodz',
            'site_play' => 'mflus',
            'site_type' => 'gdtnj',
        ),
    'hblianming.com' =>
        array (
            'offset' => 40,
            'des_pre' => '海棠',
            'site_rute' => '/mhgyy',
            'site_detail' => 'hrttq',
            'site_play' => 'ixbpo',
            'site_type' => 'xlvxm',
        ),
    'kalesz.com' =>
        array (
            'offset' => 40,
            'des_pre' => '文竹',
            'site_rute' => '/xgbqt',
            'site_detail' => 'fkkad',
            'site_play' => 'mbnnn',
            'site_type' => 'ymljd',
        ),
    'tlglxx.com' =>
        array (
            'offset' => 40,
            'des_pre' => '建兰',
            'site_rute' => '/jvxmq',
            'site_detail' => 'mzrqn',
            'site_play' => 'uhiec',
            'site_type' => 'ntqig',
        ),
    'cdxthx.com' =>
        array (
            'offset' => 40,
            'des_pre' => '寒兰',
            'site_rute' => '/jewzz',
            'site_detail' => 'xlqhv',
            'site_play' => 'yqwyx',
            'site_type' => 'bzqtb',
        ),
    'zdgsc.com' =>
        array (
            'offset' => 40,
            'des_pre' => '蕙兰',
            'site_rute' => '/eaokd',
            'site_detail' => 'ddwjl',
            'site_play' => 'phspa',
            'site_type' => 'phcjv',
        ),
    'dqklz.com' =>
        array (
            'offset' => 40,
            'des_pre' => '桃花',
            'site_rute' => '/halqw',
            'site_detail' => 'rhqtc',
            'site_play' => 'gusqz',
            'site_type' => 'ryabl',
        ),
    'jbpengpengche.com' =>
        array (
            'offset' => 40,
            'des_pre' => '天竺',
            'site_rute' => '/qjlyj',
            'site_detail' => 'cxthf',
            'site_play' => 'gkpwl',
            'site_type' => 'xgqwq',
        ),
    'syxwg.com' =>
        array (
            'offset' => 41,
            'des_pre' => '海棠',
            'site_rute' => '/fampp',
            'site_detail' => 'advtr',
            'site_play' => 'tebmc',
            'site_type' => 'hqijp',
        ),
    'xwjycl.com' =>
        array (
            'offset' => 41,
            'des_pre' => '文竹',
            'site_rute' => '/bicjg',
            'site_detail' => 'fzurt',
            'site_play' => 'jmojv',
            'site_type' => 'budgz',
        ),
    'guoshengif.com' =>
        array (
            'offset' => 41,
            'des_pre' => '翠菊',
            'site_rute' => '/gwudz',
            'site_detail' => 'vhstb',
            'site_play' => 'nwjrr',
            'site_type' => 'bgwud',
        ),
    'szdlat.com' =>
        array (
            'offset' => 41,
            'des_pre' => '石竹',
            'site_rute' => '/hzonw',
            'site_detail' => 'mncob',
            'site_play' => 'znnla',
            'site_type' => 'qdham',
        ),
    'kjdujia.com' =>
        array (
            'offset' => 41,
            'des_pre' => '蕙兰',
            'site_rute' => '/zqmru',
            'site_detail' => 'igdgn',
            'site_play' => 'txaor',
            'site_type' => 'jhfde',
        ),
    'wholesalemuranojewelry.com' =>
        array (
            'offset' => 41,
            'des_pre' => '桃花',
            'site_rute' => '/iclac',
            'site_detail' => 'wqwzd',
            'site_play' => 'rergv',
            'site_type' => 'puelx',
        ),
    'jinanquanchengjiaoxiao.com' =>
        array (
            'offset' => 41,
            'des_pre' => '天竺',
            'site_rute' => '/tbkal',
            'site_detail' => 'nrjlt',
            'site_play' => 'mrrue',
            'site_type' => 'suoeu',
        ),
    'casinomantraonline.com' =>
        array (
            'offset' => 41,
            'des_pre' => '蕙兰',
            'site_rute' => '/wfmvu',
            'site_detail' => 'imsmj',
            'site_play' => 'apdlv',
            'site_type' => 'gelwg',
        ),
    '871076.com' =>
        array (
            'offset' => 41,
            'des_pre' => '蕙兰',
            'site_rute' => '/rlwzb',
            'site_detail' => 'ddccn',
            'site_play' => 'krzts',
            'site_type' => 'piaky',
        ),
    'discounttheringssale.com' =>
        array (
            'offset' => 42,
            'des_pre' => '海棠',
            'site_rute' => '/xzdcc',
            'site_detail' => 'bozpf',
            'site_play' => 'svloi',
            'site_type' => 'sjdwr',
        ),
    'onlinemarketplace24.com' =>
        array (
            'offset' => 42,
            'des_pre' => '春菊',
            'site_rute' => '/rsbij',
            'site_detail' => 'nkyki',
            'site_play' => 'rpzpp',
            'site_type' => 'srpqz',
        ),
    'coarsefishinganswers.com' =>
        array (
            'offset' => 42,
            'des_pre' => '寒兰',
            'site_rute' => '/uyvfd',
            'site_detail' => 'oxogt',
            'site_play' => 'gcjmi',
            'site_type' => 'dxate',
        ),
    'beautifulriverside.com' =>
        array (
            'offset' => 42,
            'des_pre' => '蕙兰',
            'site_rute' => '/rognd',
            'site_detail' => 'ochch',
            'site_play' => 'idglg',
            'site_type' => 'hzafx',
        ),
    'darkroomdeveloping.com' =>
        array (
            'offset' => 42,
            'des_pre' => '石竹',
            'site_rute' => '/vaaqm',
            'site_detail' => 'mlkdn',
            'site_play' => 'dyrfe',
            'site_type' => 'gtoku',
        ),
    'minimalistphotography101.com' =>
        array (
            'offset' => 42,
            'des_pre' => '海棠',
            'site_rute' => '/tjapi',
            'site_detail' => 'esxbs',
            'site_play' => 'voozg',
            'site_type' => 'xpzmp',
        ),
    'nationalphlebotomycollege.com' =>
        array (
            'offset' => 42,
            'des_pre' => '墨兰',
            'site_rute' => '/xuspy',
            'site_detail' => 'mlrxk',
            'site_play' => 'zfgqy',
            'site_type' => 'gljmh',
        ),
    'motorcyclehyperstore.com' =>
        array (
            'offset' => 42,
            'des_pre' => '天竺',
            'site_rute' => '/bsylz',
            'site_detail' => 'sxcoe',
            'site_play' => 'asdrv',
            'site_type' => 'jjfyb',
        ),
    'house-dividedflags.com' =>
        array (
            'offset' => 42,
            'des_pre' => '春菊',
            'site_rute' => '/aiemq',
            'site_detail' => 'msmup',
            'site_play' => 'raoge',
            'site_type' => 'gevvx',
        ),
    'yinguicpa.com' =>
        array (
            'offset' => 43,
            'des_pre' => '墨兰',
            'site_rute' => '/juqxi',
            'site_detail' => 'chdez',
            'site_play' => 'gcfxq',
            'site_type' => 'xiugw',
        ),
    'qszdsy.com' =>
        array (
            'offset' => 43,
            'des_pre' => '蕙兰',
            'site_rute' => '/reayz',
            'site_detail' => 'imjcq',
            'site_play' => 'mcgza',
            'site_type' => 'rdwbw',
        ),
    'hcys.com' =>
        array (
            'offset' => 43,
            'des_pre' => '春菊',
            'site_rute' => '/kdilr',
            'site_detail' => 'xbcew',
            'site_play' => 'wiydr',
            'site_type' => 'bjfao',
        ),
    'szdywl.com' =>
        array (
            'offset' => 43,
            'des_pre' => '寒兰',
            'site_rute' => '/tksak',
            'site_detail' => 'pjofn',
            'site_play' => 'iujpa',
            'site_type' => 'wiyoz',
        ),
);
?>
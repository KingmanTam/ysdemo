<?php

class app
{
    public static array $mysql = [
        'host' => '127.0.0.1',
        'port' => '3306',
        'dbname' => 'chaos',
        'user' => 'root',
        'password' => 'root'
    ];
    public static array $redis = [
        'host' => '127.0.0.1',
        'port' => 6379,
        'password' => '',
        'timeout' => 60*60*2
    ];
    public static array $domain = [
        'title' => '',//首页标题
        'domain' => 'frontend.com',//域名
        'keywords' => '',//关键词
        'description' => '',//描述
        'template' => '',//模板路径
        'html' => '',//html路径
        'name' => '',//网站名称
        'offset' => 0,//列表偏移
        'rute' => 'type',//一级路径
        'rute_detail' => 'dd',//详细路径
        'rute_play' => 'pp',//播放路径
        'rute_type' => 'ty',//分类路径
    ];

    public static array $paeConfig = [
        'd_size' => 8,//详细页面数据列表size
        'p_size' => 8,//播放页面数据列表size
        't_size' => 12,//类别页面数据列表size
        's_size' => 12,//搜索页面数据列表size
        'i_size' => 8//首页数据列表size
    ];
    /**
     * @var int
     * 是否为蜘蛛
     */
    public static int $is_spider = 0;

    /**
     * @var string
     * ua
     */
    public static string $ua = '';

    /**
     * @var bool
     * 有效请求
     */
    public static bool $valid_url = true;

    /**
     * @var int
     * 视频id
     */
    public static int $id = 0;

    /**
     * @var int
     * 当前页码
     */
    public static int $page = 1;

    /**
     * @var int
     * 分类id
     */
    public static int $typeId = 0;

    /**
     * @var string
     * 方法
     */
    public static string $method = '';

    /**
     * @var string
     * 页面内容
     */
    public static string $content = '';

    /**
     * @var string
     * 搜索关键词
     */
    public static string $searchKey = '';

    /**
     * @var string
     * error
     */
    public static string $error = '';

}
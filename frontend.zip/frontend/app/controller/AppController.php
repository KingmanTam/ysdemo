<?php

require 'app/common/PageUtils.php';
require 'app/service/AppService.php';
class AppController
{
    /**
     * @throws Exception
     */
    public function index(): void
    {
        if (!app::$is_spider) {
            AppService::getPage();
        }
        if (!empty(app::$content)) {
            echo app::$content;
            exit();
        }
        AppService::loadHtml('index');
        AppService::setCommon();
        AppService::setItemList();
        if (!app::$is_spider) {
            Cache::set('page:' . app::$domain['domain'], app::$content, app::$redis['timeout']);
        }
        $this->run();
    }

    /**
     * @throws Exception
     */
    public function detail(): void
    {
        AppService::loadHtml('detail');
        AppService::setDetail();
        AppService::setCommon();
        AppService::setItemList();
        $this->run();
    }

    /**
     * @throws Exception
     */
    public function play(): void
    {
        AppService::loadHtml('play');
        AppService::setPlayInfo();
        AppService::setCommon();
        AppService::setItemList();
        $this->run();
    }

    /**
     * @throws Exception
     */
    public function type(): void
    {
        if (!app::$is_spider) {
            AppService::getPage();
        }
        AppService::loadHtml('type');
        AppService::setTypeInfo();
        AppService::setCommon();
        AppService::setItemList();
        if (!app::$is_spider) {
            Cache::set('page_t:' . app::$domain['domain'].'_'.app::$typeId.'_'.app::$page, app::$content, app::$redis['timeout']);
        }
        $this->run();
    }

    public function search(): void
    {
        AppService::loadHtml('search');
        AppService::setCommon();
        AppService::setSearch();
        $this->run();
    }


    public function error(): void
    {
        AppService::loadHtml('error');
        AppService::setError();
        $this->run();
    }

    public function run(): void
    {
        echo app::$content;
    }
}
<?php
require 'app/init.php';
require 'app/conn.php';
require 'app/controller/AppController.php';

app::$is_spider = common::isSpider();
$controller = new AppController();
try {
    if (!empty(app::$error)){
        $controller->error();
    }
    $b = common::validUrl();
    if (!$b){
        app::$error = '资源不存在，请浏览其他视频或者联系管理员补充！';
        $controller->error();
    }
    if (app::$method == 'index') {
        $controller->index();
    }
    if (app::$method == 'detail') {
        $controller->detail();
    }
    if (app::$method == 'play') {
        $controller->play();
    }
    if (app::$method == 'type') {
        $controller->type();
    }
    if (app::$method == 'search') {
        $controller->search();
    }
} catch (Exception $e) {
    app::$error = '系统出错，请浏览其他视频或者联系管理员补充！';
    $controller->error();
}


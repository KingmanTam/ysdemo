console.log('this is content js')
console.log('document', document)
console.log('location', location)
console.log('window', window)

async function sendDomainInfo(nl, gxsj, jls, sj_min, sj_max, yy, bt, zt, wz, pf) {
    let url = 'http://hl.com/api.php/provide/vod/?ac=list&nl=' + nl + '&gxsj=' + gxsj + '&jls=' + jls + '&sj_min=' + sj_min + '&sj_max=' + sj_max + '&yy=' + yy + '&bt=' + decodeURI(bt) + '&zt=' + zt + '&wz=' + wz + '&pf=' + pf;
    console.log(url);
    //chrome.runtime.sendMessage({'type': 'jm', 'sendUrl': url});
    // const response = await fetch(url)
    // console.log(response)
    chrome.runtime.sendMessage({action: "fromContentFetch",url:url});
}

async function getDomainInfo(domain, key) {
    // let xhr = new XMLHttpRequest();
    // xhr.onloadend = function () {
    //     let json_data = xhr.response;
    //     let res = JSON.parse(json_data);
    //     if (res['code'] === 1) {
    //         let data = res['data'];
    //         let bt = Unicode2Native(data['bt'])
    //         sendDomainInfo(data['nl'], data['gxsj'], data['jls'], data['sj_min'], data['sj_max'], data['yy'], bt, data['zt'], data['wz'], data['pf'])
    //     }
    // }
    //let url = 'https://www.juming.com/hao/cha_d?do=lishi&ym=' + domain + '&key=' + key;
    const response = await fetch('https://dplayer.diygod.dev/')
    if (!response.ok) {
        throw new Error('Network response was not ok')
    }
    sendDomainInfo('1', "2", "3", "4", "5", "6", "7", "7", "9", "10");

}

async function geReturnTop(reqdomain) {
    // var xhr = new XMLHttpRequest();
    // xhr.onloadend = function () {
    //     let reptext = xhr.response;
    //     // let ends = reptext.indexOf('</script>');
    //     // let scriptText = reptext.substring(0,ends)
    //     let startnum = reptext.indexOf('key');
    //     let endnum = reptext.indexOf('jmkey');
    //     let key = reptext.substring(startnum + 5, endnum - 2);
    //     getDomainInfo(reqdomain, key);
    // }
    //let reqpurl = 'https://www.juming.com/hao?ym=' + reqdomain + '&fs=1&_=' + (new Date().getTime());
    //const response = await fetch('https://www.juming.com/hao?ym=' + reqdomain + '&fs=1&_=' + (new Date().getTime()))
    const response = await fetch('https://dplayer.diygod.dev/')
    console.log("jum", response);
    if (!response.ok) {
        throw new Error('Network response was not ok')
    }
    //const allData = await response.json()

    getDomainInfo("baidu.com",22)
}

function getOkDoamin(){
    const listform = document.getElementById('app');
    console.log(listform);
    geReturnTop("baidu.com")
    // const trlist = listform.getElementsByTagName('tr');
    // let lenl = trlist.length-1
    // for (let i = 1; i < lenl; i++) {
    //     let cells = trlist[i].cells;
    //     let domain = cells[0].innerText;
    //     let len = cells[1].innerText;
    //     let des = cells[2].innerText;
    //     let opt = cells[7].innerText;
    //     //if (opt!='立即注册') continue;
    //     if (len<5) continue;
    //     if (len>18)continue;
    //     if (des.length<4) continue;
    //     if (des.indexOf('建站')<0)continue;
    //     if (des.indexOf('记录0条')!==-1) continue;
    //     if (des.indexOf('建站0年')!==-1) continue;
    //     let reqdomain = domain.replace('.','_');
    //     geReturnTop(reqdomain);
    // }
    // setTimeout(function (){next()},2000)
}
let start = 0;
let end = false;
let tags = 'tv';
let step = 100;
function getDoubanList(){

    if (end){
        console.log('end**************', end)
        return;
    }
    fetch('https://movie.douban.com/j/new_search_subjects?tags=tv&range=0,5&limit=100&start='+start).then(res=>{
        return res.json()
    }).then(res2=>{
        if (res2.data.length < 1){
            end = true
        }else {
            let list = res2.data;
            for (let j = 0; j < list.length; j++) {
                data = list[j];
                let casts = "";
                let casts_arr = data.casts
                if (casts_arr.length > 0){
                    casts = casts_arr.join(',')
                }

                let directors = ''
                let directors_arr = data.directors
                if (directors_arr.length > 0){
                    directors = directors_arr.join(',')
                }

                let cover = data.cover
                let id = data.id
                let rate = data.rate
                let star = data.star
                let title = data.title
                let url = data.url
                let send_url = 'http://hl.com/api.php/vod/get_list?cover=' +decodeURI(cover)  + '&rate=' + rate +
                    '&star=' + star + '&title=' + title + '&url=' + decodeURI(url) + '&casts=' + casts + '&directors=' + directors+ '&start=' + start+ '&tag='+tags;
                chrome.runtime.sendMessage({action: "fromContentFetch",url:send_url});
            }

        }
    }).catch(error=>{
        console.log(error);
    })
    start = start+step;

}

function scDouban(){
    //getDoubanList();
    setInterval(getDoubanList, 10000);
}

async function getDoubanTv() {
    // let types = new Array('喜剧','爱情','动作','科幻','动画','悬疑','犯罪','惊悚','冒险','音乐','历史','奇幻','恐怖','战争','传记','歌舞','武侠','情色','灾难','西部','纪录片','短片');
    // let areas = new Array('华语','欧美','韩国','日本','中国大陆','美国','中国香港','中国台湾','英国','法国','德国','意大利','西班牙','印度','泰国','俄罗斯','加拿大','澳大利亚','爱尔兰','瑞典','巴西','丹麦')
    //
    let types = new Array('喜剧', '爱情', '悬疑', '动画', '武侠', '古装', '家庭', '犯罪', '科幻', '恐怖', '历史', '战争', '动作', '冒险', '传记', '剧情', '奇幻', '惊悚', '灾难', '歌舞', '音乐');
    let areas = new Array('华语', '欧美', '国外', '韩国', '日本', '中国大陆', '中国香港', '美国', '英国', '泰国', '中国台湾', '意大利', '法国', '德国', '西班牙', '俄罗斯', '瑞典', '巴西', '丹麦', '印度', '加拿大', '爱尔兰', '澳大利亚')
    let tags_url = 'https://m.douban.com/rexxar/api/v2/tv/recommend/filter_tags?selected_categories=';
    let res = await fetch('https://m.douban.com/rexxar/api/v2/movie/recommend?refresh=0&start=0&count=20&selected_categories=%7B%22%E7%B1%BB%E5%9E%8B%22:%22%E5%96%9C%E5%89%A7%22%7D&uncollect=false&score_range=0,10&tags=%E5%96%9C%E5%89%A7');
    data = await res.json();
    let items = data['items'];
    for (let j = 0; j < items.length; j++) {
        let item = items[j];
        chrome.runtime.sendMessage({action: "fromContentFetch",data:JSON.stringify(item)});
    }
    return;
    let item_cont = 0
    //for (let i = 0; i < types.length; i++) {
    for (let i = 0; i < 1; i++) {
        let type = types[i];
        let res = await fetch('https://m.douban.com/rexxar/api/v2/movie/recommend?refresh=0&start=20&count=20&selected_categories=%7B%22%E7%B1%BB%E5%9E%8B%22:%22%E5%96%9C%E5%89%A7%22%7D&uncollect=false&score_range=0,10&tags=%E5%96%9C%E5%89%A7');
        data = res.json();
        console.log(res);
        console.log(1111111111111111);
        let items = data['item'];
        console.log(items);
        for (let j = 0; j < items.length; j++) {
            let item = items[j];
            console.log(item);
        }
        // for (let j = 1; j < areas.length; j++) {
        //     let area = areas[j];
        //     let params = {'类型': type, '形式': '电视剧', '地区': area};
        //     let p = JSON.stringify(params);
        //     //let tag_data = extGet(encodeURI(tags_url+p));
        //     let tag_data = await fetch(encodeURI(tags_url + p));
        //     let years = tag_data['tags'][0]['tags'];
        //     let pts = tag_data['tags'][1]['tags'];
        //     let tags = tag_data['tags'][2]['tags'];
        //     for (let k = 1; k < years.length; k++) {
        //         let year = years[k]
        //         let url_tags = type + ',' + area + ',' + year;
        //         let flag = true;
        //         let start = 0;
        //         let count = 50;
        //         let total = 0;
        //         while (flag) {
        //             let item_url = 'https://m.douban.com/rexxar/api/v2/movie/recommend?refresh=0&start=' + start + '&count=' + count + '&selected_categories=' + p + '&uncollect=false&tags=' + url_tags + '&sort=S&ck=Ras9';
        //             let item_data = extGet(encodeURI(item_url))
        //             total = item_data['total'];
        //             start = item_data['start'];
        //             let items = item_data['items'];
        //             let data_len = items.length;
        //             if (data_len < 1) {
        //                 flag = false;
        //             }
        //             for (let m = 0; m < data_len; m++) {
        //                 let item = items[m];
        //                 let id = item['id'];
        //                 let title = item['title'];
        //                 saveDouban(id, title);
        //                 item_cont = item_cont + 1;
        //             }
        //             start = start + count;
        //         }
        //         console.log(p + ',' + url_tags + ',count:' + item_cont + ',total:' + total)
        //         item_cont = 0
        //         total = 0
        //
        //     }
        // }
    }
}
//创建页面函数
function createPage () {
    const page = $('<div id="cj_move_page"></div>')
    const h3 = $('<h3 id="cj_move_h3">My Chrome Ext Content Page</h3>')
    const but1 = $('<button id="cj_but1">消息通知</button>')
    const but2 = $('<button id="cj_but2">content 加载更多</button>')
    const but3 = $('<button id="cj_but3">service worker 加载</button>')
    const but4 = $('<button id="cj_but4">加载domain</button>')
    page.append(h3)
    page.append(but1)
    page.append(but2)
    page.append(but3)
    page.append(but4)
    $('body').append(page)
    // 消息通知按钮事件
    $('#cj_but1').click(async (e) => {
        console.log('e', e, chrome)
        chrome.runtime.sendMessage({action: "fromContent"});
    })
    // content 加载更多按钮事件
    $('#cj_but2').click(async (e) => {
        const response = await fetch("https://dplayer.diygod.dev/")
        console.log("douban", response);
        if (!response.ok) {
            throw new Error('Network response was not ok')
        }
        const allData = await response.json()
        console.log('content index allData', allData)
    })
    // service worker 加载按钮事件
    $('#cj_but3').click(async (e) => {
        console.log('e', e, chrome)
        chrome.runtime.sendMessage({action: "fromContentFetch"});
    })

    $('#cj_but4').click(async (e) => {
        //getOkDoamin();
        //scDouban();
        getDoubanTv();
    })

    //拖拽
    drag(cj_move_h3)
}

createPage()

//拖拽
function drag(ele) {
    let oldX, oldY, newX, newY
    ele.onmousedown = function (e) {
        if (!cj_move_page.style.right && !cj_move_page.style.bottom) {
            cj_move_page.style.right = 0
            cj_move_page.style.bottom = 0
        }
        oldX = e.clientX
        oldY = e.clientY
        document.onmousemove = function (e) {
            newX = e.clientX
            newY = e.clientY
            cj_move_page.style.right = parseInt(cj_move_page.style.right) - newX + oldX + 'px'
            cj_move_page.style.bottom = parseInt(cj_move_page.style.bottom) - newY + oldY + 'px'
            oldX = newX
            oldY = newY
        }
        document.onmouseup = function () {
            document.onmousemove = null
            document.onmouseup = null
        }
    }
}
chrome.runtime.onConnect.addListener((res) => {
    console.log('contentjs中的 chrome.runtime.onConnect：',res)
    if (res.name === 'fromPopup2Content') {
        res.onMessage.addListener(mess => {
            console.log('contentjs中的 res.onMessage.addListener：', mess)
            res.postMessage('哈哈哈，我是contentjs')
        })
    }
})

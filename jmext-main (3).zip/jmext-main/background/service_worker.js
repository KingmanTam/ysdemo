chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {

    if (message.action === 'fromContentFetch') {
        console.log('service worker fromContentFetch',message.data);
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: message.data,
        };
        const response = await fetch('http://hl.com/api.php/vod/get_list', options);
        if (!response.ok) {
            throw new Error('Network response was not ok')
        }
        const allData = await response.json()
        console.log('service worker allData', allData)
    }
});

const plugin_search_but = document.getElementById('plugin_search_but')
const plugin_search_inp = document.getElementById('plugin_search_inp')
plugin_search_but.onclick = async function () {

    const [tab] = await chrome.tabs.query({
        url: ["https://dplayer.diygod.dev/*"],
        active: true,
        currentWindow: true
    });
    console.log('tab', tab)
    if (tab) {

        const connect = chrome.tabs.connect(tab.id, {name: 'fromPopup2Content'});
        console.log('connect', connect)
        connect.postMessage('这里是弹出框页面，你是谁？')
        connect.onMessage.addListener((mess) => {
            console.log(mess)
        })
    }
}

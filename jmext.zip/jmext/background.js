

function initialize_extension() {

    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.type = "jm") {

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                console.log(xhr.response);
            }
            xhr.open('GET', request.sendUrl, true);
            xhr.send(null);
        }
        if (request.type = "douban") {

            var xhr = new XMLHttpRequest();
            xhr.open('GET', request.sendUrl, true);
            xhr.send(null);
        }
        if (request.type = "jd") {

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                console.log(xhr.response);
            }
            xhr.open('GET', request.sendUrl, true);
            xhr.send(null);
        }
    });
}

initialize_extension();

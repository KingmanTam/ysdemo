


function containsNumber(str) {
    var reg=/\d/;
    return reg.test(str);
}
function getDouban(){
    // let types = new Array('喜剧','爱情','动作','科幻','动画','悬疑','犯罪','惊悚','冒险','音乐','历史','奇幻','恐怖','战争','传记','歌舞','武侠','情色','灾难','西部','纪录片','短片');
    // let areas = new Array('华语','欧美','韩国','日本','中国大陆','美国','中国香港','中国台湾','英国','法国','德国','意大利','西班牙','印度','泰国','俄罗斯','加拿大','澳大利亚','爱尔兰','瑞典','巴西','丹麦')
    //{"类型":"科幻","地区":"欧美"},科幻,欧美,90年代,count:193,total:500
    let types = new Array('喜剧','爱情','动作','科幻','动画','悬疑','犯罪','惊悚','冒险','音乐','历史','奇幻','恐怖','战争','传记','歌舞','武侠','情色','灾难','西部','纪录片','短片');
    let areas = new Array('华语','欧美','韩国','日本','中国大陆','美国','中国香港','中国台湾','英国','法国','德国','意大利','西班牙','印度','泰国','俄罗斯','加拿大','澳大利亚','爱尔兰','瑞典','巴西','丹麦')
    let tags_url = 'https://m.douban.com/rexxar/api/v2/movie/recommend/filter_tags?selected_categories=';
    let item_cont = 0
    for (let i = 0; i < types.length; i++) {
        let type = types[i];
        for (let j = 0; j < areas.length; j++) {
            let area = areas[j];
            let params = {'类型': type,'地区':area};
            let p = JSON.stringify(params);
            let tag_data = extGet(encodeURI(tags_url+p));
            let years = tag_data['tags'][0]['tags'];
            let tags = tag_data['tags'][1]['tags'];
            for (let k = 1; k < years.length; k++) {
                let year = years[k]
                let url_tags = type+','+area+','+year;
                let flag = true;
                let start = 0;
                let count = 100;
                let total = 0;
                while (flag){
                    let item_url = 'https://m.douban.com/rexxar/api/v2/movie/recommend?refresh=0&start='+start+'&count='+count+'&selected_categories='+p+'&uncollect=false&tags='+url_tags+'&sort=S&ck=Ras9';;
                    let item_data = extGet(encodeURI(item_url))
                    total = item_data['total'];
                    start = item_data['start'];
                    let items = item_data['items'];
                    let data_len = items.length;
                    console.log(data_len)
                    if (data_len<1){
                        flag = false;
                    }
                    for (let m = 0; m < data_len; m++) {
                        let item = items[m];
                        let id = item['id'];
                        let title = item['title'];
                        saveDouban(id,title);
                        item_cont = item_cont +1;
                    }
                    start = start + count;
                }
                console.log(p+','+url_tags+',count:'+item_cont+',total:'+total);
                item_cont = 0;
                total = 0;
            }
        }
    }
}
function getDoubanTv(){
    // let types = new Array('喜剧','爱情','动作','科幻','动画','悬疑','犯罪','惊悚','冒险','音乐','历史','奇幻','恐怖','战争','传记','歌舞','武侠','情色','灾难','西部','纪录片','短片');
    // let areas = new Array('华语','欧美','韩国','日本','中国大陆','美国','中国香港','中国台湾','英国','法国','德国','意大利','西班牙','印度','泰国','俄罗斯','加拿大','澳大利亚','爱尔兰','瑞典','巴西','丹麦')
    //
    let types = new Array('喜剧','爱情','悬疑','动画','武侠','古装','家庭','犯罪','科幻','恐怖','历史','战争','动作','冒险','传记','剧情','奇幻','惊悚','灾难','歌舞','音乐');
    let areas = new Array('华语','欧美','国外','韩国','日本','中国大陆','中国香港','美国','英国','泰国','中国台湾','意大利','法国','德国','西班牙','俄罗斯','瑞典','巴西','丹麦','印度','加拿大','爱尔兰','澳大利亚')
    let tags_url = 'https://m.douban.com/rexxar/api/v2/tv/recommend/filter_tags?selected_categories=';
    let item_cont = 0
    for (let i = 7; i < types.length; i++) {
        let type = types[i];
        for (let j = 1; j < areas.length; j++) {
            let area = areas[j];
            let params = {'类型': type,'形式':'电视剧','地区':area};
            let p = JSON.stringify(params);
            let tag_data = extGet(encodeURI(tags_url+p));
            let years = tag_data['tags'][0]['tags'];
            let pts = tag_data['tags'][1]['tags'];
            let tags = tag_data['tags'][2]['tags'];
            for (let k = 1; k < years.length; k++) {
                let year = years[k]
                let url_tags = type+','+area+','+year;
                let flag = true;
                let start = 0;
                let count = 50;
                let total = 0;
                while (flag){
                    let item_url = 'https://m.douban.com/rexxar/api/v2/movie/recommend?refresh=0&start='+start+'&count='+count+'&selected_categories='+p+'&uncollect=false&tags='+url_tags+'&sort=S&ck=Ras9';
                    let item_data = extGet(encodeURI(item_url))
                    total = item_data['total'];
                    start = item_data['start'];
                    let items = item_data['items'];
                    let data_len = items.length;
                    if (data_len<1){
                        flag = false;
                    }
                    for (let m = 0; m < data_len; m++) {
                        let item = items[m];
                        let id = item['id'];
                        let title = item['title'];
                        saveDouban(id,title);
                        item_cont = item_cont +1;
                    }
                    start = start + count;
                }
                console.log(p+','+url_tags+',count:'+item_cont+',total:'+total)
                item_cont = 0
                total = 0

            }
        }
    }
}

function sHanld(p,url_tags){
    let xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        let res = xhr.response;
        let data = JSON.parse(res);
        let total = data['total'];
        return total;
    }
    xhr.open('GET', url, false);
    xhr.send(null);
}

function getTotal(url){
    let xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        let res = xhr.response;
        let data = JSON.parse(res);
        let total = data['total'];
        return total;
    }
    xhr.open('GET', url, false);
    xhr.send(null);
    let res = xhr.responseText;
    let data = JSON.parse(res);
    let total = data['total'];
    return total;
}

function saveDouban(id,title){
    let url = 'http://xone.com:8787/douban/'+id+'/'+title+'/';
    chrome.runtime.sendMessage({'type': 'douban','sendUrl':url});
}

function extGet(url){
    let xhr = new XMLHttpRequest();
    xhr.open('GET', url, false);
    xhr.send(null);
    let res = xhr.responseText;
    let data = JSON.parse(res);
    return data
}

function getDomain(){
    /*const aTags = document.getElementsByClassName('td_yd');
    for (let i = 0; i < aTags.length; i++) {
        let a = aTags[i].getElementsByTagName('a');
        if (a[0].innerText=='GO'){
            a[0].click();
        }
    }*/
    getOkDoamin();
    //setTimeout(function (){getOkDoamin()},2000)
    //getDouban()
    //getDoubanTv();
    // for (let i = 1; i < 100; i++) {
    //     saveDouban(i,'白哦提'+i)
    //     console.log(i)
    // }
    // for (let i = 0; i < 10; i++) {
    //     let url = 'https://m.douban.com/rexxar/api/v2/movie/recommend?refresh=0&start='+i*20+'&count=20&selected_categories=%7B%22%E5%9C%B0%E5%8C%BA%22:%22%E5%8D%8E%E8%AF%AD%22,%22%E7%B1%BB%E5%9E%8B%22:%22%E5%96%9C%E5%89%A7%22%7D&uncollect=false&tags=%E5%8D%8E%E8%AF%AD,%E5%96%9C%E5%89%A7';
    //     let data = extGet(url)
    //     console.log(data)
    //     console.log('js:'+i)
    // }
}

function getOkDoamin(){
    const listform = document.getElementById('listform');
    const trlist = listform.getElementsByTagName('tr');
    let lenl = trlist.length-1
    for (let i = 1; i < lenl; i++) {
        let cells = trlist[i].cells;
        let domain = cells[0].innerText;
        let len = cells[1].innerText;
        let des = cells[2].innerText;
        let opt = cells[7].innerText;
        //if (opt!='立即注册') continue;
        if (len<5) continue;
        if (len>18)continue;
        if (des.length<4) continue;
        if (des.indexOf('建站')<0)continue;
        if (des.indexOf('记录0条')!==-1) continue;
        if (des.indexOf('建站0年')!==-1) continue;
        let reqdomain = domain.replace('.','_');
        geReturnTop(reqdomain);
    }
    setTimeout(function (){next()},2000)
}
function geReturnTop(reqdomain){
    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        let reptext = xhr.response;
        // let ends = reptext.indexOf('</script>');
        // let scriptText = reptext.substring(0,ends)
        let startnum = reptext.indexOf('key');
        let endnum = reptext.indexOf('jmkey');
        let key = reptext.substring(startnum+5,endnum-2);
        getDomainInfo(reqdomain,key);
    }
    let reqpurl = 'https://www.juming.com/hao?ym='+reqdomain+'&fs=1&_='+(new Date().getTime());
    xhr.open('GET', reqpurl, false);
    xhr.send(null);
}
function getDomainInfo(domain,key){
    let xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        let json_data = xhr.response;
        let res = JSON.parse(json_data);
        if (res['code'] ===1){
            let data = res['data'];
            let bt = Unicode2Native(data['bt'])
            sendDomainInfo(data['nl'],data['gxsj'],data['jls'],data['sj_min'],data['sj_max'],data['yy'],bt,data['zt'],data['wz'],data['pf'])
        }
    }
    let url = 'https://www.juming.com/hao/cha_d?do=lishi&ym='+domain+'&key='+key;
    xhr.open('GET', url, false);
    xhr.send(null);
}
function Unicode2Native(title) {
    let code = title.match(/&#(\d+);/g);
    if (code == null) {
        return;
    }
    let rtitle = '';
    for (let i=0; i<code.length; i++){
        rtitle = rtitle + String.fromCharCode(code[i].replace(/[&#;]/g, ''));
    }
    return rtitle;
}
function sendDomainInfo(nl,gxsj,jls,sj_min,sj_max,yy,bt,zt,wz,pf){
    let url = 'http://localhost:8080/api?nl='+nl+'&gxsj='+gxsj+'&jls='+jls+'&sj_min='+sj_min+'&sj_max='+sj_max+'&yy='+yy+'&bt='+decodeURI(bt)+'&zt='+zt+'&wz='+wz+'&pf='+pf;
    console.log(url);
    chrome.runtime.sendMessage({'type': 'jm','sendUrl':url});
}
function next(){

    const next = document.getElementsByClassName('nextpage');
    next[0].click();
    setTimeout(function (){getDomain()},2000)
}

function checkDomain(){
    const listform = document.getElementById('listform');
    const trlist = listform.getElementsByTagName('tr');


    let lenl = trlist.length-1
    let cells = trlist[1].cells;
    console.log(cells);
    console.log(cells[0]);
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        let returntop = document.getElementsByClassName('returnTop');
        returntop[0].innerHTML = xhr.response
        let returntop1 = document.getElementsByClassName('returnTop');
        let scriptText = returntop1[0].getElementsByTagName('script')[0].innerText;
        let startnum = scriptText.indexOf('key');
        let endnum = scriptText.indexOf('jmkey');
        console.log(scriptText.substring(startnum+5,endnum-2))

    }
    xhr.open('GET', 'https://www.juming.com/hao?ym=vishow_cn&fs=1&_=1686768908691', true);
    xhr.send(null);

    const  ta = cells[0].getElementsByClassName('a_ym')



    ta[0].addEventListener('click',function (){
        setTimeout(function() {
            console.log("延迟 1 秒钟执行的代码");
        }, 1000);
        const zh = document.getElementById('zonghe');
        console.log(zh)

    })
    ta[0].click();


    let domain = cells[0].innerText;
    let len = cells[1].innerText;
    let des = cells[2].innerText;
    let opt = cells[7].innerText;
    /*const aAllTags = document.getElementsByClassName('td_yd');
    for (let i = 0; i < aAllTags.length; i++) {
        let a = aAllTags[i].getElementsByTagName('a');
        a[0].click();
    }*/
}

function sendJdShopInfo(title){
    let url = 'http://localhost:8081/sys/jd/shop/'+decodeURI(title);
    console.log(url);
    chrome.runtime.sendMessage({'type': 'jd','sendUrl':url});
}

function sendJdItem(name){
    let url = 'http://localhost:8081/sys/jd/item/'+decodeURI(name);
    chrome.runtime.sendMessage({'type': 'jd','sendUrl':url});
}

function getJdShop(){
    const goodsListDiv = document.getElementById('J_goodsList');
    const goodsListUls = goodsListDiv.getElementsByClassName("gl-warp");
    console.log(goodsListUls.length);
    const goodsListUl = goodsListUls.item(0);
    console.log(goodsListUl);
    const goodsLis = goodsListUl.getElementsByTagName('li');
    for (let i = 0; i < goodsLis.length; i++) {
        let goodsLi = goodsLis.item(i);
        let shops = goodsLi.getElementsByClassName("curr-shop");
        if (shops.length>0){
            let title = shops.item(0).getAttribute("title");
            sendJdShopInfo(title);
        }
    }
}

function getShopItem(){
    const goodsListDiv = document.getElementById('J_goodsList');
    const goodsListUls = goodsListDiv.getElementsByClassName("gl-warp");
    console.log(goodsListUls.length);
    const goodsListUl = goodsListUls.item(0);
    const goodsLis = goodsListUl.getElementsByClassName("gl-item");
    console.log(goodsListUl);
    for (let i = 0; i < goodsLis.length; i++) {
        let goodsLi = goodsLis.item(i);
        console.log(goodsLi);
        let shops = goodsLi.getElementsByClassName("p-name");
        if (shops.length<1){
            continue;
        }
        let emTags = shops.item(0).getElementsByTagName("em");
        if (emTags.length<1){
            continue;
        }
        let nameTag = emTags.item(0);
        let name = nameTag.textContent;
        sendJdItem(name);
    }
}

function initForPage() {
    if (!document.body)
        return;

    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.wdm_unhighlight) {
            var lemma = request.wdm_unhighlight;
            unhighlight(lemma);
        }
        if (request.begin) {
            getShopItem();
        }
        // if (request.begin) {
        //     getDomain();
        // }
        // if (request.beginGet) {
        //     getOkDoamin();
        // }
        // if (request.next) {
        //     next();
        // }
        // if (request.checks) {
        //     //checkDomain();
        // }
    });
}
function begin(){
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.begin) {
            console.log(96341)
        }
    });
}

document.addEventListener("DOMContentLoaded", function (event) {
    //console.log(3333)
    initForPage();
});

